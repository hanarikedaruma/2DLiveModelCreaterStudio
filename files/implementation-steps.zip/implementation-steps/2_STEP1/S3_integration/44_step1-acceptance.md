# 44. STEP1の結合と受け入れ

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | STEP1 / S3 結合 |
| 並行作業 | 直列 |
| 担当の目安 | 結合 |
| 作業場所 | apps/desktop/src/services.ts、docs/ |

## 目的

STEP1の仮実装を本物に差し替え、STEP1の完成条件をすべて確かめる。

## 前提（このカードの時点ですでにあるもの）

次の本物の実装がある。

| 提供元 | 関数 |
| --- | --- |
| @app/audio | createAudioSource、createLipSyncProducer |
| @app/core | createAutoBlink、createBodyFollowProducer、createExpressionController |
| @app/tracking | createCalibrationService |
| apps/desktop | createHotkeyService（src/hotkeys）、createSpoutSink（src/output/spout） |

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### サービスのまとめ（@app/contracts）

```ts
export interface Services {
  store: ProjectStore; editor: EditorStore; assets: AssetRepository; fs: FileSystem;
  evaluator: BindingEvaluator; pipeline: DeformPipeline; mixer: ParameterMixer; createRenderer(): Renderer;
  meshGenerator: MeshGenerator; keyGenerator: KeyGenerator; autoSetup: AutoSetup; keyEditor: KeyEditor;
  importer: Importer; io: ProjectIO; autoSaver: AutoSaver;
  tracking: TrackingSource; trackingLayer: TrackingLayerProducer;
}
```

### STEP1で増える契約（@app/contracts）

```ts
// TrackingFrame に足す任意の項目（無いときは undefined）
//   mouthForm?: number;  // -1..1（への字〜笑顔）
//   mouthWidth?: number; // -1..1（すぼめ〜横に開く）
//   browY?: number;      // -1..1（下げる〜上げる）

export interface AudioLevel { time: number; rmsDb: number }
export interface AudioSource {
  listDevices(): Promise<{ id: string; label: string }[]>;
  start(deviceId?: string): Promise<void>; stop(): void;
  onLevel(listener: (x: AudioLevel) => void): () => void;                                   // 10ms ごと
  onSamples(listener: (samples: Float32Array, sampleRate: number, time: number) => void): () => void;
}
export interface LipSyncProducer extends LayerProducer {   // id 'lipSync'
  configure(o: { mouthSource: 'max' | 'micOnly' | 'cameraOnly'; strength: 'low' | 'standard' | 'high'; silenceThresholdDb: number }): void;
  update(level: AudioLevel): void;
}
export interface AutoBlink { tick(now: number): { EyeOpenL: number; EyeOpenR: number } }
export interface BodyFollowProducer extends LayerProducer { setStrength(s: 'low' | 'standard' | 'high'): void }   // id 'bodyFollow'
export interface ExpressionController extends LayerProducer {   // id 'expression'
  apply(expressionId: string | null, now: number): void;        // null で解除。STEP1では1つだけ
  active(): string | null;
}
export type CalibrationStep = 'neutral' | 'eyesClosed' | 'mouthOpen';
export interface CalibrationService { capture(step: CalibrationStep, frames: TrackingFrame[]): void; result(): Environment['calibration']; reset(): void }
// TrackingLayerProducer に足すメソッド
//   setCalibration(c: Environment['calibration']): void
//   setPreset(p: 'stable' | 'standard' | 'large' | 'custom', custom?: { minCutoff: number; beta: number; gain: number; deadZone: number }): void
//   setEyeTracking(on: boolean): void   // off のときと外れたときは AutoBlink の値を使う
export interface HotkeyService { register(hotkey: Hotkey, handler: (phase: 'down' | 'up') => void): Promise<'ok' | 'conflict'>; unregisterAll(): Promise<void> }
export interface OutputSink {
  start(o: { width: number; height: number; fps: number }): Promise<void>;
  setTextures(pngs: Record<string, Uint8Array>): Promise<void>;
  submit(model: DeformedModel, view: ViewTransform, background: Background): void;
  stop(): Promise<void>;
}
// KeyGenerator に足すメソッド
//   rotate(binding: Binding, model: Model): Binding                    // 頂点・制御点をピボット中心の円弧で補間
//   surface(binding: Binding, model: Model): Binding                   // ワープの制御点を球面に沿って生成
//   ease(binding: Binding): Binding                                     // 中間キーの値をゆるやかに
//   regenerate(binding: Binding, model: Model, range?: [number, number]): Binding   // ロックされたキーを残して作り直す
// Services に足すもの: audio, lipSync, autoBlink, bodyFollow, expressions, calibration, hotkeys, spout（OutputSink）
```

## 作るもの

- `services.ts` の STEP1 の項目を本物に差し替える。
- 下の完成条件を、MVP と同じ評価条件で確かめ、`docs/acceptance-step1.md` に残す。

1. かんたん/詳細の切り替え（状態はモードごとに保持）と「カスタム」表示
2. かんたんメッシュ（変形の細かさ）と、キー作成後の変形の転写
3. ワープと組み合わせキーの編集UI（詳細モード）
4. かんたんセットアップの拡張（曲面の顔の向き、曲線のまばたき、目 笑顔・眉・口の形、体の追従、斜め方向の合成）
5. 生成方式の追加（回転・曲面・なめらか）
6. 中間キーの編集
7. キーのロック
8. 選択範囲の再補間
9. 2Dパラメータ
10. パラメータによる不透明度の変化
11. 合成モード（乗算・スクリーン・加算）、PSD の合成モードの引き継ぎ、クリッピングの自動統合
12. 反転マスクと複数のマスク元
13. 標準パラメータの追加（目 笑顔、眉、口の形と横幅、頬染め、体）
14. ユーザー定義パラメータ（トラッキング・ホットキーへの割り当てを含む）
15. キャリブレーション（正面・目の閉じ・口の開き）
16. トラッキング簡易設定
17. 音量によるリップシンク（カメラの口との切り替えを含む）
18. 自動まばたき
19. 表情（作成、プリセット、1つずつの切り替え）
20. シーン
21. 背景プリセット
22. グローバルホットキー
23. 透過出力（Windows: Spout2）
24. 素材の差し替え（サイズ違いへの変形の転写）と PSD の再読み込み

## 作らないもの

STEP2の機能。

## 完了条件

- [ ] 24項目すべての確認結果が docs/acceptance-step1.md にある
- [ ] MVP の受け入れの項目が引き続き通る
