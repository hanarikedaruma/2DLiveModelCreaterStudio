# 33. 反転マスクと複数のマスク元

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | STEP1 / S1 部品 |
| 並行作業 | 同じ段階の 27〜41 と並行して作れる（触るフォルダは重ならない） |
| 担当の目安 | 画面 |
| 作業場所 | apps/desktop/src/modes/modeling/structure/MaskPanel.tsx |

## 目的

マスクの反転と、複数のマスク元を画面から設定できるようにする。

## 前提（このカードの時点ですでにあるもの）

レンダラーは、複数のマスク元の和と反転にすでに対応している（マスク元自身のマスクは掛けない）。MaskPanel は1つのマスク元のドロップダウンだけ。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### Part と StandardPartType（@app/schema）

```ts
export interface Part {
  id: Id;
  name: string;
  kind: 'image' | 'group';
  standardType: StandardPartType | null;   // 自由パーツは null
  assetId: Id | null;                      // image のみ
  meshId: Id | null;                       // image のみ
  parentId: Id | null;
  position: Vec2;                          // 初期値 {x: 0, y: 0}
  rotation: number;                        // 度。初期値 0
  scale: Vec2;                             // 初期値 {x: 1, y: 1}
  pivot: Vec2;                             // 回転・拡縮の中心（キャンバス座標）
  opacity: number;                         // 0..1
  blendMode: BlendMode;
  depth: number;                           // 奥行き。手前が正（-1..1 が目安）
  mask: { sourcePartIds: Id[]; inverted: boolean } | null;
  physicsId: Id | null;
  visible: boolean;
  locked: boolean;
}
export type StandardPartType =
  | 'face' | 'earL' | 'earR' | 'cheek'
  | 'eyeWhiteL' | 'irisL' | 'highlightL' | 'upperLidL' | 'lowerLidL' | 'eyeWholeL'
  | 'eyeWhiteR' | 'irisR' | 'highlightR' | 'upperLidR' | 'lowerLidR' | 'eyeWholeR'
  | 'browL' | 'browR'
  | 'upperLip' | 'lowerLip' | 'mouthInside' | 'teeth' | 'tongue' | 'mouthWhole'
  | 'frontHair' | 'sideHairL' | 'sideHairR' | 'backHair'
  | 'neck' | 'torso' | 'armL' | 'armR'
  // 変形グループ（かんたんセットアップが作る）
  | 'bodyRoot' | 'armRootL' | 'armRootR' | 'neckRoot' | 'headRoot'
  | 'faceGroup' | 'eyeGroupL' | 'eyeGroupR' | 'mouthGroup';
```

### ストアの契約（@app/contracts）

```ts
export interface Command { label: string; apply(project: Project): Project }   // 純粋関数
export interface ProjectStore {
  get(): Project;
  subscribe(listener: (project: Project) => void): () => void;
  dispatch(command: Command): void;                                          // 1回の Undo 単位
  transaction(label: string, run: (dispatch: (c: Command) => void) => void): void;   // まとめて1回の Undo
  undo(): void; redo(): void; canUndo(): boolean; canRedo(): boolean;
  load(project: Project): void;                                              // 履歴を消して置き換える
}
export interface EditorState {
  mode: ModeId;
  uiLevel: Record<ModeId, UiLevel>;
  selectedPartIds: string[];
  activeParameterIds: string[];        // 編集中のパラメータ（0〜2個）
  editorParamValues: ParamValues;      // モデリング中のプレビュー値（無いパラメータはデフォルト値）
}
export interface EditorStore { get(): EditorState; set(patch: Partial<EditorState>): void; subscribe(l: (s: EditorState) => void): () => void }
```

## 作るもの

- マスク元を複数選べる一覧（チェック）と、[反転]（範囲の外を表示）のチェック。
- 選べないもの: 自身と子孫、画像でないパーツ。
- 説明の文: 「複数選ぶと、どれかの範囲を表示します。反転すると、その外側を表示します」。

## 作らないもの

範囲の積・差（将来検討）。

## 完了条件

- [ ] 複数・反転の設定が保存され、描画に反映される
- [ ] 選べないパーツが出ない
- [ ] Undo できる
