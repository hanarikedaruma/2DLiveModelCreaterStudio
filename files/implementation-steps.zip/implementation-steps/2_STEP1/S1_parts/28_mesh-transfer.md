# 28. メッシュの密度と変形の転写

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | STEP1 / S1 部品 |
| 並行作業 | 同じ段階の 27〜41 と並行して作れる（触るフォルダは重ならない） |
| 担当の目安 | コア |
| 作業場所 | packages/core/src/mesh/transfer.ts、apps/desktop/src/modes/modeling/mesh/、apps/desktop/src/modes/modeling/structure/replaceAsset.ts |

## 目的

メッシュを作り直しても、既存の変形を新しいメッシュへ移せるようにする（MVPのリセットを置き換える）。

## 前提（このカードの時点ですでにあるもの）

MVPのメッシュ編集ツール（形が変わる操作で頂点のキーをリセットする）と、素材の差し替え（replaceAsset.ts）がある。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### Mesh（@app/schema）

```ts
export interface Mesh {
  id: Id;
  vertices: Vec2[];                // 基準状態の頂点（キャンバス座標）
  uvs: Vec2[];                     // 0..1（素材画像の中の位置）
  triangles: [number, number, number][];
  density: 'light' | 'standard' | 'smooth' | 'custom';
  edited: boolean;                 // 手で編集したか
}
```

### Binding と ParameterKey（@app/schema）

```ts
export type Channel = 'transform' | 'vertices' | 'warpPoints';
export interface TransformDelta { position: Vec2; rotation: number; scale: Vec2; opacity: number }
// position・rotation は加算、scale・opacity は倍率（1 = 変化なし）
export interface Binding {
  id: Id;
  target: { type: 'part' | 'mesh' | 'warp'; id: Id };   // transform → part、vertices → mesh、warpPoints → warp
  channel: Channel;
  parameterIds: Id[];              // 1 または 2
  keyValues: number[][];           // パラメータごとのキー位置（昇順。デフォルト値を必ず含む）
  keys: ParameterKey[];
  generation: 'linear' | 'depth' | 'rotate' | 'surface' | 'ease';
  divisions: number | null;        // 中間キーの分割数（自動なら null）
}
export interface ParameterKey {
  coords: number[];                // parameterIds と同じ順の値
  delta: TransformDelta | Vec2[];  // transform は TransformDelta、それ以外は頂点・制御点ごとの差分
  source: 'manual' | 'auto' | 'generated' | 'combined';
  locked: boolean;
}
```

### メッシュ生成の契約（@app/contracts）

```ts
export interface MeshGenerator {
  generate(alpha: ImageData, offset: Vec2, density: 'light' | 'standard' | 'smooth'):
    { vertices: Vec2[]; uvs: Vec2[]; triangles: [number, number, number][] };   // 頂点はキャンバス座標
}
```

### アプリの枠の差し込み口（apps/desktop/src/shell/api.ts）

```ts
export interface PanelDef { id: string; mode: ModeId; area: 'left' | 'right' | 'bottom'; title: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanel(def: PanelDef): void;
export interface SectionDef { id: string; panelId: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanelSection(def: SectionDef): void;      // パネルの中の <PanelSections panelId=… /> に入る
export function PanelSections(props: { panelId: string }): JSX.Element;
export function registerCenter(mode: 'studio' | 'animation', component: React.FC): void;
export function registerSetupScreen(component: React.FC): void;   // 素材が1つも無いとき中央に出す
export function registerMenuItem(item: { id: string; label: string; shortcut?: string; run(): void }): void;

export interface CanvasPointerEvent { canvasPoint: Vec2; screenPoint: Vec2; button: number; shiftKey: boolean; altKey: boolean; ctrlKey: boolean }
export interface CanvasTool {
  id: string; label: string; cursor?: string;
  onPointerDown?(e: CanvasPointerEvent): void; onPointerMove?(e: CanvasPointerEvent): void; onPointerUp?(e: CanvasPointerEvent): void;
  onKeyDown?(e: KeyboardEvent): void;
  drawOverlay?(ctx: CanvasRenderingContext2D, view: ViewTransform): void;
}
export function registerCanvasTool(tool: CanvasTool): void;        // 最初に登録したものが既定のツール
export function registerCanvasOverlay(id: string, draw: (ctx: CanvasRenderingContext2D, view: ViewTransform) => void): void;
export function useCanvas(): { view: ViewTransform; activeToolId: string; setActiveTool(id: string): void; requestRedraw(): void; lastDeformed(): DeformedModel | null; screenToCanvas(p: Vec2): Vec2 };

export function useServices(): Services;
export function useProject(): Project;
export function useDispatch(): (c: Command) => void;
export function useEditor(): [EditorState, (patch: Partial<EditorState>) => void];
export function useEnvironment(): [Environment, (patch: Partial<Environment>) => void];
export function useDialogs(): { confirm(message: string): Promise<boolean>; notify(message: string): void; prompt(message: string, initial?: string): Promise<string | null> };
export function emitAppEvent(name: string, payload?: unknown): void;
export function onAppEvent(name: string, listener: (payload: unknown) => void): () => void;
```

### ストアの契約（@app/contracts）

```ts
export interface Command { label: string; apply(project: Project): Project }   // 純粋関数
export interface ProjectStore {
  get(): Project;
  subscribe(listener: (project: Project) => void): () => void;
  dispatch(command: Command): void;                                          // 1回の Undo 単位
  transaction(label: string, run: (dispatch: (c: Command) => void) => void): void;   // まとめて1回の Undo
  undo(): void; redo(): void; canUndo(): boolean; canRedo(): boolean;
  load(project: Project): void;                                              // 履歴を消して置き換える
}
export interface EditorState {
  mode: ModeId;
  uiLevel: Record<ModeId, UiLevel>;
  selectedPartIds: string[];
  activeParameterIds: string[];        // 編集中のパラメータ（0〜2個）
  editorParamValues: ParamValues;      // モデリング中のプレビュー値（無いパラメータはデフォルト値）
}
export interface EditorStore { get(): EditorState; set(patch: Partial<EditorState>): void; subscribe(l: (s: EditorState) => void): () => void }
```

## 作るもの

- `transferPointDeltas(oldVertices: Vec2[], oldTriangles: [number, number, number][], newVertices: Vec2[], deltas: Vec2[]): Vec2[]`: 新しい頂点ごとに、旧メッシュ（基準状態）で含まれる三角形を探し、重心座標で旧い差分を補間する。どの三角形にも入らない点は、いちばん近い三角形の重心座標（0..1 に丸める）を使う。
- `transferMeshKeys(model, meshId, newMesh): Model`: そのメッシュを対象にする vertices バインディングの全キーを転写する。
- 変形の細かさ（「パーツの設定」パネルのセクション、画像パーツのとき）: 軽い / 標準 / なめらか。選ぶとメッシュを作り直して転写する（density を更新）。
- メッシュ編集ツールの頂点の追加・削除・自動生成を、リセットから転写に替える。確認の文は「変形を新しいメッシュへ移します」。
- 素材の差し替えでサイズが違うときも、リセットから転写に替える。
- どれも1つの transaction で、Undo できる。

## 作らないもの

PSD の再読み込み（別のカード）。

## 完了条件

- [ ] 同じメッシュへの転写で差分が変わらない
- [ ] 一様な平行移動の差分が、より細かいメッシュへ正しく移る
- [ ] 外側の点の扱い
- [ ] 密度の変更・頂点の追加と削除・差し替えで、見た目がほぼ変わらない
