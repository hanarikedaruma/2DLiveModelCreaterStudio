# 32. 合成モードとPSDの合成・クリッピング

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | STEP1 / S1 部品 |
| 並行作業 | 同じ段階の 27〜41 と並行して作れる（触るフォルダは重ならない） |
| 担当の目安 | 描画 |
| 作業場所 | packages/render/src/blend.ts、packages/io/src/import/、apps/desktop/src/modes/modeling/blend/、apps/desktop/src/modes/modeling/assets/ |

## 目的

乗算・スクリーン・加算で描けるようにし、PSD の合成モードを引き継ぎ、クリッピングを自動で統合する。

## 前提（このカードの時点ですでにあるもの）

レンダラーの合成は `blend.ts` の `applyBlend(gl, mode)` に集まっていて、今は normal だけ。取り込みは合成モードを sourceBlendMode に記録し、クリッピングなどを needsMerge で警告している。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### 基本の型（@app/schema）

```ts
export type Id = string;
export interface Vec2 { x: number; y: number }
export type BlendMode = 'normal' | 'multiply' | 'screen' | 'add';
export type ParameterGroupId = 'face' | 'eye' | 'brow' | 'mouth' | 'cheek' | 'body' | 'armL' | 'armR' | 'sway' | 'other';
export type ModeId = 'modeling' | 'animation' | 'studio';
export type UiLevel = 'easy' | 'detail';
export function newId(): string;   // ULID
```

### Asset（@app/schema）

```ts
export interface Asset {
  id: Id;
  path: string;                    // 例: assets/<id>.png
  hash: string;                    // png の SHA-256（16進）
  width: number; height: number;   // トリミング後のサイズ
  offset: Vec2;                    // トリミング後の左上のキャンバス座標
  canvasSize: { width: number; height: number };
  source: { kind: 'psd' | 'png'; file: string; layerName?: string; layerPath?: string[]; hidden?: boolean };
  sourceBlendMode: BlendMode;
  sourceOpacity: number;           // 0..1
}
```

### Part と StandardPartType（@app/schema）

```ts
export interface Part {
  id: Id;
  name: string;
  kind: 'image' | 'group';
  standardType: StandardPartType | null;   // 自由パーツは null
  assetId: Id | null;                      // image のみ
  meshId: Id | null;                       // image のみ
  parentId: Id | null;
  position: Vec2;                          // 初期値 {x: 0, y: 0}
  rotation: number;                        // 度。初期値 0
  scale: Vec2;                             // 初期値 {x: 1, y: 1}
  pivot: Vec2;                             // 回転・拡縮の中心（キャンバス座標）
  opacity: number;                         // 0..1
  blendMode: BlendMode;
  depth: number;                           // 奥行き。手前が正（-1..1 が目安）
  mask: { sourcePartIds: Id[]; inverted: boolean } | null;
  physicsId: Id | null;
  visible: boolean;
  locked: boolean;
}
export type StandardPartType =
  | 'face' | 'earL' | 'earR' | 'cheek'
  | 'eyeWhiteL' | 'irisL' | 'highlightL' | 'upperLidL' | 'lowerLidL' | 'eyeWholeL'
  | 'eyeWhiteR' | 'irisR' | 'highlightR' | 'upperLidR' | 'lowerLidR' | 'eyeWholeR'
  | 'browL' | 'browR'
  | 'upperLip' | 'lowerLip' | 'mouthInside' | 'teeth' | 'tongue' | 'mouthWhole'
  | 'frontHair' | 'sideHairL' | 'sideHairR' | 'backHair'
  | 'neck' | 'torso' | 'armL' | 'armR'
  // 変形グループ（かんたんセットアップが作る）
  | 'bodyRoot' | 'armRootL' | 'armRootR' | 'neckRoot' | 'headRoot'
  | 'faceGroup' | 'eyeGroupL' | 'eyeGroupR' | 'mouthGroup';
```

### 取り込み・保存の契約（@app/contracts）

```ts
export interface FileSystem {          // パスは / 区切りの絶対パス
  readText(path: string): Promise<string>; writeText(path: string, data: string): Promise<void>;
  readBinary(path: string): Promise<Uint8Array>; writeBinary(path: string, data: Uint8Array): Promise<void>;
  exists(path: string): Promise<boolean>; mkdir(path: string): Promise<void>;
  list(dir: string): Promise<string[]>; remove(path: string): Promise<void>; rename(from: string, to: string): Promise<void>;
}
export interface ImportedAsset { asset: Asset; png: Uint8Array }   // png はトリミング済み
export interface ImportWarning { kind: 'canvasMismatch' | 'noTransparency' | 'resolution' | 'needsMerge'; assetIds: string[]; layerNames: string[]; message: string }
export interface Importer { importFiles(files: { name: string; data: Uint8Array }[]): Promise<{ assets: ImportedAsset[]; warnings: ImportWarning[] }> }
export interface ProjectIO {
  save(dir: string, project: Project, assetPngs: Record<string, Uint8Array>): Promise<void>;
  load(dir: string): Promise<{ project: Project; assetPngs: Record<string, Uint8Array> }>;
}
export interface AutoSaver { start(dir: string): void; stop(): void; findRecoverable(dir: string): Promise<string | null> }
```

### アプリの枠の差し込み口（apps/desktop/src/shell/api.ts）

```ts
export interface PanelDef { id: string; mode: ModeId; area: 'left' | 'right' | 'bottom'; title: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanel(def: PanelDef): void;
export interface SectionDef { id: string; panelId: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanelSection(def: SectionDef): void;      // パネルの中の <PanelSections panelId=… /> に入る
export function PanelSections(props: { panelId: string }): JSX.Element;
export function registerCenter(mode: 'studio' | 'animation', component: React.FC): void;
export function registerSetupScreen(component: React.FC): void;   // 素材が1つも無いとき中央に出す
export function registerMenuItem(item: { id: string; label: string; shortcut?: string; run(): void }): void;

export interface CanvasPointerEvent { canvasPoint: Vec2; screenPoint: Vec2; button: number; shiftKey: boolean; altKey: boolean; ctrlKey: boolean }
export interface CanvasTool {
  id: string; label: string; cursor?: string;
  onPointerDown?(e: CanvasPointerEvent): void; onPointerMove?(e: CanvasPointerEvent): void; onPointerUp?(e: CanvasPointerEvent): void;
  onKeyDown?(e: KeyboardEvent): void;
  drawOverlay?(ctx: CanvasRenderingContext2D, view: ViewTransform): void;
}
export function registerCanvasTool(tool: CanvasTool): void;        // 最初に登録したものが既定のツール
export function registerCanvasOverlay(id: string, draw: (ctx: CanvasRenderingContext2D, view: ViewTransform) => void): void;
export function useCanvas(): { view: ViewTransform; activeToolId: string; setActiveTool(id: string): void; requestRedraw(): void; lastDeformed(): DeformedModel | null; screenToCanvas(p: Vec2): Vec2 };

export function useServices(): Services;
export function useProject(): Project;
export function useDispatch(): (c: Command) => void;
export function useEditor(): [EditorState, (patch: Partial<EditorState>) => void];
export function useEnvironment(): [Environment, (patch: Partial<Environment>) => void];
export function useDialogs(): { confirm(message: string): Promise<boolean>; notify(message: string): void; prompt(message: string, initial?: string): Promise<string | null> };
export function emitAppEvent(name: string, payload?: unknown): void;
export function onAppEvent(name: string, listener: (payload: unknown) => void): () => void;
```

## 作るもの

- `applyBlend`（乗算済みアルファ）: normal = (ONE, ONE_MINUS_SRC_ALPHA)、add = (ONE, ONE)、multiply = (DST_COLOR, ONE_MINUS_SRC_ALPHA)、screen = (ONE, ONE_MINUS_SRC_COLOR)。マスクのアルファは合成の前に掛ける。
- 取り込み: クリッピングされたレイヤーを、それぞれの合成モードと不透明度でクリップ先に重ね、クリップ先のアルファで切り抜いて1枚の素材にする（クリップ先の名前を使う）。needsMerge は、調整レイヤー・レイヤー効果・スマートオブジェクト・対応していない合成モードだけに出す。
- 割り当て: 画像パーツを作るときに blendMode = asset.sourceBlendMode にする。
- 合成モードの選択（「transform」のセクション）: 通常・乗算・スクリーン・加算。

## 作らないもの

そのほかの合成モード。

## 完了条件

- [ ] 4つの合成モードのピクセルのテスト（参照の式との差が ±3 以内）
- [ ] クリッピングの統合のテスト（PSD をテストの中で作る）
- [ ] 割り当てで合成モードが引き継がれる
