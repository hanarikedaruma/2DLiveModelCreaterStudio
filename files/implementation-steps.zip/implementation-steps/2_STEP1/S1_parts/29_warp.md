# 29. ワープ

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | STEP1 / S1 部品 |
| 並行作業 | 同じ段階の 27〜41 と並行して作れる（触るフォルダは重ならない） |
| 担当の目安 | コア |
| 作業場所 | packages/core/src/deform/warp.ts、packages/core/src/deform/space.ts、apps/desktop/src/modes/modeling/warp/ |

## 目的

グループに格子のワープを付け、子パーツをまとめて曲げられるようにする。

## 前提（このカードの時点ですでにあるもの）

変形パイプラインが `warp.ts` の `applyWarp(points, warp, delta)` を親グループごとに呼んでいる（今は何もしない）。KeyEditor は pointsEdit（{kind: 'warp'}）でワープの制御点を基準状態かキーに記録できる。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### パーツの変形と計算の順序

- パーツの変形は、点 p を `p' = position + pivot + R(rotation)·(scale ⊙ (p − pivot))` に動かす。R は y が下向きの座標で `[cos −sin; sin cos]`（正の角度で時計回り）。
- 実際に使う値: `position = Part.position + Δposition`、`rotation = Part.rotation + Δrotation`、`scale = Part.scale ⊙ Δscale`、`opacity = Part.opacity × Δopacity`（Δ はキーの合成結果）。
- 取り込み直後は position (0,0)・rotation 0・scale (1,1)。メッシュの頂点と pivot はキャンバス座標。
- 画像パーツの最終頂点は内側から外側へ求める。(1) メッシュの基準頂点 + 頂点の差分 → (2) 自身のパーツの変形 → (3) 親グループのワープ（あれば）→ (4) 親グループのパーツの変形 → ルートまで (3)(4) を繰り返す。
- 不透明度は、自身から親までの値をすべて掛け合わせる。

### Warp（@app/schema）

```ts
export interface Warp {
  id: Id;
  partId: Id;                      // ワープを付ける group パーツ
  columns: number; rows: number;   // 格子の分割数
  bounds: { x: number; y: number; width: number; height: number };   // キャンバス座標
  points: Vec2[];                  // (columns+1)×(rows+1) 個、行優先。基準状態の制御点
}
```

### Binding と ParameterKey（@app/schema）

```ts
export type Channel = 'transform' | 'vertices' | 'warpPoints';
export interface TransformDelta { position: Vec2; rotation: number; scale: Vec2; opacity: number }
// position・rotation は加算、scale・opacity は倍率（1 = 変化なし）
export interface Binding {
  id: Id;
  target: { type: 'part' | 'mesh' | 'warp'; id: Id };   // transform → part、vertices → mesh、warpPoints → warp
  channel: Channel;
  parameterIds: Id[];              // 1 または 2
  keyValues: number[][];           // パラメータごとのキー位置（昇順。デフォルト値を必ず含む）
  keys: ParameterKey[];
  generation: 'linear' | 'depth' | 'rotate' | 'surface' | 'ease';
  divisions: number | null;        // 中間キーの分割数（自動なら null）
}
export interface ParameterKey {
  coords: number[];                // parameterIds と同じ順の値
  delta: TransformDelta | Vec2[];  // transform は TransformDelta、それ以外は頂点・制御点ごとの差分
  source: 'manual' | 'auto' | 'generated' | 'combined';
  locked: boolean;
}
```

### キー編集の契約（@app/contracts）

```ts
export type TransformChange = { dPosition?: Vec2; dRotation?: number; scaleFactor?: Vec2; opacityFactor?: number; dPivot?: Vec2 };
export type PointsTarget = { kind: 'mesh'; meshId: string } | { kind: 'warp'; warpId: string };
export interface KeyEditor {
  // EditorState の activeParameterIds と editorParamValues に応じて、基準状態かキーを変えるコマンドを返す
  transformEdit(project: Project, editor: EditorState, partIds: string[], change: TransformChange): Command | 'needsKey';
  pointsEdit(project: Project, editor: EditorState, target: PointsTarget, moves: { index: number; d: Vec2 }[]): Command | 'needsKey';
  addKeyAtCurrentValue(project: Project, editor: EditorState, target: { partId: string } | PointsTarget): Command;
}
```

### アプリの枠の差し込み口（apps/desktop/src/shell/api.ts）

```ts
export interface PanelDef { id: string; mode: ModeId; area: 'left' | 'right' | 'bottom'; title: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanel(def: PanelDef): void;
export interface SectionDef { id: string; panelId: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanelSection(def: SectionDef): void;      // パネルの中の <PanelSections panelId=… /> に入る
export function PanelSections(props: { panelId: string }): JSX.Element;
export function registerCenter(mode: 'studio' | 'animation', component: React.FC): void;
export function registerSetupScreen(component: React.FC): void;   // 素材が1つも無いとき中央に出す
export function registerMenuItem(item: { id: string; label: string; shortcut?: string; run(): void }): void;

export interface CanvasPointerEvent { canvasPoint: Vec2; screenPoint: Vec2; button: number; shiftKey: boolean; altKey: boolean; ctrlKey: boolean }
export interface CanvasTool {
  id: string; label: string; cursor?: string;
  onPointerDown?(e: CanvasPointerEvent): void; onPointerMove?(e: CanvasPointerEvent): void; onPointerUp?(e: CanvasPointerEvent): void;
  onKeyDown?(e: KeyboardEvent): void;
  drawOverlay?(ctx: CanvasRenderingContext2D, view: ViewTransform): void;
}
export function registerCanvasTool(tool: CanvasTool): void;        // 最初に登録したものが既定のツール
export function registerCanvasOverlay(id: string, draw: (ctx: CanvasRenderingContext2D, view: ViewTransform) => void): void;
export function useCanvas(): { view: ViewTransform; activeToolId: string; setActiveTool(id: string): void; requestRedraw(): void; lastDeformed(): DeformedModel | null; screenToCanvas(p: Vec2): Vec2 };

export function useServices(): Services;
export function useProject(): Project;
export function useDispatch(): (c: Command) => void;
export function useEditor(): [EditorState, (patch: Partial<EditorState>) => void];
export function useEnvironment(): [Environment, (patch: Partial<Environment>) => void];
export function useDialogs(): { confirm(message: string): Promise<boolean>; notify(message: string): void; prompt(message: string, initial?: string): Promise<string | null> };
export function emitAppEvent(name: string, payload?: unknown): void;
export function onAppEvent(name: string, listener: (payload: unknown) => void): () => void;
```

### ストアの契約（@app/contracts）

```ts
export interface Command { label: string; apply(project: Project): Project }   // 純粋関数
export interface ProjectStore {
  get(): Project;
  subscribe(listener: (project: Project) => void): () => void;
  dispatch(command: Command): void;                                          // 1回の Undo 単位
  transaction(label: string, run: (dispatch: (c: Command) => void) => void): void;   // まとめて1回の Undo
  undo(): void; redo(): void; canUndo(): boolean; canRedo(): boolean;
  load(project: Project): void;                                              // 履歴を消して置き換える
}
export interface EditorState {
  mode: ModeId;
  uiLevel: Record<ModeId, UiLevel>;
  selectedPartIds: string[];
  activeParameterIds: string[];        // 編集中のパラメータ（0〜2個）
  editorParamValues: ParamValues;      // モデリング中のプレビュー値（無いパラメータはデフォルト値）
}
export interface EditorStore { get(): EditorState; set(patch: Partial<EditorState>): void; subscribe(l: (s: EditorState) => void): () => void }
```

## 作るもの

- `applyWarp`: 点 p について、u = (p.x − bounds.x) / bounds.width × columns、v = (p.y − bounds.y) / bounds.height × rows。セル i = floor(u) と j = floor(v) を 0..columns−1、0..rows−1 に丸め、s = u − i、t = v − j（範囲外の点では 0..1 を超えてよい。外へなめらかに延ばす）。4つの角の点（基準の points + delta）を双線形補間した位置へ動かす。
- `space.ts`: `pointsToModelSpace(model, deltas, partId, points)`（グループの点を、祖先の変形とワープを掛けたキャンバス上の位置にする）を作る。ツールの表示に使う。
- [ワープを追加]（詳細モード。「パーツの設定」のセクション、グループのとき）: bounds = 子孫の画像パーツの外接矩形（基準状態）に 5% の余白、分割は 4×4（2〜8 で変えられる）、points = 規則的な格子。[ワープを削除] も用意する（関係するバインディングも消す）。
- ワープ編集ツール（registerCanvasTool）: 格子を変形後の位置に描き、制御点のドラッグを keyEditor.pointsEdit({kind: 'warp'}) で記録する。'needsKey' の扱いはほかのツールと同じ。

## 作らないもの

曲面の生成（別のカード）。

## 完了条件

- [ ] 規則的な格子で恒等になる
- [ ] 全制御点の平行移動で子も同じだけ動く
- [ ] 双線形補間の値、範囲外での連続
- [ ] ワープの追加・編集・削除と Undo
