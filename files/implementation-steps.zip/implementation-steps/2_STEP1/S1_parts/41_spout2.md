# 41. Spout2出力

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | STEP1 / S1 部品 |
| 並行作業 | 同じ段階の 27〜41 と並行して作れる（触るフォルダは重ならない） |
| 担当の目安 | ネイティブ |
| 作業場所 | apps/desktop/src-tauri/src/output/、apps/desktop/src/output/spout/ |

## 目的

Windows で、背景を透過したまま OBS へ映像を渡せるようにする。

## 前提（このカードの時点ですでにあるもの）

スタジオの実行部に registerFrameSink がある（毎フレームの DeformedModel・view・背景が届く）。Environment.output に方式と解像度がある。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### 変形の契約（@app/contracts）

```ts
export interface DrawItem {
  partId: string; assetId: string;
  positions: Float32Array;         // 変形後の頂点（キャンバス座標）[x0, y0, x1, y1, ...]
  uvs: Float32Array;               // [u0, v0, ...]（0..1）
  indices: Uint32Array;
  opacity: number;                 // 親まで掛けた最終値
  blendMode: BlendMode;
  mask: { sourcePartIds: string[]; inverted: boolean } | null;
}
export interface DeformedModel {
  items: DrawItem[];               // 描画順（背面 → 前面）。非表示のパーツは含めない
  byPartId: Record<string, DrawItem>;
}
export interface DeformPipeline { deform(model: Model, deltas: TargetDeltas): DeformedModel }
```

### 描画の契約（@app/contracts）

```ts
export type Background = { type: 'transparent' } | { type: 'color'; color: string } | { type: 'image'; image: ImageBitmap };
export interface ViewTransform { scale: number; offset: Vec2 }   // 画面座標（CSSピクセル）= キャンバス座標 × scale + offset
export interface Renderer {
  init(canvas: HTMLCanvasElement): void;
  setTextures(images: Record<string, ImageBitmap>): void;       // assetId → 画像
  render(model: DeformedModel, view: ViewTransform, background: Background): void;
  dispose(): void;
}
```

### STEP1で増える契約（@app/contracts）

```ts
// TrackingFrame に足す任意の項目（無いときは undefined）
//   mouthForm?: number;  // -1..1（への字〜笑顔）
//   mouthWidth?: number; // -1..1（すぼめ〜横に開く）
//   browY?: number;      // -1..1（下げる〜上げる）

export interface AudioLevel { time: number; rmsDb: number }
export interface AudioSource {
  listDevices(): Promise<{ id: string; label: string }[]>;
  start(deviceId?: string): Promise<void>; stop(): void;
  onLevel(listener: (x: AudioLevel) => void): () => void;                                   // 10ms ごと
  onSamples(listener: (samples: Float32Array, sampleRate: number, time: number) => void): () => void;
}
export interface LipSyncProducer extends LayerProducer {   // id 'lipSync'
  configure(o: { mouthSource: 'max' | 'micOnly' | 'cameraOnly'; strength: 'low' | 'standard' | 'high'; silenceThresholdDb: number }): void;
  update(level: AudioLevel): void;
}
export interface AutoBlink { tick(now: number): { EyeOpenL: number; EyeOpenR: number } }
export interface BodyFollowProducer extends LayerProducer { setStrength(s: 'low' | 'standard' | 'high'): void }   // id 'bodyFollow'
export interface ExpressionController extends LayerProducer {   // id 'expression'
  apply(expressionId: string | null, now: number): void;        // null で解除。STEP1では1つだけ
  active(): string | null;
}
export type CalibrationStep = 'neutral' | 'eyesClosed' | 'mouthOpen';
export interface CalibrationService { capture(step: CalibrationStep, frames: TrackingFrame[]): void; result(): Environment['calibration']; reset(): void }
// TrackingLayerProducer に足すメソッド
//   setCalibration(c: Environment['calibration']): void
//   setPreset(p: 'stable' | 'standard' | 'large' | 'custom', custom?: { minCutoff: number; beta: number; gain: number; deadZone: number }): void
//   setEyeTracking(on: boolean): void   // off のときと外れたときは AutoBlink の値を使う
export interface HotkeyService { register(hotkey: Hotkey, handler: (phase: 'down' | 'up') => void): Promise<'ok' | 'conflict'>; unregisterAll(): Promise<void> }
export interface OutputSink {
  start(o: { width: number; height: number; fps: number }): Promise<void>;
  setTextures(pngs: Record<string, Uint8Array>): Promise<void>;
  submit(model: DeformedModel, view: ViewTransform, background: Background): void;
  stop(): Promise<void>;
}
// KeyGenerator に足すメソッド
//   rotate(binding: Binding, model: Model): Binding                    // 頂点・制御点をピボット中心の円弧で補間
//   surface(binding: Binding, model: Model): Binding                   // ワープの制御点を球面に沿って生成
//   ease(binding: Binding): Binding                                     // 中間キーの値をゆるやかに
//   regenerate(binding: Binding, model: Model, range?: [number, number]): Binding   // ロックされたキーを残して作り直す
// Services に足すもの: audio, lipSync, autoBlink, bodyFollow, expressions, calibration, hotkeys, spout（OutputSink）
```

### スタジオの実行部の差し込み口（apps/desktop/src/modes/studio/runtime.ts）

```ts
export function registerLayerProducer(p: LayerProducer): () => void;   // LayerProducer・FrameContext は @app/contracts
export interface StudioFrame { model: DeformedModel; view: ViewTransform; background: Background; params: ParamValues; now: number }
export function registerFrameSink(sink: (frame: StudioFrame) => void): () => void;
export function useStudioRuntime(): { running: boolean; status: 'tracking' | 'lost' | 'stopped'; lastFrame(): StudioFrame | null };
```

1フレームの処理: LAYER_ORDER の順に producer を呼び、呼ぶたびに mixedSoFar を更新する → mixer.mix → evaluator → pipeline → プレビューの renderer と、登録された sink へ渡す。

### Environment（@app/schema。PCごとの設定でプロジェクトの外に保存）

```ts
export interface Environment {
  cameraDeviceId: string | null;
  mirror: boolean;
  calibration: { neutral: { yaw: number; pitch: number; roll: number }; eyeClosed: { l: number; r: number }; mouthOpenMax: number } | null;
  microphoneDeviceId: string | null;
  silenceThreshold: number;        // dBFS
  trackingPreset: 'stable' | 'standard' | 'large' | 'custom';
  output: { method: 'window' | 'spout2'; width: number; height: number; fps: number };
  uiLevel: Record<ModeId, UiLevel>;
  lastProjectDir: string | null;
}
```

### アプリの枠の差し込み口（apps/desktop/src/shell/api.ts）

```ts
export interface PanelDef { id: string; mode: ModeId; area: 'left' | 'right' | 'bottom'; title: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanel(def: PanelDef): void;
export interface SectionDef { id: string; panelId: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanelSection(def: SectionDef): void;      // パネルの中の <PanelSections panelId=… /> に入る
export function PanelSections(props: { panelId: string }): JSX.Element;
export function registerCenter(mode: 'studio' | 'animation', component: React.FC): void;
export function registerSetupScreen(component: React.FC): void;   // 素材が1つも無いとき中央に出す
export function registerMenuItem(item: { id: string; label: string; shortcut?: string; run(): void }): void;

export interface CanvasPointerEvent { canvasPoint: Vec2; screenPoint: Vec2; button: number; shiftKey: boolean; altKey: boolean; ctrlKey: boolean }
export interface CanvasTool {
  id: string; label: string; cursor?: string;
  onPointerDown?(e: CanvasPointerEvent): void; onPointerMove?(e: CanvasPointerEvent): void; onPointerUp?(e: CanvasPointerEvent): void;
  onKeyDown?(e: KeyboardEvent): void;
  drawOverlay?(ctx: CanvasRenderingContext2D, view: ViewTransform): void;
}
export function registerCanvasTool(tool: CanvasTool): void;        // 最初に登録したものが既定のツール
export function registerCanvasOverlay(id: string, draw: (ctx: CanvasRenderingContext2D, view: ViewTransform) => void): void;
export function useCanvas(): { view: ViewTransform; activeToolId: string; setActiveTool(id: string): void; requestRedraw(): void; lastDeformed(): DeformedModel | null; screenToCanvas(p: Vec2): Vec2 };

export function useServices(): Services;
export function useProject(): Project;
export function useDispatch(): (c: Command) => void;
export function useEditor(): [EditorState, (patch: Partial<EditorState>) => void];
export function useEnvironment(): [Environment, (patch: Partial<Environment>) => void];
export function useDialogs(): { confirm(message: string): Promise<boolean>; notify(message: string): void; prompt(message: string, initial?: string): Promise<string | null> };
export function emitAppEvent(name: string, payload?: unknown): void;
export function onAppEvent(name: string, listener: (payload: unknown) => void): () => void;
```

## 作るもの

- Rust 側: wgpu（D3D11）で、決めた解像度の透過のテクスチャに描き、Spout2 SDK で送る（送り手の名前は「2D Liver」）。描画の規則は WebGL のレンダラーと同じにする（乗算済みアルファ、不透明度、マスク元のアルファの和と反転、通常・乗算・スクリーン・加算）。
- テクスチャ: setTextures で PNG を1回だけ送る（素材が変わったときに送り直す）。
- 毎フレームの送信: Tauri の IPC でバイナリを送る。形式は「品目数 → 品目ごとに partId の番号・assetId の番号・頂点数・positions（f32）・uvs（f32）・indices（u32）・opacity・blendMode・マスク元の番号の配列・inverted」と view・背景。
- JS 側: `createSpoutSink(): OutputSink` と、registerFrameSink で submit する sink。Environment.output.method が 'spout2' のときだけ動かす。
- 出力の設定（studioSettings のセクション）: 方式（ウィンドウ / Spout2）、解像度、fps。OBS の設定手順（Spout2 のプラグインを入れて追加する）を説明に出す。

## 作らないもの

macOS の Syphon、ブラウザソース、仮想カメラ。

## 完了条件

- [ ] OBS（Spout2 のプラグイン）で透過のまま受け取れる
- [ ] 1920×1080・60fps で送れる（基準PC）
- [ ] プレビューとの見た目の差が小さい（ピクセルの比較で ±3 以内が 99% 以上）
