# 27. かんたん/詳細の切り替え

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | STEP1 / S1 部品 |
| 並行作業 | 同じ段階の 27〜41 と並行して作れる（触るフォルダは重ならない） |
| 担当の目安 | 画面 |
| 作業場所 | apps/desktop/src/shell/level/、apps/desktop/src/shell/Header.tsx |

## 目的

かんたん/詳細の切り替えを使えるようにし、状態をモードごとに保持する。

## 前提（このカードの時点ですでにあるもの）

ヘッダーに非表示の切り替えボタンがあり、EditorState.uiLevel にモードごとの状態がある。パネルとセクションは level で出し分けられる。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### ストアの契約（@app/contracts）

```ts
export interface Command { label: string; apply(project: Project): Project }   // 純粋関数
export interface ProjectStore {
  get(): Project;
  subscribe(listener: (project: Project) => void): () => void;
  dispatch(command: Command): void;                                          // 1回の Undo 単位
  transaction(label: string, run: (dispatch: (c: Command) => void) => void): void;   // まとめて1回の Undo
  undo(): void; redo(): void; canUndo(): boolean; canRedo(): boolean;
  load(project: Project): void;                                              // 履歴を消して置き換える
}
export interface EditorState {
  mode: ModeId;
  uiLevel: Record<ModeId, UiLevel>;
  selectedPartIds: string[];
  activeParameterIds: string[];        // 編集中のパラメータ（0〜2個）
  editorParamValues: ParamValues;      // モデリング中のプレビュー値（無いパラメータはデフォルト値）
}
export interface EditorStore { get(): EditorState; set(patch: Partial<EditorState>): void; subscribe(l: (s: EditorState) => void): () => void }
```

### アプリの枠の差し込み口（apps/desktop/src/shell/api.ts）

```ts
export interface PanelDef { id: string; mode: ModeId; area: 'left' | 'right' | 'bottom'; title: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanel(def: PanelDef): void;
export interface SectionDef { id: string; panelId: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanelSection(def: SectionDef): void;      // パネルの中の <PanelSections panelId=… /> に入る
export function PanelSections(props: { panelId: string }): JSX.Element;
export function registerCenter(mode: 'studio' | 'animation', component: React.FC): void;
export function registerSetupScreen(component: React.FC): void;   // 素材が1つも無いとき中央に出す
export function registerMenuItem(item: { id: string; label: string; shortcut?: string; run(): void }): void;

export interface CanvasPointerEvent { canvasPoint: Vec2; screenPoint: Vec2; button: number; shiftKey: boolean; altKey: boolean; ctrlKey: boolean }
export interface CanvasTool {
  id: string; label: string; cursor?: string;
  onPointerDown?(e: CanvasPointerEvent): void; onPointerMove?(e: CanvasPointerEvent): void; onPointerUp?(e: CanvasPointerEvent): void;
  onKeyDown?(e: KeyboardEvent): void;
  drawOverlay?(ctx: CanvasRenderingContext2D, view: ViewTransform): void;
}
export function registerCanvasTool(tool: CanvasTool): void;        // 最初に登録したものが既定のツール
export function registerCanvasOverlay(id: string, draw: (ctx: CanvasRenderingContext2D, view: ViewTransform) => void): void;
export function useCanvas(): { view: ViewTransform; activeToolId: string; setActiveTool(id: string): void; requestRedraw(): void; lastDeformed(): DeformedModel | null; screenToCanvas(p: Vec2): Vec2 };

export function useServices(): Services;
export function useProject(): Project;
export function useDispatch(): (c: Command) => void;
export function useEditor(): [EditorState, (patch: Partial<EditorState>) => void];
export function useEnvironment(): [Environment, (patch: Partial<Environment>) => void];
export function useDialogs(): { confirm(message: string): Promise<boolean>; notify(message: string): void; prompt(message: string, initial?: string): Promise<string | null> };
export function emitAppEvent(name: string, payload?: unknown): void;
export function onAppEvent(name: string, listener: (payload: unknown) => void): () => void;
```

### STEP1で増える画面の部品（apps/desktop/src/shell）

```ts
// かんたん/詳細のプリセットに一致するかを調べる。一致しなければ 'custom'
export function presetOf<T extends Record<string, number>>(values: T, presets: Record<string, T>, tolerance?: number): string | 'custom';
// かんたんモードで、その項目だけ詳細を一時的に開く
export function DetailDisclosure(props: { label?: string; children: React.ReactNode }): JSX.Element;
```

### Environment（@app/schema。PCごとの設定でプロジェクトの外に保存）

```ts
export interface Environment {
  cameraDeviceId: string | null;
  mirror: boolean;
  calibration: { neutral: { yaw: number; pitch: number; roll: number }; eyeClosed: { l: number; r: number }; mouthOpenMax: number } | null;
  microphoneDeviceId: string | null;
  silenceThreshold: number;        // dBFS
  trackingPreset: 'stable' | 'standard' | 'large' | 'custom';
  output: { method: 'window' | 'spout2'; width: number; height: number; fps: number };
  uiLevel: Record<ModeId, UiLevel>;
  lastProjectDir: string | null;
}
```

## 作るもの

- 切り替えボタンを表示する。押すと、今のモードの uiLevel だけを変える。
- uiLevel を Environment.uiLevel に保存し、起動時に戻す。初期値はすべて 'easy'。
- 詳細からかんたんへ戻しても、詳細でだけ変えられる値は消さない（表示を隠すだけ）。
- かんたんのプリセットを選び直すときは、presetOf が 'custom' なら「個別に調整した値を上書きします」と確認する（各機能が使う確認の関数 `confirmOverwriteCustom()` をここに置く）。

## 作らないもの

各機能の詳細の画面（それぞれのカード）。

## 完了条件

- [ ] モデリングを詳細、スタジオをかんたんにしたまま、行き来しても保たれる
- [ ] 再起動しても状態が戻る
- [ ] confirmOverwriteCustom の確認が出る
