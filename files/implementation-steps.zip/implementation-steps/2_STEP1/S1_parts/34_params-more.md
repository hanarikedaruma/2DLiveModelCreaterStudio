# 34. 不透明度のキー・標準パラメータの追加・ユーザー定義パラメータ

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | STEP1 / S1 部品 |
| 並行作業 | 同じ段階の 27〜41 と並行して作れる（触るフォルダは重ならない） |
| 担当の目安 | 画面 |
| 作業場所 | apps/desktop/src/modes/modeling/opacity/、apps/desktop/src/modes/modeling/userParams/、apps/desktop/src/project/step1Params.ts |

## 目的

パラメータで不透明度を変えられるようにし、STEP1の標準パラメータとユーザー定義パラメータを使えるようにする。

## 前提（このカードの時点ですでにあるもの）

KeyEditor は transformEdit の opacityFactor をキーに記録できる。評価と変形は不透明度の倍率に対応している。プロジェクトを開いたときと新規作成のときに、アプリイベント 'projectLoaded' が出る。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### Parameter と ParameterGroup（@app/schema）

```ts
export interface ParameterGroup { id: ParameterGroupId; name: string }
export interface Parameter {
  id: Id;                          // 標準は 'FaceAngleX' など。ユーザー定義は任意の文字列
  name: string;                    // 表示名
  groupId: ParameterGroupId;
  min: number; max: number; default: number;
  standard: boolean;
}
```

### Binding と ParameterKey（@app/schema）

```ts
export type Channel = 'transform' | 'vertices' | 'warpPoints';
export interface TransformDelta { position: Vec2; rotation: number; scale: Vec2; opacity: number }
// position・rotation は加算、scale・opacity は倍率（1 = 変化なし）
export interface Binding {
  id: Id;
  target: { type: 'part' | 'mesh' | 'warp'; id: Id };   // transform → part、vertices → mesh、warpPoints → warp
  channel: Channel;
  parameterIds: Id[];              // 1 または 2
  keyValues: number[][];           // パラメータごとのキー位置（昇順。デフォルト値を必ず含む）
  keys: ParameterKey[];
  generation: 'linear' | 'depth' | 'rotate' | 'surface' | 'ease';
  divisions: number | null;        // 中間キーの分割数（自動なら null）
}
export interface ParameterKey {
  coords: number[];                // parameterIds と同じ順の値
  delta: TransformDelta | Vec2[];  // transform は TransformDelta、それ以外は頂点・制御点ごとの差分
  source: 'manual' | 'auto' | 'generated' | 'combined';
  locked: boolean;
}
```

### 標準パラメータ（STANDARD_PARAMETERS）

| id | 表示名 | group | min | max | default | フェーズ |
| --- | --- | --- | --- | --- | --- | --- |
| FaceAngleX | 顔 左右 | face | -30 | 30 | 0 | MVP |
| FaceAngleY | 顔 上下 | face | -30 | 30 | 0 | MVP |
| FaceAngleZ | 顔 傾き | face | -30 | 30 | 0 | MVP |
| EyeOpenL / EyeOpenR | 目 開閉 L / R | eye | 0 | 1 | 1 | MVP |
| EyeBallX / EyeBallY | 瞳 左右 / 上下 | eye | -1 | 1 | 0 | MVP |
| MouthOpen | 口 開閉 | mouth | 0 | 1 | 0 | MVP |
| EyeSmileL / EyeSmileR | 目 笑顔 L / R | eye | 0 | 1 | 0 | STEP1 |
| BrowYL / BrowYR | 眉 上下 L / R | brow | -1 | 1 | 0 | STEP1 |
| BrowFormL / BrowFormR | 眉 形 L / R（困り〜怒り） | brow | -1 | 1 | 0 | STEP1 |
| MouthForm | 口 形（への字〜笑顔） | mouth | -1 | 1 | 0 | STEP1 |
| MouthWidth | 口 横幅（すぼめ〜横に開く） | mouth | -1 | 1 | 0 | STEP1 |
| Cheek | 頬染め | cheek | 0 | 1 | 0 | STEP1 |
| BodyAngleX / BodyAngleY / BodyAngleZ | 体 左右 / 上下 / 傾き | body | -10 | 10 | 0 | STEP1 |
| Breath | 呼吸 | body | 0 | 1 | 0 | STEP2 |
| ArmL / ArmR | 腕 L / R | armL / armR | -1 | 1 | 0 | STEP2 |
| HairFront / HairSide / HairBack | 髪揺れ 前 / 横 / 後ろ | sway | -1 | 1 | 0 | STEP2 |

### スキーマの関数（@app/schema）

```ts
export const SCHEMA_VERSION = 1;
export function validateProject(json: unknown): Project;       // 失敗時は項目のパス付きのエラー
export function migrate(json: unknown): unknown;               // 古い版を現在の版へ変換
export function loadProjectJson(text: string): Project;        // 解析 → migrate → validate
export function createEmptyProject(name: string): Project;     // MVPの標準パラメータ入り
export function ensureStandardParameters(model: Model, phase: 'mvp' | 'step1' | 'step2'): Model;
```

### キー編集の契約（@app/contracts）

```ts
export type TransformChange = { dPosition?: Vec2; dRotation?: number; scaleFactor?: Vec2; opacityFactor?: number; dPivot?: Vec2 };
export type PointsTarget = { kind: 'mesh'; meshId: string } | { kind: 'warp'; warpId: string };
export interface KeyEditor {
  // EditorState の activeParameterIds と editorParamValues に応じて、基準状態かキーを変えるコマンドを返す
  transformEdit(project: Project, editor: EditorState, partIds: string[], change: TransformChange): Command | 'needsKey';
  pointsEdit(project: Project, editor: EditorState, target: PointsTarget, moves: { index: number; d: Vec2 }[]): Command | 'needsKey';
  addKeyAtCurrentValue(project: Project, editor: EditorState, target: { partId: string } | PointsTarget): Command;
}
```

### アプリの枠の差し込み口（apps/desktop/src/shell/api.ts）

```ts
export interface PanelDef { id: string; mode: ModeId; area: 'left' | 'right' | 'bottom'; title: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanel(def: PanelDef): void;
export interface SectionDef { id: string; panelId: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanelSection(def: SectionDef): void;      // パネルの中の <PanelSections panelId=… /> に入る
export function PanelSections(props: { panelId: string }): JSX.Element;
export function registerCenter(mode: 'studio' | 'animation', component: React.FC): void;
export function registerSetupScreen(component: React.FC): void;   // 素材が1つも無いとき中央に出す
export function registerMenuItem(item: { id: string; label: string; shortcut?: string; run(): void }): void;

export interface CanvasPointerEvent { canvasPoint: Vec2; screenPoint: Vec2; button: number; shiftKey: boolean; altKey: boolean; ctrlKey: boolean }
export interface CanvasTool {
  id: string; label: string; cursor?: string;
  onPointerDown?(e: CanvasPointerEvent): void; onPointerMove?(e: CanvasPointerEvent): void; onPointerUp?(e: CanvasPointerEvent): void;
  onKeyDown?(e: KeyboardEvent): void;
  drawOverlay?(ctx: CanvasRenderingContext2D, view: ViewTransform): void;
}
export function registerCanvasTool(tool: CanvasTool): void;        // 最初に登録したものが既定のツール
export function registerCanvasOverlay(id: string, draw: (ctx: CanvasRenderingContext2D, view: ViewTransform) => void): void;
export function useCanvas(): { view: ViewTransform; activeToolId: string; setActiveTool(id: string): void; requestRedraw(): void; lastDeformed(): DeformedModel | null; screenToCanvas(p: Vec2): Vec2 };

export function useServices(): Services;
export function useProject(): Project;
export function useDispatch(): (c: Command) => void;
export function useEditor(): [EditorState, (patch: Partial<EditorState>) => void];
export function useEnvironment(): [Environment, (patch: Partial<Environment>) => void];
export function useDialogs(): { confirm(message: string): Promise<boolean>; notify(message: string): void; prompt(message: string, initial?: string): Promise<string | null> };
export function emitAppEvent(name: string, payload?: unknown): void;
export function onAppEvent(name: string, listener: (payload: unknown) => void): () => void;
```

### ストアの契約（@app/contracts）

```ts
export interface Command { label: string; apply(project: Project): Project }   // 純粋関数
export interface ProjectStore {
  get(): Project;
  subscribe(listener: (project: Project) => void): () => void;
  dispatch(command: Command): void;                                          // 1回の Undo 単位
  transaction(label: string, run: (dispatch: (c: Command) => void) => void): void;   // まとめて1回の Undo
  undo(): void; redo(): void; canUndo(): boolean; canRedo(): boolean;
  load(project: Project): void;                                              // 履歴を消して置き換える
}
export interface EditorState {
  mode: ModeId;
  uiLevel: Record<ModeId, UiLevel>;
  selectedPartIds: string[];
  activeParameterIds: string[];        // 編集中のパラメータ（0〜2個）
  editorParamValues: ParamValues;      // モデリング中のプレビュー値（無いパラメータはデフォルト値）
}
export interface EditorStore { get(): EditorState; set(patch: Partial<EditorState>): void; subscribe(l: (s: EditorState) => void): () => void }
```

## 作るもの

- 不透明度（「transform」のセクション）: パラメータの編集中に「不透明度（このキー）」のスライダーを出し、keyEditor.transformEdit の opacityFactor で記録する（例: 頬染めを Cheek で出し入れ）。
- `step1Params.ts`: 'projectLoaded' で ensureStandardParameters(model, 'step1') を実行する（足りないものがあるときだけ）。
- パラメータパネルの結果の言葉に STEP1 の標準パラメータを足す（目 笑顔: なし / 笑顔、眉 上下: 下げる / – / 上げる、眉 形: 困り / – / 怒り、口 形: への字 / – / 笑顔、口 横幅: すぼめる / – / 横に開く、頬染め: なし / 染める、体: 頭と同じ言葉）。
- ユーザー定義パラメータ（パラメータパネルのセクション）: 一覧、[追加]（名前・最小・最大・デフォルト値・グループ）、編集、削除。削除はそのパラメータを使うバインディング・トラッキングのマッピング・表情の項目も消す（確認あり）。id は newId()、standard は false。

## 作らないもの

トラッキングやホットキーへの割り当ての画面（それぞれのカード）。

## 完了条件

- [ ] 不透明度をキーで変えられる
- [ ] 開いたプロジェクトに STEP1 の標準パラメータが足される
- [ ] ユーザー定義パラメータの追加・編集・削除と Undo
