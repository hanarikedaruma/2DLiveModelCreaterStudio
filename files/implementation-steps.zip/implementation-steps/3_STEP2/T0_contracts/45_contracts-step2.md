# 45. STEP2の契約の拡張

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | STEP2 / T0 契約の拡張 |
| 並行作業 | 直列 |
| 担当の目安 | 基盤 |
| 作業場所 | packages/contracts/src/、apps/desktop/src/modes/studio/runtime.ts、apps/desktop/src/services.ts |

## 目的

STEP2の部品が互いを待たずに作れるよう、増えるインターフェースと仮実装を先に用意する。

## 前提（このカードの時点ですでにあるもの）

STEP1が完成している。スタジオの実行部は producer の produce が返す1つのレイヤーを合成している。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### 合成の契約（@app/contracts）

```ts
export type LayerId = 'tracking' | 'bodyFollow' | 'expression' | 'animation' | 'lipSync' | 'periodic' | 'physics';
export const LAYER_ORDER: LayerId[] = ['tracking', 'bodyFollow', 'expression', 'animation', 'lipSync', 'periodic', 'physics'];
export interface Layer {
  id: LayerId;
  weight: number;                     // 0..1
  values: ParamValues;                // このレイヤーが担当するパラメータの値だけ
  blend?: Record<string, BlendOp>;    // パラメータごとの合成方法。無ければ override
}
export interface ParameterMixer { mix(parameters: Parameter[], layers: Layer[]): ParamValues }

// スタジオの1フレームの文脈。producer は LAYER_ORDER の順に呼ばれる
export interface FrameContext {
  now: number; dt: number;            // ミリ秒
  project: Project;
  mixedSoFar: ParamValues;            // それまでのレイヤーを合成した値
  flags: { lipSyncWeight: number; physicsActive: boolean };   // 前のレイヤーが後のレイヤーへ伝える値（初期値 1・true）
}
export interface LayerProducer { id: LayerId; produce(ctx: FrameContext): Layer | null }
```

### STEP1で増える契約（@app/contracts）

```ts
// TrackingFrame に足す任意の項目（無いときは undefined）
//   mouthForm?: number;  // -1..1（への字〜笑顔）
//   mouthWidth?: number; // -1..1（すぼめ〜横に開く）
//   browY?: number;      // -1..1（下げる〜上げる）

export interface AudioLevel { time: number; rmsDb: number }
export interface AudioSource {
  listDevices(): Promise<{ id: string; label: string }[]>;
  start(deviceId?: string): Promise<void>; stop(): void;
  onLevel(listener: (x: AudioLevel) => void): () => void;                                   // 10ms ごと
  onSamples(listener: (samples: Float32Array, sampleRate: number, time: number) => void): () => void;
}
export interface LipSyncProducer extends LayerProducer {   // id 'lipSync'
  configure(o: { mouthSource: 'max' | 'micOnly' | 'cameraOnly'; strength: 'low' | 'standard' | 'high'; silenceThresholdDb: number }): void;
  update(level: AudioLevel): void;
}
export interface AutoBlink { tick(now: number): { EyeOpenL: number; EyeOpenR: number } }
export interface BodyFollowProducer extends LayerProducer { setStrength(s: 'low' | 'standard' | 'high'): void }   // id 'bodyFollow'
export interface ExpressionController extends LayerProducer {   // id 'expression'
  apply(expressionId: string | null, now: number): void;        // null で解除。STEP1では1つだけ
  active(): string | null;
}
export type CalibrationStep = 'neutral' | 'eyesClosed' | 'mouthOpen';
export interface CalibrationService { capture(step: CalibrationStep, frames: TrackingFrame[]): void; result(): Environment['calibration']; reset(): void }
// TrackingLayerProducer に足すメソッド
//   setCalibration(c: Environment['calibration']): void
//   setPreset(p: 'stable' | 'standard' | 'large' | 'custom', custom?: { minCutoff: number; beta: number; gain: number; deadZone: number }): void
//   setEyeTracking(on: boolean): void   // off のときと外れたときは AutoBlink の値を使う
export interface HotkeyService { register(hotkey: Hotkey, handler: (phase: 'down' | 'up') => void): Promise<'ok' | 'conflict'>; unregisterAll(): Promise<void> }
export interface OutputSink {
  start(o: { width: number; height: number; fps: number }): Promise<void>;
  setTextures(pngs: Record<string, Uint8Array>): Promise<void>;
  submit(model: DeformedModel, view: ViewTransform, background: Background): void;
  stop(): Promise<void>;
}
// KeyGenerator に足すメソッド
//   rotate(binding: Binding, model: Model): Binding                    // 頂点・制御点をピボット中心の円弧で補間
//   surface(binding: Binding, model: Model): Binding                   // ワープの制御点を球面に沿って生成
//   ease(binding: Binding): Binding                                     // 中間キーの値をゆるやかに
//   regenerate(binding: Binding, model: Model, range?: [number, number]): Binding   // ロックされたキーを残して作り直す
// Services に足すもの: audio, lipSync, autoBlink, bodyFollow, expressions, calibration, hotkeys, spout（OutputSink）
```

### スタジオの実行部の差し込み口（apps/desktop/src/modes/studio/runtime.ts）

```ts
export function registerLayerProducer(p: LayerProducer): () => void;   // LayerProducer・FrameContext は @app/contracts
export interface StudioFrame { model: DeformedModel; view: ViewTransform; background: Background; params: ParamValues; now: number }
export function registerFrameSink(sink: (frame: StudioFrame) => void): () => void;
export function useStudioRuntime(): { running: boolean; status: 'tracking' | 'lost' | 'stopped'; lastFrame(): StudioFrame | null };
```

1フレームの処理: LAYER_ORDER の順に producer を呼び、呼ぶたびに mixedSoFar を更新する → mixer.mix → evaluator → pipeline → プレビューの renderer と、登録された sink へ渡す。

### サービスのまとめ（@app/contracts）

```ts
export interface Services {
  store: ProjectStore; editor: EditorStore; assets: AssetRepository; fs: FileSystem;
  evaluator: BindingEvaluator; pipeline: DeformPipeline; mixer: ParameterMixer; createRenderer(): Renderer;
  meshGenerator: MeshGenerator; keyGenerator: KeyGenerator; autoSetup: AutoSetup; keyEditor: KeyEditor;
  importer: Importer; io: ProjectIO; autoSaver: AutoSaver;
  tracking: TrackingSource; trackingLayer: TrackingLayerProducer;
}
```

## 作るもの

- 下の「STEP2で増える契約」を `@app/contracts` に足す。
- `LayerProducer.produce` の戻り値を `Layer | Layer[] | null` に広げ、runtime.ts を配列も受け取れるように直す（同じ id のレイヤーは配列の順に合成）。既存の producer は直さなくてよい。
- 仮実装: FakeAnimationPlayer（何も出さない）、FakePeriodic（何も出さない）、FakePhysics（何も出さない）、FakeVowels（いつも closed）。ExpressionController の仮実装に toggle・actives を足す。
- Services に animations・periodic・physics・vowels を足し、`services.ts` で仮実装を入れる。

### STEP2で増える契約（@app/contracts）

```ts
// LayerProducer.produce は複数のレイヤーを返せるようになる（同じ id は配列の順に合成）
//   produce(ctx: FrameContext): Layer | Layer[] | null
export interface AnimationPlayer extends LayerProducer {   // id 'animation'。ctx.flags を設定する
  play(animationId: string, now: number): void;
  stop(animationId: string, now: number): void;
  stopAll(now: number): void;
  playing(): string[];
}
export interface PeriodicPlayer extends LayerProducer { setActive(animationIds: string[]): void }   // id 'periodic'
export interface PhysicsEngine extends LayerProducer { reset(): void }                             // id 'physics'
export interface VowelEstimator { estimate(samples: Float32Array, sampleRate: number): { closed: number; a: number; i: number; u: number; e: number; o: number } }   // 合計 1
// ExpressionController に足すメソッド（複数の同時適用）
//   toggle(expressionId: string, now: number): void
//   actives(): string[]           // 適用した順
// Services に足すもの: animations（AnimationPlayer）, periodic, physics, vowels
```

## 作らないもの

各部品の本物（T1のカード）。

## 完了条件

- [ ] 型検査が通り、これまでのテストがすべて通ったまま
- [ ] 配列を返す producer のテスト（runtime）
