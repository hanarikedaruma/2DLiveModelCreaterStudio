# 51. 母音のリップシンク

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | STEP2 / T1 部品 |
| 並行作業 | 同じ段階の 46〜53 と並行して作れる（触るフォルダは重ならない） |
| 担当の目安 | 入出力 |
| 作業場所 | packages/audio/src/vowel.ts、packages/audio/src/lipsync.ts、apps/desktop/src/modes/modeling/vowels/ |

## 目的

あいうえおの口の形を、音声から推定して口の形と横幅に反映する。

## 前提（このカードの時点ですでにあるもの）

STEP1の音量のリップシンク（createLipSyncProducer。MouthOpen を出す）と AudioSource（onSamples）がある。model.lipSync.vowels がある（空）。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### LipSync（@app/schema）

```ts
export interface LipSync {
  mouthSource: 'max' | 'micOnly' | 'cameraOnly';
  strength: 'low' | 'standard' | 'high';
  vowels: { vowel: 'closed' | 'a' | 'i' | 'u' | 'e' | 'o'; values: Record<Id, number> }[];   // STEP2で使う
}
```

### STEP1で増える契約（@app/contracts）

```ts
// TrackingFrame に足す任意の項目（無いときは undefined）
//   mouthForm?: number;  // -1..1（への字〜笑顔）
//   mouthWidth?: number; // -1..1（すぼめ〜横に開く）
//   browY?: number;      // -1..1（下げる〜上げる）

export interface AudioLevel { time: number; rmsDb: number }
export interface AudioSource {
  listDevices(): Promise<{ id: string; label: string }[]>;
  start(deviceId?: string): Promise<void>; stop(): void;
  onLevel(listener: (x: AudioLevel) => void): () => void;                                   // 10ms ごと
  onSamples(listener: (samples: Float32Array, sampleRate: number, time: number) => void): () => void;
}
export interface LipSyncProducer extends LayerProducer {   // id 'lipSync'
  configure(o: { mouthSource: 'max' | 'micOnly' | 'cameraOnly'; strength: 'low' | 'standard' | 'high'; silenceThresholdDb: number }): void;
  update(level: AudioLevel): void;
}
export interface AutoBlink { tick(now: number): { EyeOpenL: number; EyeOpenR: number } }
export interface BodyFollowProducer extends LayerProducer { setStrength(s: 'low' | 'standard' | 'high'): void }   // id 'bodyFollow'
export interface ExpressionController extends LayerProducer {   // id 'expression'
  apply(expressionId: string | null, now: number): void;        // null で解除。STEP1では1つだけ
  active(): string | null;
}
export type CalibrationStep = 'neutral' | 'eyesClosed' | 'mouthOpen';
export interface CalibrationService { capture(step: CalibrationStep, frames: TrackingFrame[]): void; result(): Environment['calibration']; reset(): void }
// TrackingLayerProducer に足すメソッド
//   setCalibration(c: Environment['calibration']): void
//   setPreset(p: 'stable' | 'standard' | 'large' | 'custom', custom?: { minCutoff: number; beta: number; gain: number; deadZone: number }): void
//   setEyeTracking(on: boolean): void   // off のときと外れたときは AutoBlink の値を使う
export interface HotkeyService { register(hotkey: Hotkey, handler: (phase: 'down' | 'up') => void): Promise<'ok' | 'conflict'>; unregisterAll(): Promise<void> }
export interface OutputSink {
  start(o: { width: number; height: number; fps: number }): Promise<void>;
  setTextures(pngs: Record<string, Uint8Array>): Promise<void>;
  submit(model: DeformedModel, view: ViewTransform, background: Background): void;
  stop(): Promise<void>;
}
// KeyGenerator に足すメソッド
//   rotate(binding: Binding, model: Model): Binding                    // 頂点・制御点をピボット中心の円弧で補間
//   surface(binding: Binding, model: Model): Binding                   // ワープの制御点を球面に沿って生成
//   ease(binding: Binding): Binding                                     // 中間キーの値をゆるやかに
//   regenerate(binding: Binding, model: Model, range?: [number, number]): Binding   // ロックされたキーを残して作り直す
// Services に足すもの: audio, lipSync, autoBlink, bodyFollow, expressions, calibration, hotkeys, spout（OutputSink）
```

### STEP2で増える契約（@app/contracts）

```ts
// LayerProducer.produce は複数のレイヤーを返せるようになる（同じ id は配列の順に合成）
//   produce(ctx: FrameContext): Layer | Layer[] | null
export interface AnimationPlayer extends LayerProducer {   // id 'animation'。ctx.flags を設定する
  play(animationId: string, now: number): void;
  stop(animationId: string, now: number): void;
  stopAll(now: number): void;
  playing(): string[];
}
export interface PeriodicPlayer extends LayerProducer { setActive(animationIds: string[]): void }   // id 'periodic'
export interface PhysicsEngine extends LayerProducer { reset(): void }                             // id 'physics'
export interface VowelEstimator { estimate(samples: Float32Array, sampleRate: number): { closed: number; a: number; i: number; u: number; e: number; o: number } }   // 合計 1
// ExpressionController に足すメソッド（複数の同時適用）
//   toggle(expressionId: string, now: number): void
//   actives(): string[]           // 適用した順
// Services に足すもの: animations（AnimationPlayer）, periodic, physics, vowels
```

### 標準の合成ルール

| パラメータ | 表情 | アニメーション | リップシンク | 周期 |
| --- | --- | --- | --- | --- |
| 顔・体の角度 | add | override（遷移の blendMode が addToTracking なら add） | – | add |
| 目 開閉 | multiply（例: 笑顔 0.6、ウィンク 0） | override | – | – |
| 目 笑顔・頬染め | override | override | – | – |
| 眉 | add | override | – | – |
| 口 開閉 | add | override | max | – |
| 口 形・横幅 | override | override | override（音量に応じた重み） | – |

トラッキングと体の追従は担当するパラメータを override、物理演算は揺れもののパラメータを override で合成する。

### アプリの枠の差し込み口（apps/desktop/src/shell/api.ts）

```ts
export interface PanelDef { id: string; mode: ModeId; area: 'left' | 'right' | 'bottom'; title: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanel(def: PanelDef): void;
export interface SectionDef { id: string; panelId: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanelSection(def: SectionDef): void;      // パネルの中の <PanelSections panelId=… /> に入る
export function PanelSections(props: { panelId: string }): JSX.Element;
export function registerCenter(mode: 'studio' | 'animation', component: React.FC): void;
export function registerSetupScreen(component: React.FC): void;   // 素材が1つも無いとき中央に出す
export function registerMenuItem(item: { id: string; label: string; shortcut?: string; run(): void }): void;

export interface CanvasPointerEvent { canvasPoint: Vec2; screenPoint: Vec2; button: number; shiftKey: boolean; altKey: boolean; ctrlKey: boolean }
export interface CanvasTool {
  id: string; label: string; cursor?: string;
  onPointerDown?(e: CanvasPointerEvent): void; onPointerMove?(e: CanvasPointerEvent): void; onPointerUp?(e: CanvasPointerEvent): void;
  onKeyDown?(e: KeyboardEvent): void;
  drawOverlay?(ctx: CanvasRenderingContext2D, view: ViewTransform): void;
}
export function registerCanvasTool(tool: CanvasTool): void;        // 最初に登録したものが既定のツール
export function registerCanvasOverlay(id: string, draw: (ctx: CanvasRenderingContext2D, view: ViewTransform) => void): void;
export function useCanvas(): { view: ViewTransform; activeToolId: string; setActiveTool(id: string): void; requestRedraw(): void; lastDeformed(): DeformedModel | null; screenToCanvas(p: Vec2): Vec2 };

export function useServices(): Services;
export function useProject(): Project;
export function useDispatch(): (c: Command) => void;
export function useEditor(): [EditorState, (patch: Partial<EditorState>) => void];
export function useEnvironment(): [Environment, (patch: Partial<Environment>) => void];
export function useDialogs(): { confirm(message: string): Promise<boolean>; notify(message: string): void; prompt(message: string, initial?: string): Promise<string | null> };
export function emitAppEvent(name: string, payload?: unknown): void;
export function onAppEvent(name: string, listener: (payload: unknown) => void): () => void;
```

### ストアの契約（@app/contracts）

```ts
export interface Command { label: string; apply(project: Project): Project }   // 純粋関数
export interface ProjectStore {
  get(): Project;
  subscribe(listener: (project: Project) => void): () => void;
  dispatch(command: Command): void;                                          // 1回の Undo 単位
  transaction(label: string, run: (dispatch: (c: Command) => void) => void): void;   // まとめて1回の Undo
  undo(): void; redo(): void; canUndo(): boolean; canRedo(): boolean;
  load(project: Project): void;                                              // 履歴を消して置き換える
}
export interface EditorState {
  mode: ModeId;
  uiLevel: Record<ModeId, UiLevel>;
  selectedPartIds: string[];
  activeParameterIds: string[];        // 編集中のパラメータ（0〜2個）
  editorParamValues: ParamValues;      // モデリング中のプレビュー値（無いパラメータはデフォルト値）
}
export interface EditorStore { get(): EditorState; set(patch: Partial<EditorState>): void; subscribe(l: (s: EditorState) => void): () => void }
```

## 作るもの

- `createVowelEstimator(): VowelEstimator`: 20ms の窓ごとに LPC（次数 12 程度）で第1・第2フォルマントを求め、母音ごとの代表値との距離から確率に直す（合計 1）。無音（しきい値以下）は closed。代表値は成人の平均で始め、キャリブレーションは行わない。
- lipsync.ts を拡張する: onSamples を推定に回し、母音の確率で model.lipSync.vowels の values を重み付き平均した MouthForm・MouthWidth を出す（blend override、weight = 開きの値。音量が小さいほど表情の口の形が残る）。MouthOpen は母音の values の MouthOpen と音量の開きの小さい方。遅延は 100ms 以下。
- 母音の形の登録（モデリングの「母音」パネル）: 閉じる・あ・い・う・え・お を、口のパラメータ（MouthOpen・MouthForm・MouthWidth）を動かして登録する。[標準の形で作る] で下表の値を入れる。

| 母音 | MouthOpen | MouthWidth | MouthForm |
| --- | --- | --- | --- |
| 閉じる | 0 | 0 | 0 |
| あ | 1.0 | 0.3 | 0 |
| い | 0.3 | 1.0 | 0.2 |
| う | 0.3 | −1.0 | 0 |
| え | 0.6 | 0.7 | 0 |
| お | 0.6 | −0.7 | 0 |

## 作らないもの

話者ごとの母音のキャリブレーション。

## 完了条件

- [ ] 合成した母音の音（フォルマントを持つ信号）で、母音が正しく選ばれる
- [ ] 無音で closed
- [ ] 母音の形の登録と Undo
- [ ] 遅延 100ms 以下（計測の表示で確認）
