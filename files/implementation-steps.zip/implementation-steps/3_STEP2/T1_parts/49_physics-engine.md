# 49. 物理演算

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | STEP2 / T1 部品 |
| 並行作業 | 同じ段階の 46〜53 と並行して作れる（触るフォルダは重ならない） |
| 担当の目安 | コア |
| 作業場所 | packages/core/src/physics/ |

## 目的

頭と体の動きから、髪などの揺れを計算して揺れパラメータに出す。

## 前提（このカードの時点ですでにあるもの）

スタジオの実行部は producer を LAYER_ORDER の最後に物理を呼び、ctx.mixedSoFar（それまでの合成結果）と ctx.flags.physicsActive を渡す。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### Physics（@app/schema）

```ts
export interface Physics {
  id: Id; partId: Id;              // 根元の位置はこのパーツの pivot
  preset: 'hair' | 'cloth' | 'ribbon' | 'accessory';
  strength: number;                // 0..1（かんたん設定の「揺れ方」）
  direction: 'horizontal' | 'vertical' | 'both';
  length: number;                  // px
  spring: number; damping: number; gravity: number; inertia: number; range: number;
  inputs: { parameterId: Id; weight: number }[];
  outputParameterId: Id;
}
```

### Parameter と ParameterGroup（@app/schema）

```ts
export interface ParameterGroup { id: ParameterGroupId; name: string }
export interface Parameter {
  id: Id;                          // 標準は 'FaceAngleX' など。ユーザー定義は任意の文字列
  name: string;                    // 表示名
  groupId: ParameterGroupId;
  min: number; max: number; default: number;
  standard: boolean;
}
```

### 合成の契約（@app/contracts）

```ts
export type LayerId = 'tracking' | 'bodyFollow' | 'expression' | 'animation' | 'lipSync' | 'periodic' | 'physics';
export const LAYER_ORDER: LayerId[] = ['tracking', 'bodyFollow', 'expression', 'animation', 'lipSync', 'periodic', 'physics'];
export interface Layer {
  id: LayerId;
  weight: number;                     // 0..1
  values: ParamValues;                // このレイヤーが担当するパラメータの値だけ
  blend?: Record<string, BlendOp>;    // パラメータごとの合成方法。無ければ override
}
export interface ParameterMixer { mix(parameters: Parameter[], layers: Layer[]): ParamValues }

// スタジオの1フレームの文脈。producer は LAYER_ORDER の順に呼ばれる
export interface FrameContext {
  now: number; dt: number;            // ミリ秒
  project: Project;
  mixedSoFar: ParamValues;            // それまでのレイヤーを合成した値
  flags: { lipSyncWeight: number; physicsActive: boolean };   // 前のレイヤーが後のレイヤーへ伝える値（初期値 1・true）
}
export interface LayerProducer { id: LayerId; produce(ctx: FrameContext): Layer | null }
```

### STEP2で増える契約（@app/contracts）

```ts
// LayerProducer.produce は複数のレイヤーを返せるようになる（同じ id は配列の順に合成）
//   produce(ctx: FrameContext): Layer | Layer[] | null
export interface AnimationPlayer extends LayerProducer {   // id 'animation'。ctx.flags を設定する
  play(animationId: string, now: number): void;
  stop(animationId: string, now: number): void;
  stopAll(now: number): void;
  playing(): string[];
}
export interface PeriodicPlayer extends LayerProducer { setActive(animationIds: string[]): void }   // id 'periodic'
export interface PhysicsEngine extends LayerProducer { reset(): void }                             // id 'physics'
export interface VowelEstimator { estimate(samples: Float32Array, sampleRate: number): { closed: number; a: number; i: number; u: number; e: number; o: number } }   // 合計 1
// ExpressionController に足すメソッド（複数の同時適用）
//   toggle(expressionId: string, now: number): void
//   actives(): string[]           // 適用した順
// Services に足すもの: animations（AnimationPlayer）, periodic, physics, vowels
```

## 作るもの

- `createPhysicsEngine(): PhysicsEngine`（id 'physics'）。
- project.physics の項目ごとに振り子を1つ持つ。入力 x = Σ(inputs の値 × weight)。入力の変化が根元の動きになる。
- 運動: 角度 θ と角速度 ω。加速度 = −spring·θ − damping·ω − inertia·(入力の加速度) + gravity·(重力の向きの成分)。固定の 1/120 秒で積分し（フレームの時間に合わせて回数を変える。1フレームの最大は8回）、θ を ±range に丸める。
- direction: horizontal は左右だけ、vertical は上下だけ、both は2つの振り子を持ち、出力は左右を使う。
- 出力: outputParameterId に θ / range（−1..1）を、blend override、weight 1 で出す。
- strength（0..1）は spring と damping を弱めて揺れを大きくする（strength 1 で spring × 0.6、damping × 0.6）。
- ctx.flags.physicsActive が false の間は値を出さず（null）、状態は保つ。reset() で全部を止める。
- 入力が無い項目の既定: FaceAngleX 0.7、BodyAngleX 0.3（horizontal）、FaceAngleY 0.7（vertical）。

## 作らないもの

物理の設定の画面（別のカード）。

## 完了条件

- [ ] 入力を急に動かすと揺れて、ゆっくり止まる
- [ ] range で頭打ちになる
- [ ] フレームの時間が変わっても結果がほぼ同じ
- [ ] physicsActive が false の間は出さない
