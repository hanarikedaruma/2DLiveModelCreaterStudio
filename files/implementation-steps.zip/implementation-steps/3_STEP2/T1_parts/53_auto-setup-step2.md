# 53. 呼吸・腕の標準パラメータと自動セットアップ

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | STEP2 / T1 部品 |
| 並行作業 | 同じ段階の 46〜53 と並行して作れる（触るフォルダは重ならない） |
| 担当の目安 | コア |
| 作業場所 | packages/core/src/setup/、apps/desktop/src/project/step2Params.ts |

## 目的

呼吸と腕の動きのたたき台を、かんたんセットアップで自動で作る。

## 前提（このカードの時点ですでにあるもの）

かんたんセットアップ（MVP と STEP1 の規則）がある。プロジェクトを開いたときと新規作成のときに 'projectLoaded' が出る。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### 座標と値の約束

- 座標はキャンバス（元のPSD・PNG）のピクセル。原点は左上、x は右、y は下が正。
- 回転は度。画面上の時計回りが正。
- L / R はキャラクター自身から見た左右。画面では L が右側に描かれる。
- FaceAngleX はキャラクターが画面の右を向くと正、FaceAngleY は上を向くと正、FaceAngleZ は時計回りが正。EyeBallX は画面の右を見ると正、EyeBallY は上を見ると正。
- 基準状態 = 素材を配置しただけの状態 = 全パラメータがデフォルト値の状態。素材は「目を開け、口を閉じた」状態で描かれている前提。
- キーは基準状態からの差分。位置・回転・頂点は加算、拡縮・不透明度は倍率（1 = 変化なし）。

### パーツの変形と計算の順序

- パーツの変形は、点 p を `p' = position + pivot + R(rotation)·(scale ⊙ (p − pivot))` に動かす。R は y が下向きの座標で `[cos −sin; sin cos]`（正の角度で時計回り）。
- 実際に使う値: `position = Part.position + Δposition`、`rotation = Part.rotation + Δrotation`、`scale = Part.scale ⊙ Δscale`、`opacity = Part.opacity × Δopacity`（Δ はキーの合成結果）。
- 取り込み直後は position (0,0)・rotation 0・scale (1,1)。メッシュの頂点と pivot はキャンバス座標。
- 画像パーツの最終頂点は内側から外側へ求める。(1) メッシュの基準頂点 + 頂点の差分 → (2) 自身のパーツの変形 → (3) 親グループのワープ（あれば）→ (4) 親グループのパーツの変形 → ルートまで (3)(4) を繰り返す。
- 不透明度は、自身から親までの値をすべて掛け合わせる。

### Part と StandardPartType（@app/schema）

```ts
export interface Part {
  id: Id;
  name: string;
  kind: 'image' | 'group';
  standardType: StandardPartType | null;   // 自由パーツは null
  assetId: Id | null;                      // image のみ
  meshId: Id | null;                       // image のみ
  parentId: Id | null;
  position: Vec2;                          // 初期値 {x: 0, y: 0}
  rotation: number;                        // 度。初期値 0
  scale: Vec2;                             // 初期値 {x: 1, y: 1}
  pivot: Vec2;                             // 回転・拡縮の中心（キャンバス座標）
  opacity: number;                         // 0..1
  blendMode: BlendMode;
  depth: number;                           // 奥行き。手前が正（-1..1 が目安）
  mask: { sourcePartIds: Id[]; inverted: boolean } | null;
  physicsId: Id | null;
  visible: boolean;
  locked: boolean;
}
export type StandardPartType =
  | 'face' | 'earL' | 'earR' | 'cheek'
  | 'eyeWhiteL' | 'irisL' | 'highlightL' | 'upperLidL' | 'lowerLidL' | 'eyeWholeL'
  | 'eyeWhiteR' | 'irisR' | 'highlightR' | 'upperLidR' | 'lowerLidR' | 'eyeWholeR'
  | 'browL' | 'browR'
  | 'upperLip' | 'lowerLip' | 'mouthInside' | 'teeth' | 'tongue' | 'mouthWhole'
  | 'frontHair' | 'sideHairL' | 'sideHairR' | 'backHair'
  | 'neck' | 'torso' | 'armL' | 'armR'
  // 変形グループ（かんたんセットアップが作る）
  | 'bodyRoot' | 'armRootL' | 'armRootR' | 'neckRoot' | 'headRoot'
  | 'faceGroup' | 'eyeGroupL' | 'eyeGroupR' | 'mouthGroup';
```

### Binding と ParameterKey（@app/schema）

```ts
export type Channel = 'transform' | 'vertices' | 'warpPoints';
export interface TransformDelta { position: Vec2; rotation: number; scale: Vec2; opacity: number }
// position・rotation は加算、scale・opacity は倍率（1 = 変化なし）
export interface Binding {
  id: Id;
  target: { type: 'part' | 'mesh' | 'warp'; id: Id };   // transform → part、vertices → mesh、warpPoints → warp
  channel: Channel;
  parameterIds: Id[];              // 1 または 2
  keyValues: number[][];           // パラメータごとのキー位置（昇順。デフォルト値を必ず含む）
  keys: ParameterKey[];
  generation: 'linear' | 'depth' | 'rotate' | 'surface' | 'ease';
  divisions: number | null;        // 中間キーの分割数（自動なら null）
}
export interface ParameterKey {
  coords: number[];                // parameterIds と同じ順の値
  delta: TransformDelta | Vec2[];  // transform は TransformDelta、それ以外は頂点・制御点ごとの差分
  source: 'manual' | 'auto' | 'generated' | 'combined';
  locked: boolean;
}
```

### Model と Project（@app/schema）

```ts
export interface Model {
  parts: Part[];
  meshes: Mesh[];
  warps: Warp[];
  drawOrder: Id[];                 // 画像パーツの id。背面 → 前面
  parameters: Parameter[];
  parameterGroups: ParameterGroup[];
  bindings: Binding[];
  lipSync: LipSync;
  setupHints: { closedLineL: Vec2[] | null; closedLineR: Vec2[] | null };   // かんたんセットアップ用（閉じた目の線。STEP1で使う）
}
export interface Project {
  schemaVersion: number;           // 現在は 1
  id: Id;
  name: string;
  assets: Asset[];
  model: Model;
  expressions: Expression[];
  animations: Animation[];
  physics: Physics[];
  trackingMappings: TrackingMapping[];   // 空なら既定のマッピング
  studio: { scenes: Scene[]; activeSceneId: Id | null; hotkeys: Hotkey[] };
}
```

### 標準パラメータ（STANDARD_PARAMETERS）

| id | 表示名 | group | min | max | default | フェーズ |
| --- | --- | --- | --- | --- | --- | --- |
| FaceAngleX | 顔 左右 | face | -30 | 30 | 0 | MVP |
| FaceAngleY | 顔 上下 | face | -30 | 30 | 0 | MVP |
| FaceAngleZ | 顔 傾き | face | -30 | 30 | 0 | MVP |
| EyeOpenL / EyeOpenR | 目 開閉 L / R | eye | 0 | 1 | 1 | MVP |
| EyeBallX / EyeBallY | 瞳 左右 / 上下 | eye | -1 | 1 | 0 | MVP |
| MouthOpen | 口 開閉 | mouth | 0 | 1 | 0 | MVP |
| EyeSmileL / EyeSmileR | 目 笑顔 L / R | eye | 0 | 1 | 0 | STEP1 |
| BrowYL / BrowYR | 眉 上下 L / R | brow | -1 | 1 | 0 | STEP1 |
| BrowFormL / BrowFormR | 眉 形 L / R（困り〜怒り） | brow | -1 | 1 | 0 | STEP1 |
| MouthForm | 口 形（への字〜笑顔） | mouth | -1 | 1 | 0 | STEP1 |
| MouthWidth | 口 横幅（すぼめ〜横に開く） | mouth | -1 | 1 | 0 | STEP1 |
| Cheek | 頬染め | cheek | 0 | 1 | 0 | STEP1 |
| BodyAngleX / BodyAngleY / BodyAngleZ | 体 左右 / 上下 / 傾き | body | -10 | 10 | 0 | STEP1 |
| Breath | 呼吸 | body | 0 | 1 | 0 | STEP2 |
| ArmL / ArmR | 腕 L / R | armL / armR | -1 | 1 | 0 | STEP2 |
| HairFront / HairSide / HairBack | 髪揺れ 前 / 横 / 後ろ | sway | -1 | 1 | 0 | STEP2 |

### スキーマの関数（@app/schema）

```ts
export const SCHEMA_VERSION = 1;
export function validateProject(json: unknown): Project;       // 失敗時は項目のパス付きのエラー
export function migrate(json: unknown): unknown;               // 古い版を現在の版へ変換
export function loadProjectJson(text: string): Project;        // 解析 → migrate → validate
export function createEmptyProject(name: string): Project;     // MVPの標準パラメータ入り
export function ensureStandardParameters(model: Model, phase: 'mvp' | 'step1' | 'step2'): Model;
```

### 生成・セットアップの契約（@app/contracts）

```ts
export interface KeyGenerator {
  linear(binding: Binding, divisions?: number): Binding;
  depthParallax(model: Model, parameterId: 'FaceAngleX' | 'FaceAngleY'): Binding[];   // 作り直した transform バインディング
}
export interface AutoSetup { plan(project: Project): { command: Command; warnings: string[] } }
```

### アプリの枠の差し込み口（apps/desktop/src/shell/api.ts）

```ts
export interface PanelDef { id: string; mode: ModeId; area: 'left' | 'right' | 'bottom'; title: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanel(def: PanelDef): void;
export interface SectionDef { id: string; panelId: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanelSection(def: SectionDef): void;      // パネルの中の <PanelSections panelId=… /> に入る
export function PanelSections(props: { panelId: string }): JSX.Element;
export function registerCenter(mode: 'studio' | 'animation', component: React.FC): void;
export function registerSetupScreen(component: React.FC): void;   // 素材が1つも無いとき中央に出す
export function registerMenuItem(item: { id: string; label: string; shortcut?: string; run(): void }): void;

export interface CanvasPointerEvent { canvasPoint: Vec2; screenPoint: Vec2; button: number; shiftKey: boolean; altKey: boolean; ctrlKey: boolean }
export interface CanvasTool {
  id: string; label: string; cursor?: string;
  onPointerDown?(e: CanvasPointerEvent): void; onPointerMove?(e: CanvasPointerEvent): void; onPointerUp?(e: CanvasPointerEvent): void;
  onKeyDown?(e: KeyboardEvent): void;
  drawOverlay?(ctx: CanvasRenderingContext2D, view: ViewTransform): void;
}
export function registerCanvasTool(tool: CanvasTool): void;        // 最初に登録したものが既定のツール
export function registerCanvasOverlay(id: string, draw: (ctx: CanvasRenderingContext2D, view: ViewTransform) => void): void;
export function useCanvas(): { view: ViewTransform; activeToolId: string; setActiveTool(id: string): void; requestRedraw(): void; lastDeformed(): DeformedModel | null; screenToCanvas(p: Vec2): Vec2 };

export function useServices(): Services;
export function useProject(): Project;
export function useDispatch(): (c: Command) => void;
export function useEditor(): [EditorState, (patch: Partial<EditorState>) => void];
export function useEnvironment(): [Environment, (patch: Partial<Environment>) => void];
export function useDialogs(): { confirm(message: string): Promise<boolean>; notify(message: string): void; prompt(message: string, initial?: string): Promise<string | null> };
export function emitAppEvent(name: string, payload?: unknown): void;
export function onAppEvent(name: string, listener: (payload: unknown) => void): () => void;
```

## 作るもの

- `step2Params.ts`: 'projectLoaded' で ensureStandardParameters(model, 'step2') を実行する（足りないものがあるときだけ）。
- plan に規則を足す（source 'auto'。manual と locked のキーは残す）。

| パラメータ | 対象 | 値 1 のときの差分 |
| --- | --- | --- |
| Breath | torso | Δscale.y = 1.015（ピボットは胴体の下端中央） |
| Breath | neckRoot | Δposition.y = −胴体の高さ × 0.006 |
| ArmL / ArmR | armRootL / armRootR | Δrotation = −30 / +30（腕を上げる向き。値 −1 で逆） |

- 揺れものの標準パラメータ（HairFront など）は、物理の設定で使われるまでバインディングを作らない。

## 作らないもの

物理の設定（別のカード）。

## 完了条件

- [ ] fixtures でキーの向きと値が表のとおり
- [ ] 開いたプロジェクトに STEP2 の標準パラメータが足される
- [ ] 再実行で manual と locked のキーが残る
