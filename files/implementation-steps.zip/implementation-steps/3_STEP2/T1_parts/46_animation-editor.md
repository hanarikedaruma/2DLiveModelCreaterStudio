# 46. アニメーション画面（タイムライン・登録）

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | STEP2 / T1 部品 |
| 並行作業 | 同じ段階の 46〜53 と並行して作れる（触るフォルダは重ならない） |
| 担当の目安 | 画面 |
| 作業場所 | apps/desktop/src/modes/animation/ |

## 目的

パラメータを時間で動かすアニメーションを作り、名前と再生方法を付けて登録できるようにする。

## 前提（このカードの時点ですでにあるもの）

アプリの枠に registerCenter('animation') と registerPanel がある。モデリングと同じ evaluator・pipeline・renderer でプレビューを描ける。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### Animation（@app/schema）

```ts
export interface Animation {
  id: Id; name: string;
  duration: number;                // 秒
  speed: number; loop: boolean;
  periodic: boolean;               // 周期アニメーションか
  tracks: { parameterId: Id; keyframes: { time: number; value: number; curve: 'linear' | 'smooth' | 'step' }[] }[];
  affectedGroups: ParameterGroupId[];      // 空なら自動（トラックのあるグループ）
  restart: 'restart' | 'ignore';
  transition: {
    preset: 'auto' | 'quick' | 'natural' | 'slow' | 'custom';
    blendIn: number; blendOut: number;     // 秒
    curve: 'linear' | 'smooth';
    blendMode: 'override' | 'addToTracking';
    keepLipSync: boolean; keepPhysics: boolean; returnToTracking: boolean;
  };
}
```

### Parameter と ParameterGroup（@app/schema）

```ts
export interface ParameterGroup { id: ParameterGroupId; name: string }
export interface Parameter {
  id: Id;                          // 標準は 'FaceAngleX' など。ユーザー定義は任意の文字列
  name: string;                    // 表示名
  groupId: ParameterGroupId;
  min: number; max: number; default: number;
  standard: boolean;
}
```

### アプリの枠の差し込み口（apps/desktop/src/shell/api.ts）

```ts
export interface PanelDef { id: string; mode: ModeId; area: 'left' | 'right' | 'bottom'; title: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanel(def: PanelDef): void;
export interface SectionDef { id: string; panelId: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanelSection(def: SectionDef): void;      // パネルの中の <PanelSections panelId=… /> に入る
export function PanelSections(props: { panelId: string }): JSX.Element;
export function registerCenter(mode: 'studio' | 'animation', component: React.FC): void;
export function registerSetupScreen(component: React.FC): void;   // 素材が1つも無いとき中央に出す
export function registerMenuItem(item: { id: string; label: string; shortcut?: string; run(): void }): void;

export interface CanvasPointerEvent { canvasPoint: Vec2; screenPoint: Vec2; button: number; shiftKey: boolean; altKey: boolean; ctrlKey: boolean }
export interface CanvasTool {
  id: string; label: string; cursor?: string;
  onPointerDown?(e: CanvasPointerEvent): void; onPointerMove?(e: CanvasPointerEvent): void; onPointerUp?(e: CanvasPointerEvent): void;
  onKeyDown?(e: KeyboardEvent): void;
  drawOverlay?(ctx: CanvasRenderingContext2D, view: ViewTransform): void;
}
export function registerCanvasTool(tool: CanvasTool): void;        // 最初に登録したものが既定のツール
export function registerCanvasOverlay(id: string, draw: (ctx: CanvasRenderingContext2D, view: ViewTransform) => void): void;
export function useCanvas(): { view: ViewTransform; activeToolId: string; setActiveTool(id: string): void; requestRedraw(): void; lastDeformed(): DeformedModel | null; screenToCanvas(p: Vec2): Vec2 };

export function useServices(): Services;
export function useProject(): Project;
export function useDispatch(): (c: Command) => void;
export function useEditor(): [EditorState, (patch: Partial<EditorState>) => void];
export function useEnvironment(): [Environment, (patch: Partial<Environment>) => void];
export function useDialogs(): { confirm(message: string): Promise<boolean>; notify(message: string): void; prompt(message: string, initial?: string): Promise<string | null> };
export function emitAppEvent(name: string, payload?: unknown): void;
export function onAppEvent(name: string, listener: (payload: unknown) => void): () => void;
```

### サービスのまとめ（@app/contracts）

```ts
export interface Services {
  store: ProjectStore; editor: EditorStore; assets: AssetRepository; fs: FileSystem;
  evaluator: BindingEvaluator; pipeline: DeformPipeline; mixer: ParameterMixer; createRenderer(): Renderer;
  meshGenerator: MeshGenerator; keyGenerator: KeyGenerator; autoSetup: AutoSetup; keyEditor: KeyEditor;
  importer: Importer; io: ProjectIO; autoSaver: AutoSaver;
  tracking: TrackingSource; trackingLayer: TrackingLayerProducer;
}
```

### ストアの契約（@app/contracts）

```ts
export interface Command { label: string; apply(project: Project): Project }   // 純粋関数
export interface ProjectStore {
  get(): Project;
  subscribe(listener: (project: Project) => void): () => void;
  dispatch(command: Command): void;                                          // 1回の Undo 単位
  transaction(label: string, run: (dispatch: (c: Command) => void) => void): void;   // まとめて1回の Undo
  undo(): void; redo(): void; canUndo(): boolean; canRedo(): boolean;
  load(project: Project): void;                                              // 履歴を消して置き換える
}
export interface EditorState {
  mode: ModeId;
  uiLevel: Record<ModeId, UiLevel>;
  selectedPartIds: string[];
  activeParameterIds: string[];        // 編集中のパラメータ（0〜2個）
  editorParamValues: ParamValues;      // モデリング中のプレビュー値（無いパラメータはデフォルト値）
}
export interface EditorStore { get(): EditorState; set(patch: Partial<EditorState>): void; subscribe(l: (s: EditorState) => void): () => void }
```

## 作るもの

- アニメーションの一覧（left）: 追加・名前の変更・複製・削除。
- 中央: 上にプレビュー、下にタイムライン。パラメータの行ごとにキーフレーム（◆）。再生・停止・ループ再生、時刻のつまみ。
- キーフレームの操作: 追加（その時刻の今の値で）・移動・削除・値の変更（プレビューの横のパラメータのスライダー）。補間は 線形 / なめらか / 一定 を選ぶ。
- プレビューの値: 時刻 t でトラックを補間した値（トラックの無いパラメータはデフォルト値）。smooth は前後のキーフレームの間を smoothstep、step は前の値のまま。
- 登録の設定（right）: 再生速度、ループ、影響範囲（かんたんは自動 = トラックのあるグループ。詳細はグループごとに選ぶ）、遷移（かんたん: 自動 / すばやく / 自然 / ゆっくり と [x] トラッキングに戻る。詳細: blendIn・blendOut・カーブ・合成方法（上書き / トラッキングに加算）・リップシンクを維持・物理演算を維持）、再開始（最初から / 無視）。
- 遷移のプリセット: auto と natural は blendIn 0.35・blendOut 0.40、quick は 0.15・0.20、slow は 0.7・0.8（秒）。

## 作らないもの

スタジオでの再生（別のカード）。

## 完了条件

- [ ] キーフレームの追加・移動・削除・補間の切り替えと Undo
- [ ] プレビューの補間値のテスト（3種類の補間）
- [ ] 登録の設定が保存される
