# 54. STEP2の結合と受け入れ

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | STEP2 / T2 結合 |
| 並行作業 | 直列 |
| 担当の目安 | 結合 |
| 作業場所 | apps/desktop/src/services.ts、docs/ |

## 目的

STEP2の仮実装を本物に差し替え、STEP2の完成条件をすべて確かめる。

## 前提（このカードの時点ですでにあるもの）

次の本物の実装がある。

| 提供元 | 関数 |
| --- | --- |
| @app/core | createAnimationPlayer、createPeriodicPlayer、createPhysicsEngine、ExpressionController（同時適用つき） |
| @app/audio | createVowelEstimator（lipsync に組み込み済み） |

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### サービスのまとめ（@app/contracts）

```ts
export interface Services {
  store: ProjectStore; editor: EditorStore; assets: AssetRepository; fs: FileSystem;
  evaluator: BindingEvaluator; pipeline: DeformPipeline; mixer: ParameterMixer; createRenderer(): Renderer;
  meshGenerator: MeshGenerator; keyGenerator: KeyGenerator; autoSetup: AutoSetup; keyEditor: KeyEditor;
  importer: Importer; io: ProjectIO; autoSaver: AutoSaver;
  tracking: TrackingSource; trackingLayer: TrackingLayerProducer;
}
```

### STEP2で増える契約（@app/contracts）

```ts
// LayerProducer.produce は複数のレイヤーを返せるようになる（同じ id は配列の順に合成）
//   produce(ctx: FrameContext): Layer | Layer[] | null
export interface AnimationPlayer extends LayerProducer {   // id 'animation'。ctx.flags を設定する
  play(animationId: string, now: number): void;
  stop(animationId: string, now: number): void;
  stopAll(now: number): void;
  playing(): string[];
}
export interface PeriodicPlayer extends LayerProducer { setActive(animationIds: string[]): void }   // id 'periodic'
export interface PhysicsEngine extends LayerProducer { reset(): void }                             // id 'physics'
export interface VowelEstimator { estimate(samples: Float32Array, sampleRate: number): { closed: number; a: number; i: number; u: number; e: number; o: number } }   // 合計 1
// ExpressionController に足すメソッド（複数の同時適用）
//   toggle(expressionId: string, now: number): void
//   actives(): string[]           // 適用した順
// Services に足すもの: animations（AnimationPlayer）, periodic, physics, vowels
```

### スタジオの実行部の差し込み口（apps/desktop/src/modes/studio/runtime.ts）

```ts
export function registerLayerProducer(p: LayerProducer): () => void;   // LayerProducer・FrameContext は @app/contracts
export interface StudioFrame { model: DeformedModel; view: ViewTransform; background: Background; params: ParamValues; now: number }
export function registerFrameSink(sink: (frame: StudioFrame) => void): () => void;
export function useStudioRuntime(): { running: boolean; status: 'tracking' | 'lost' | 'stopped'; lastFrame(): StudioFrame | null };
```

1フレームの処理: LAYER_ORDER の順に producer を呼び、呼ぶたびに mixedSoFar を更新する → mixer.mix → evaluator → pipeline → プレビューの renderer と、登録された sink へ渡す。

## 作るもの

- `services.ts` の STEP2 の項目を本物に差し替え、producer をスタジオに登録する。
- 下の完成条件を、MVP と同じ評価条件で確かめ、`docs/acceptance-step2.md` に残す。

1. タイムライン
2. アニメーションの作成
3. アニメーションの登録
4. ループ
5. 周期アニメーション（呼吸の自動生成を含む）
6. 現在の状態からの開始ブレンド
7. 終了時のトラッキング復帰ブレンド
8. アニメーション間のクロスフェードと割り込み
9. 影響範囲（パラメータグループ単位）
10. トラッキング・表情・リップシンク・アニメーションの同時合成（標準の合成ルール）
11. 複数の表情の同時適用
12. 母音（あいうえお）によるリップシンク
13. 物理演算（揺れパラメータとバインディングの自動作成）
14. 髪・布・リボン・アクセサリの簡易物理プリセット
15. 標準パラメータの追加（呼吸、腕、揺れもの）

## 作らないもの

STEP3相当の機能（設計の対象外）。

## 完了条件

- [ ] 15項目すべての確認結果が docs/acceptance-step2.md にある
- [ ] MVP と STEP1 の受け入れの項目が引き続き通る
