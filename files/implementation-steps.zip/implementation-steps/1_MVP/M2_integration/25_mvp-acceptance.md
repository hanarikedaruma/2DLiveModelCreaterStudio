# 25. 計測とMVPの受け入れ

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | MVP / M2 結合 |
| 並行作業 | 直列 |
| 担当の目安 | 結合 |
| 作業場所 | apps/desktop/src/diagnostics/、fixtures/、docs/ |

## 目的

非機能要件を決めた条件で測り、MVPの完成条件をすべて確かめる。

## 前提（このカードの時点ですでにあるもの）

MVPの機能がすべて本物でつながっている。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### スタジオの実行部の差し込み口（apps/desktop/src/modes/studio/runtime.ts）

```ts
export function registerLayerProducer(p: LayerProducer): () => void;   // LayerProducer・FrameContext は @app/contracts
export interface StudioFrame { model: DeformedModel; view: ViewTransform; background: Background; params: ParamValues; now: number }
export function registerFrameSink(sink: (frame: StudioFrame) => void): () => void;
export function useStudioRuntime(): { running: boolean; status: 'tracking' | 'lost' | 'stopped'; lastFrame(): StudioFrame | null };
```

1フレームの処理: LAYER_ORDER の順に producer を呼び、呼ぶたびに mixedSoFar を更新する → mixer.mix → evaluator → pipeline → プレビューの renderer と、登録された sink へ渡す。

### トラッキングの契約（@app/contracts）

```ts
export interface TrackingFrame {
  time: number;                    // ミリ秒（performance.now）
  detected: boolean;
  faceYaw: number;                 // 度。ユーザーが自分の右を向くと正
  facePitch: number;               // 度。上を向くと正
  faceRoll: number;                // 度。ユーザーが自分の右へ傾けると正
  eyeOpenL: number; eyeOpenR: number;   // 0..1。ユーザー自身の左目・右目
  eyeBallX: number;                // -1..1。ユーザーが自分の右を見ると正
  eyeBallY: number;                // -1..1。上を見ると正
  mouthOpen: number;               // 0..1
}
export interface TrackingSource {
  listDevices(): Promise<{ id: string; label: string }[]>;
  start(deviceId?: string): Promise<void>;
  stop(): void;
  onFrame(listener: (frame: TrackingFrame) => void): () => void;
}
export interface TrackingLayerProducer {
  update(frame: TrackingFrame): void;
  tick(now: number): Layer;        // id 'tracking'
  status(): 'tracking' | 'lost';
  setMirror(on: boolean): void;
  setLostBehavior(b: 'returnToFront' | 'hold'): void;
}
```

## 作るもの

- 計測の表示（Ctrl+Shift+D で開閉）: 描画の fps（平均と1%最低値）、トラッキングの fps、遅延（TrackingFrame.time から、その値を使ったフレームを描いた時刻まで。95パーセンタイル）。5分間の記録を JSON に書き出せる。
- 基準モデル: `fixtures/reference-model/` を作るスクリプト（約50レイヤー、キャンバス 2000×3000px、かんたんセットアップ済み）。
- ストレステスト用の素材: 4000×6000px・100レイヤーの PSD を作るスクリプト。
- 下の評価条件で測り、結果を `docs/acceptance-mvp.md` に残す。ストレステスト（大きな PSD の取り込み時間とメモリ、2時間の連続動作でのメモリとフレームレート、内蔵GPUのPCでのフレームレート）は合否に含めず、結果だけを残す。

| 条件 | 内容 |
| --- | --- |
| 基準PC | Windows 11（64bit）、CPU 6コア12スレッド級、GPU GeForce RTX 3060級、メモリ 16GB |
| 同時実行 | OBS で 1920×1080・60fps の配信または録画を同時に行う |
| 基準モデル | fixtures/reference-model |
| カメラ | 1280×720・30fps の Webカメラ。明るい室内で逆光なし、顔が画面の高さの3分の1以上に写る距離 |
| 目標 | 描画 60fps（平均）、トラッキング 30fps 以上、遅延 100ms 以下（95パーセンタイル、スムージングは標準） |

MVPの完成条件（すべて確かめる）:

1. PNG・PSD の素材を複数読み込める（位置を保持。クリッピング・合成モード・特殊レイヤーは検出して警告する）
2. 素材を標準パーツへ手動で割り当てられる
3. かんたんセットアップで、階層・ピボット・描画順・マスクと、瞳・顔の傾き・顔の向き（奥行き）・目と口の開閉（簡易）のたたき台を自動で作れる
4. キャンバスで配置とピボットを調整できる
5. パーツを階層化できる（変形グループを含む）
6. 描画順を、階層とは独立して変更できる
7. メッシュを自動生成・手動編集でき、変形できる（キー作成後の作り直しは頂点のキーをリセット）
8. 1パーツにつき1つのマスク元で、マスクを設定できる
9. 標準パラメータ（MVP分）を使える
10. 代表状態から中間キーを生成できる（線形・奥行き）
11. バインディング・差分キー・ワープのデータ構造、合成レイヤーの骨格、コマンド方式、schemaVersion が、STEP1以降の機能を作り直しなしで載せられる形で実装されている（設計レビューで確認）
12. カメラ入力でモデルを動かせ、顔が外れたら正面へ戻る
13. スタジオで背景（透明・単色・画像）を変更できる
14. 単色背景とウィンドウキャプチャで、OBS へ出力できる
15. Undo / Redo ができる
16. 保存・再読込・自動保存ができる（schemaVersion 付き）
17. 評価条件のもとで、基準モデルが非機能要件の目標を満たす

## 作らないもの

目標を満たさなかった項目の改善（別のカードを起こす）。

## 完了条件

- [ ] 17項目すべての確認結果が docs/acceptance-mvp.md にある
- [ ] 計測の記録（JSON）とストレステストの結果が残っている
