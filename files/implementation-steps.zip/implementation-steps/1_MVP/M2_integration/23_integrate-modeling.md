# 23. モデリングの結合

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | MVP / M2 結合 |
| 並行作業 | 直列 |
| 担当の目安 | 結合 |
| 作業場所 | apps/desktop/src/services.ts、apps/desktop/src/project/、apps/desktop/src/platform/ |

## 目的

モデリングの仮実装を本物に差し替え、取り込みから保存までを通しで動かす。

## 前提（このカードの時点ですでにあるもの）

次の本物の実装がある。

| 提供元 | 関数 |
| --- | --- |
| @app/core | createProjectStore、createEditorStore、createBindingEvaluator、createDeformPipeline、createParameterMixer、createMeshGenerator、createKeyGenerator、createAutoSetup |
| @app/render | createWebGLRenderer |
| @app/io | createImporter、createProjectIO(fs)、createAutoSaver(fs, io, store, getAssetPngs) |
| @app/contracts | createAssetRepository |
| apps/desktop/src/services/keyEditor | createKeyEditor |

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### サービスのまとめ（@app/contracts）

```ts
export interface Services {
  store: ProjectStore; editor: EditorStore; assets: AssetRepository; fs: FileSystem;
  evaluator: BindingEvaluator; pipeline: DeformPipeline; mixer: ParameterMixer; createRenderer(): Renderer;
  meshGenerator: MeshGenerator; keyGenerator: KeyGenerator; autoSetup: AutoSetup; keyEditor: KeyEditor;
  importer: Importer; io: ProjectIO; autoSaver: AutoSaver;
  tracking: TrackingSource; trackingLayer: TrackingLayerProducer;
}
```

### アプリの枠の差し込み口（apps/desktop/src/shell/api.ts）

```ts
export interface PanelDef { id: string; mode: ModeId; area: 'left' | 'right' | 'bottom'; title: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanel(def: PanelDef): void;
export interface SectionDef { id: string; panelId: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanelSection(def: SectionDef): void;      // パネルの中の <PanelSections panelId=… /> に入る
export function PanelSections(props: { panelId: string }): JSX.Element;
export function registerCenter(mode: 'studio' | 'animation', component: React.FC): void;
export function registerSetupScreen(component: React.FC): void;   // 素材が1つも無いとき中央に出す
export function registerMenuItem(item: { id: string; label: string; shortcut?: string; run(): void }): void;

export interface CanvasPointerEvent { canvasPoint: Vec2; screenPoint: Vec2; button: number; shiftKey: boolean; altKey: boolean; ctrlKey: boolean }
export interface CanvasTool {
  id: string; label: string; cursor?: string;
  onPointerDown?(e: CanvasPointerEvent): void; onPointerMove?(e: CanvasPointerEvent): void; onPointerUp?(e: CanvasPointerEvent): void;
  onKeyDown?(e: KeyboardEvent): void;
  drawOverlay?(ctx: CanvasRenderingContext2D, view: ViewTransform): void;
}
export function registerCanvasTool(tool: CanvasTool): void;        // 最初に登録したものが既定のツール
export function registerCanvasOverlay(id: string, draw: (ctx: CanvasRenderingContext2D, view: ViewTransform) => void): void;
export function useCanvas(): { view: ViewTransform; activeToolId: string; setActiveTool(id: string): void; requestRedraw(): void; lastDeformed(): DeformedModel | null; screenToCanvas(p: Vec2): Vec2 };

export function useServices(): Services;
export function useProject(): Project;
export function useDispatch(): (c: Command) => void;
export function useEditor(): [EditorState, (patch: Partial<EditorState>) => void];
export function useEnvironment(): [Environment, (patch: Partial<Environment>) => void];
export function useDialogs(): { confirm(message: string): Promise<boolean>; notify(message: string): void; prompt(message: string, initial?: string): Promise<string | null> };
export function emitAppEvent(name: string, payload?: unknown): void;
export function onAppEvent(name: string, listener: (payload: unknown) => void): () => void;
```

### 取り込み・保存の契約（@app/contracts）

```ts
export interface FileSystem {          // パスは / 区切りの絶対パス
  readText(path: string): Promise<string>; writeText(path: string, data: string): Promise<void>;
  readBinary(path: string): Promise<Uint8Array>; writeBinary(path: string, data: Uint8Array): Promise<void>;
  exists(path: string): Promise<boolean>; mkdir(path: string): Promise<void>;
  list(dir: string): Promise<string[]>; remove(path: string): Promise<void>; rename(from: string, to: string): Promise<void>;
}
export interface ImportedAsset { asset: Asset; png: Uint8Array }   // png はトリミング済み
export interface ImportWarning { kind: 'canvasMismatch' | 'noTransparency' | 'resolution' | 'needsMerge'; assetIds: string[]; layerNames: string[]; message: string }
export interface Importer { importFiles(files: { name: string; data: Uint8Array }[]): Promise<{ assets: ImportedAsset[]; warnings: ImportWarning[] }> }
export interface ProjectIO {
  save(dir: string, project: Project, assetPngs: Record<string, Uint8Array>): Promise<void>;
  load(dir: string): Promise<{ project: Project; assetPngs: Record<string, Uint8Array> }>;
}
export interface AutoSaver { start(dir: string): void; stop(): void; findRecoverable(dir: string): Promise<string | null> }
```

### スキーマの関数（@app/schema）

```ts
export const SCHEMA_VERSION = 1;
export function validateProject(json: unknown): Project;       // 失敗時は項目のパス付きのエラー
export function migrate(json: unknown): unknown;               // 古い版を現在の版へ変換
export function loadProjectJson(text: string): Project;        // 解析 → migrate → validate
export function createEmptyProject(name: string): Project;     // MVPの標準パラメータ入り
export function ensureStandardParameters(model: Model, phase: 'mvp' | 'step1' | 'step2'): Model;
```

### Environment（@app/schema。PCごとの設定でプロジェクトの外に保存）

```ts
export interface Environment {
  cameraDeviceId: string | null;
  mirror: boolean;
  calibration: { neutral: { yaw: number; pitch: number; roll: number }; eyeClosed: { l: number; r: number }; mouthOpenMax: number } | null;
  microphoneDeviceId: string | null;
  silenceThreshold: number;        // dBFS
  trackingPreset: 'stable' | 'standard' | 'large' | 'custom';
  output: { method: 'window' | 'spout2'; width: number; height: number; fps: number };
  uiLevel: Record<ModeId, UiLevel>;
  lastProjectDir: string | null;
}
```

## 作るもの

- `platform/tauriFs.ts`: Tauri の fs プラグインで FileSystem を実装する。
- `services.ts`: トラッキング以外を本物に差し替える。
- プロジェクトの操作（registerMenuItem）:
  - 新規: 名前を入れる → createEmptyProject → store.load。保存先はまだ無いので、自動保存はアプリのデータフォルダの `unsaved/<project.id>/` に行う。
  - 開く: フォルダを選ぶ → io.load → store.load、素材を assets.put。Environment.lastProjectDir を更新する。
  - 保存（Ctrl+S）: 保存先が無ければフォルダを選ぶ。名前を付けて保存も用意する。
  - 読み込みと新規作成の後に、アプリイベント 'projectLoaded'（値はプロジェクト）を出す。
- 起動時: `unsaved/` と lastProjectDir について findRecoverable を調べ、あれば復元するか確認する。
- 自動保存を開始する。
- 通しのテスト（Playwright と Tauri の WebDriver）: fixtures の素材から PSD を作るスクリプトで用意した PSD を取り込む → スクリプトで標準パーツへ割り当てる → かんたんセットアップ → FaceAngleX を 30 にすると前髪が右へ、後ろ髪が左へ動く → 保存 → 開き直して同じになる → Undo で戻る。

## 作らないもの

スタジオの本物への差し替え（次のカード）。

## 完了条件

- [ ] 新規・開く・保存・名前を付けて保存ができる
- [ ] 異常終了の後に復元を提案する
- [ ] 通しのテストが通る
