# 01. リポジトリと開発環境

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | MVP / M0 基盤 |
| 並行作業 | 直列。前の番号のカードが終わってから始める |
| 担当の目安 | 基盤 |
| 作業場所 | リポジトリ全体 |

## 目的

全員が同じ構成・同じ規則で作業できる土台を作る。

## 前提（このカードの時点ですでにあるもの）

なし（最初のカード）。

### リポジトリの約束

- pnpm ワークスペースのモノレポ。TypeScript は strict、テストは Vitest。
- パッケージ: `@app/schema`（packages/schema。データ型・検証・既定値・規則）、`@app/contracts`（packages/contracts。実行時のインターフェースと仮実装）、`@app/core`（packages/core。評価・変形・生成・合成・ストア。DOMに依存しない）、`@app/render`（packages/render。WebGL2）、`@app/io`（packages/io。取り込み・保存）、`@app/tracking`（packages/tracking）、`@app/audio`（packages/audio）、`apps/desktop`（Tauri 2 + React）。
- パッケージから参照してよいのは `@app/schema` と `@app/contracts` だけ（同じパッケージの中は自由）。すべてを組み合わせるのは apps/desktop だけ。
- データは不変に扱い、更新は新しいオブジェクトを返す。
- ロジックには必ずユニットテストを付ける。

## 作るもの

- pnpm ワークスペースを作り、`packages/schema`・`contracts`・`core`・`render`・`io`・`tracking`・`audio` と `apps/desktop`・`fixtures` を置く。各パッケージは空の `src/index.ts` とテスト1件だけ。パッケージ名は `@app/schema` などにする。
- `apps/desktop` は Tauri 2 + React 18 + Vite + TypeScript。Windows 10 / 11（64bit）でビルド・起動できる。
- TypeScript strict、ESLint、Prettier、Vitest を全体に入れ、`pnpm test`・`pnpm lint` で全パッケージを回す。
- 参照の規則を ESLint の import 制限で強制する（schema → なし、contracts → schema、ほかのパッケージ → schema と contracts、apps/desktop → すべて）。
- Tauri のプラグイン: fs、dialog、global-shortcut、window-state。WebView2 でカメラとマイクを使えるようにする（権限の確認をアプリ側で許可する）。
- CI（GitHub Actions、windows-latest）: install → lint → test → tauri build。

## 作らないもの

画面と機能。

## 完了条件

- [ ] `pnpm test` と `pnpm lint` が全パッケージで通る
- [ ] `pnpm tauri dev` で空のウィンドウが開く
- [ ] 禁止した参照（例: core から render）を書くと lint が失敗する
- [ ] CI が通る
