# 05. アプリの枠（モード・パネル・差し込み口）

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | MVP / M0 基盤 |
| 並行作業 | 直列。前の番号のカードが終わってから始める |
| 担当の目安 | 基盤 |
| 作業場所 | apps/desktop/src/shell/、apps/desktop/src/services.ts |

## 目的

3つのモードの画面の枠と、部品を差し込む口（パネル・セクション・キャンバスのツール・メニュー・サービス・イベント）を作る。

## 前提（このカードの時点ですでにあるもの）

`@app/contracts` のインターフェースと仮実装、`@app/core` のストア（createProjectStore・createEditorStore）がある。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### リポジトリの約束

- pnpm ワークスペースのモノレポ。TypeScript は strict、テストは Vitest。
- パッケージ: `@app/schema`（packages/schema。データ型・検証・既定値・規則）、`@app/contracts`（packages/contracts。実行時のインターフェースと仮実装）、`@app/core`（packages/core。評価・変形・生成・合成・ストア。DOMに依存しない）、`@app/render`（packages/render。WebGL2）、`@app/io`（packages/io。取り込み・保存）、`@app/tracking`（packages/tracking）、`@app/audio`（packages/audio）、`apps/desktop`（Tauri 2 + React）。
- パッケージから参照してよいのは `@app/schema` と `@app/contracts` だけ（同じパッケージの中は自由）。すべてを組み合わせるのは apps/desktop だけ。
- データは不変に扱い、更新は新しいオブジェクトを返す。
- ロジックには必ずユニットテストを付ける。

### ストアの契約（@app/contracts）

```ts
export interface Command { label: string; apply(project: Project): Project }   // 純粋関数
export interface ProjectStore {
  get(): Project;
  subscribe(listener: (project: Project) => void): () => void;
  dispatch(command: Command): void;                                          // 1回の Undo 単位
  transaction(label: string, run: (dispatch: (c: Command) => void) => void): void;   // まとめて1回の Undo
  undo(): void; redo(): void; canUndo(): boolean; canRedo(): boolean;
  load(project: Project): void;                                              // 履歴を消して置き換える
}
export interface EditorState {
  mode: ModeId;
  uiLevel: Record<ModeId, UiLevel>;
  selectedPartIds: string[];
  activeParameterIds: string[];        // 編集中のパラメータ（0〜2個）
  editorParamValues: ParamValues;      // モデリング中のプレビュー値（無いパラメータはデフォルト値）
}
export interface EditorStore { get(): EditorState; set(patch: Partial<EditorState>): void; subscribe(l: (s: EditorState) => void): () => void }
```

### 描画の契約（@app/contracts）

```ts
export type Background = { type: 'transparent' } | { type: 'color'; color: string } | { type: 'image'; image: ImageBitmap };
export interface ViewTransform { scale: number; offset: Vec2 }   // 画面座標（CSSピクセル）= キャンバス座標 × scale + offset
export interface Renderer {
  init(canvas: HTMLCanvasElement): void;
  setTextures(images: Record<string, ImageBitmap>): void;       // assetId → 画像
  render(model: DeformedModel, view: ViewTransform, background: Background): void;
  dispose(): void;
}
```

### 変形の契約（@app/contracts）

```ts
export interface DrawItem {
  partId: string; assetId: string;
  positions: Float32Array;         // 変形後の頂点（キャンバス座標）[x0, y0, x1, y1, ...]
  uvs: Float32Array;               // [u0, v0, ...]（0..1）
  indices: Uint32Array;
  opacity: number;                 // 親まで掛けた最終値
  blendMode: BlendMode;
  mask: { sourcePartIds: string[]; inverted: boolean } | null;
}
export interface DeformedModel {
  items: DrawItem[];               // 描画順（背面 → 前面）。非表示のパーツは含めない
  byPartId: Record<string, DrawItem>;
}
export interface DeformPipeline { deform(model: Model, deltas: TargetDeltas): DeformedModel }
```

### サービスのまとめ（@app/contracts）

```ts
export interface Services {
  store: ProjectStore; editor: EditorStore; assets: AssetRepository; fs: FileSystem;
  evaluator: BindingEvaluator; pipeline: DeformPipeline; mixer: ParameterMixer; createRenderer(): Renderer;
  meshGenerator: MeshGenerator; keyGenerator: KeyGenerator; autoSetup: AutoSetup; keyEditor: KeyEditor;
  importer: Importer; io: ProjectIO; autoSaver: AutoSaver;
  tracking: TrackingSource; trackingLayer: TrackingLayerProducer;
}
```

### 仮実装（@app/contracts の fakes）

- FakeEvaluator: 差分なし（すべて空）を返す。
- FakePipeline: 表示中の画像パーツを、素材の矩形（offset と幅・高さ）を覆う三角形2枚にし、自身のパーツの基本の変形だけを掛ける。順番は drawOrder。
- FakeRenderer: Canvas 2D で、各 DrawItem の画像を頂点の外接矩形に drawImage する。
- FakeMixer: デフォルト値に、各レイヤーの値を重みで上書きする。
- FakeTrackingSource: 30fps で顔をゆっくり左右に振る TrackingFrame を出す。20秒ごとに2秒間 detected を false にする。
- FakeTrackingLayer: フレームの値をそのままパラメータに写す（ミラー・スムージングなし）。
- FakeImporter: PNG だけを読み、トリミングせず offset (0,0) で返す。
- MemoryFileSystem、FakeProjectIO（メモリに保存）、FakeAutoSaver（何もしない）。
- FakeMeshGenerator: 画像全体を覆う四角形（三角形2枚）。
- FakeKeyGenerator・FakeAutoSetup: 何も変えないコマンド・バインディングを返す。
- FakeKeyEditor: 常に基準状態（Part の position・rotation・scale・pivot・opacity、メッシュの基準頂点）を変えるコマンドを返す。
- fixtures/sample-model: 単純な図形で描いたテスト用素材（1000×1500px、標準パーツ一式）と、割り当てだけ済んだ project.json。

### Environment（@app/schema。PCごとの設定でプロジェクトの外に保存）

```ts
export interface Environment {
  cameraDeviceId: string | null;
  mirror: boolean;
  calibration: { neutral: { yaw: number; pitch: number; roll: number }; eyeClosed: { l: number; r: number }; mouthOpenMax: number } | null;
  microphoneDeviceId: string | null;
  silenceThreshold: number;        // dBFS
  trackingPreset: 'stable' | 'standard' | 'large' | 'custom';
  output: { method: 'window' | 'spout2'; width: number; height: number; fps: number };
  uiLevel: Record<ModeId, UiLevel>;
  lastProjectDir: string | null;
}
```

## 作るもの

- ヘッダー: [モデリング][アニメーション][スタジオ] の切り替え。かんたん/詳細の切り替えボタンは置くが STEP1 まで非表示にする（状態は EditorState.uiLevel にモードごとに持つ）。
- レイアウト: 各モードに left・right・bottom の領域。registerPanel したパネルを order 順に並べる。level が 'detail' のパネルとセクションは、そのモードの uiLevel が 'detail' のときだけ出す。
- モデリングの中央はキャンバスホスト。services の evaluator → pipeline → renderer で、EditorState.editorParamValues の状態を描く（プロジェクトか EditorState が変わったときだけ描き直す）。ホイールで拡大縮小、スペース＋ドラッグか中ボタンで移動、[全体を表示]。registerCanvasTool したツールを切り替え、pointer イベントをキャンバス座標に直してアクティブなツールへ渡す。オーバーレイは 2D Canvas を重ねて描く。
- スタジオとアニメーションの中央は registerCenter で差し込む。
- セットアップ画面: プロジェクトに素材が1つも無いとき、registerSetupScreen された画面を中央に出す。
- メニュー: registerMenuItem したものを並べる。Ctrl+Z は undo、Ctrl+Shift+Z と Ctrl+Y は redo を枠が処理する。
- 環境設定: useEnvironment は Tauri のアプリ設定フォルダの `environment.json` に読み書きする。既定値は cameraDeviceId null、mirror true、calibration null、microphoneDeviceId null、silenceThreshold −50、trackingPreset 'standard'、output {method 'window'、1920×1080、60fps}、uiLevel はすべて 'easy'、lastProjectDir null。
- アプリイベント: emitAppEvent・onAppEvent（名前と任意の値）。
- `src/services.ts`: 仮実装と本物のストアで Services を組み立てる。この1ファイルを差し替えるだけで本物に切り替わる構造にする。
- useDialogs: 確認・通知・入力のダイアログ。

### アプリの枠の差し込み口（apps/desktop/src/shell/api.ts）

```ts
export interface PanelDef { id: string; mode: ModeId; area: 'left' | 'right' | 'bottom'; title: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanel(def: PanelDef): void;
export interface SectionDef { id: string; panelId: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanelSection(def: SectionDef): void;      // パネルの中の <PanelSections panelId=… /> に入る
export function PanelSections(props: { panelId: string }): JSX.Element;
export function registerCenter(mode: 'studio' | 'animation', component: React.FC): void;
export function registerSetupScreen(component: React.FC): void;   // 素材が1つも無いとき中央に出す
export function registerMenuItem(item: { id: string; label: string; shortcut?: string; run(): void }): void;

export interface CanvasPointerEvent { canvasPoint: Vec2; screenPoint: Vec2; button: number; shiftKey: boolean; altKey: boolean; ctrlKey: boolean }
export interface CanvasTool {
  id: string; label: string; cursor?: string;
  onPointerDown?(e: CanvasPointerEvent): void; onPointerMove?(e: CanvasPointerEvent): void; onPointerUp?(e: CanvasPointerEvent): void;
  onKeyDown?(e: KeyboardEvent): void;
  drawOverlay?(ctx: CanvasRenderingContext2D, view: ViewTransform): void;
}
export function registerCanvasTool(tool: CanvasTool): void;        // 最初に登録したものが既定のツール
export function registerCanvasOverlay(id: string, draw: (ctx: CanvasRenderingContext2D, view: ViewTransform) => void): void;
export function useCanvas(): { view: ViewTransform; activeToolId: string; setActiveTool(id: string): void; requestRedraw(): void; lastDeformed(): DeformedModel | null; screenToCanvas(p: Vec2): Vec2 };

export function useServices(): Services;
export function useProject(): Project;
export function useDispatch(): (c: Command) => void;
export function useEditor(): [EditorState, (patch: Partial<EditorState>) => void];
export function useEnvironment(): [Environment, (patch: Partial<Environment>) => void];
export function useDialogs(): { confirm(message: string): Promise<boolean>; notify(message: string): void; prompt(message: string, initial?: string): Promise<string | null> };
export function emitAppEvent(name: string, payload?: unknown): void;
export function onAppEvent(name: string, listener: (payload: unknown) => void): () => void;
```

## 作らないもの

各パネルの中身。

## 完了条件

- [ ] 3つのモードを切り替えられ、テスト用のパネルとセクションが出る。uiLevel で出し分けられる
- [ ] キャンバスに fixtures のモデルが（仮実装で）表示され、拡大・移動できる
- [ ] テスト用のツールで、pointer のキャンバス座標が拡大・移動の後も正しい
- [ ] Ctrl+Z で store.undo が呼ばれる
- [ ] environment.json を読み書きできる
