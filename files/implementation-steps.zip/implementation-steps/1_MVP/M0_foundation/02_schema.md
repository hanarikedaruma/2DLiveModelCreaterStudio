# 02. データスキーマ（型・検証・既定値・規則）

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | MVP / M0 基盤 |
| 並行作業 | 直列。前の番号のカードが終わってから始める |
| 担当の目安 | 基盤 |
| 作業場所 | packages/schema/src/ |

## 目的

全カードが使うデータの形を確定させる。STEP2 までの項目を最初から含め、後から形を変えないようにする。

## 前提（このカードの時点ですでにあるもの）

pnpm モノレポと、空の `packages/schema` がある。

### リポジトリの約束

- pnpm ワークスペースのモノレポ。TypeScript は strict、テストは Vitest。
- パッケージ: `@app/schema`（packages/schema。データ型・検証・既定値・規則）、`@app/contracts`（packages/contracts。実行時のインターフェースと仮実装）、`@app/core`（packages/core。評価・変形・生成・合成・ストア。DOMに依存しない）、`@app/render`（packages/render。WebGL2）、`@app/io`（packages/io。取り込み・保存）、`@app/tracking`（packages/tracking）、`@app/audio`（packages/audio）、`apps/desktop`（Tauri 2 + React）。
- パッケージから参照してよいのは `@app/schema` と `@app/contracts` だけ（同じパッケージの中は自由）。すべてを組み合わせるのは apps/desktop だけ。
- データは不変に扱い、更新は新しいオブジェクトを返す。
- ロジックには必ずユニットテストを付ける。

### 座標と値の約束

- 座標はキャンバス（元のPSD・PNG）のピクセル。原点は左上、x は右、y は下が正。
- 回転は度。画面上の時計回りが正。
- L / R はキャラクター自身から見た左右。画面では L が右側に描かれる。
- FaceAngleX はキャラクターが画面の右を向くと正、FaceAngleY は上を向くと正、FaceAngleZ は時計回りが正。EyeBallX は画面の右を見ると正、EyeBallY は上を見ると正。
- 基準状態 = 素材を配置しただけの状態 = 全パラメータがデフォルト値の状態。素材は「目を開け、口を閉じた」状態で描かれている前提。
- キーは基準状態からの差分。位置・回転・頂点は加算、拡縮・不透明度は倍率（1 = 変化なし）。

## 作るもの

- `types.ts` に下の型を、コメントも含めてそのまま定義する。
- `validate.ts`: zod で `validateProject(json: unknown): Project`。失敗したら項目のパス（例: `model.parts[3].pivot.x`）を含むエラーを投げる。
- `migrate.ts`: `SCHEMA_VERSION = 1`。`migrate(json)` は変換表（`{ [版]: (json) => json }`。v1 では空）で現在の版まで順に変換する。現在より新しい版はエラー。`loadProjectJson(text)` = 解析 → migrate → validate。
- `defaults.ts`: `createEmptyProject(name)`（MVP の標準パラメータと全パラメータグループ入り。lipSync は mouthSource 'max'・strength 'standard'・vowels 空。setupHints は両方 null。studio は空のシーン1つ）。`ensureStandardParameters(model, phase)`（足りない標準パラメータだけを足す。'step1' は MVP と STEP1、'step2' はすべて）。
- `rules.ts`: 下の「規則」を定義する。
- `ids.ts`: `newId()`（ULID）。

### 基本の型（@app/schema）

```ts
export type Id = string;
export interface Vec2 { x: number; y: number }
export type BlendMode = 'normal' | 'multiply' | 'screen' | 'add';
export type ParameterGroupId = 'face' | 'eye' | 'brow' | 'mouth' | 'cheek' | 'body' | 'armL' | 'armR' | 'sway' | 'other';
export type ModeId = 'modeling' | 'animation' | 'studio';
export type UiLevel = 'easy' | 'detail';
export function newId(): string;   // ULID
```

### Asset（@app/schema）

```ts
export interface Asset {
  id: Id;
  path: string;                    // 例: assets/<id>.png
  hash: string;                    // png の SHA-256（16進）
  width: number; height: number;   // トリミング後のサイズ
  offset: Vec2;                    // トリミング後の左上のキャンバス座標
  canvasSize: { width: number; height: number };
  source: { kind: 'psd' | 'png'; file: string; layerName?: string; layerPath?: string[]; hidden?: boolean };
  sourceBlendMode: BlendMode;
  sourceOpacity: number;           // 0..1
}
```

### Part と StandardPartType（@app/schema）

```ts
export interface Part {
  id: Id;
  name: string;
  kind: 'image' | 'group';
  standardType: StandardPartType | null;   // 自由パーツは null
  assetId: Id | null;                      // image のみ
  meshId: Id | null;                       // image のみ
  parentId: Id | null;
  position: Vec2;                          // 初期値 {x: 0, y: 0}
  rotation: number;                        // 度。初期値 0
  scale: Vec2;                             // 初期値 {x: 1, y: 1}
  pivot: Vec2;                             // 回転・拡縮の中心（キャンバス座標）
  opacity: number;                         // 0..1
  blendMode: BlendMode;
  depth: number;                           // 奥行き。手前が正（-1..1 が目安）
  mask: { sourcePartIds: Id[]; inverted: boolean } | null;
  physicsId: Id | null;
  visible: boolean;
  locked: boolean;
}
export type StandardPartType =
  | 'face' | 'earL' | 'earR' | 'cheek'
  | 'eyeWhiteL' | 'irisL' | 'highlightL' | 'upperLidL' | 'lowerLidL' | 'eyeWholeL'
  | 'eyeWhiteR' | 'irisR' | 'highlightR' | 'upperLidR' | 'lowerLidR' | 'eyeWholeR'
  | 'browL' | 'browR'
  | 'upperLip' | 'lowerLip' | 'mouthInside' | 'teeth' | 'tongue' | 'mouthWhole'
  | 'frontHair' | 'sideHairL' | 'sideHairR' | 'backHair'
  | 'neck' | 'torso' | 'armL' | 'armR'
  // 変形グループ（かんたんセットアップが作る）
  | 'bodyRoot' | 'armRootL' | 'armRootR' | 'neckRoot' | 'headRoot'
  | 'faceGroup' | 'eyeGroupL' | 'eyeGroupR' | 'mouthGroup';
```

### Mesh（@app/schema）

```ts
export interface Mesh {
  id: Id;
  vertices: Vec2[];                // 基準状態の頂点（キャンバス座標）
  uvs: Vec2[];                     // 0..1（素材画像の中の位置）
  triangles: [number, number, number][];
  density: 'light' | 'standard' | 'smooth' | 'custom';
  edited: boolean;                 // 手で編集したか
}
```

### Warp（@app/schema）

```ts
export interface Warp {
  id: Id;
  partId: Id;                      // ワープを付ける group パーツ
  columns: number; rows: number;   // 格子の分割数
  bounds: { x: number; y: number; width: number; height: number };   // キャンバス座標
  points: Vec2[];                  // (columns+1)×(rows+1) 個、行優先。基準状態の制御点
}
```

### Parameter と ParameterGroup（@app/schema）

```ts
export interface ParameterGroup { id: ParameterGroupId; name: string }
export interface Parameter {
  id: Id;                          // 標準は 'FaceAngleX' など。ユーザー定義は任意の文字列
  name: string;                    // 表示名
  groupId: ParameterGroupId;
  min: number; max: number; default: number;
  standard: boolean;
}
```

### Binding と ParameterKey（@app/schema）

```ts
export type Channel = 'transform' | 'vertices' | 'warpPoints';
export interface TransformDelta { position: Vec2; rotation: number; scale: Vec2; opacity: number }
// position・rotation は加算、scale・opacity は倍率（1 = 変化なし）
export interface Binding {
  id: Id;
  target: { type: 'part' | 'mesh' | 'warp'; id: Id };   // transform → part、vertices → mesh、warpPoints → warp
  channel: Channel;
  parameterIds: Id[];              // 1 または 2
  keyValues: number[][];           // パラメータごとのキー位置（昇順。デフォルト値を必ず含む）
  keys: ParameterKey[];
  generation: 'linear' | 'depth' | 'rotate' | 'surface' | 'ease';
  divisions: number | null;        // 中間キーの分割数（自動なら null）
}
export interface ParameterKey {
  coords: number[];                // parameterIds と同じ順の値
  delta: TransformDelta | Vec2[];  // transform は TransformDelta、それ以外は頂点・制御点ごとの差分
  source: 'manual' | 'auto' | 'generated' | 'combined';
  locked: boolean;
}
```

### Model と Project（@app/schema）

```ts
export interface Model {
  parts: Part[];
  meshes: Mesh[];
  warps: Warp[];
  drawOrder: Id[];                 // 画像パーツの id。背面 → 前面
  parameters: Parameter[];
  parameterGroups: ParameterGroup[];
  bindings: Binding[];
  lipSync: LipSync;
  setupHints: { closedLineL: Vec2[] | null; closedLineR: Vec2[] | null };   // かんたんセットアップ用（閉じた目の線。STEP1で使う）
}
export interface Project {
  schemaVersion: number;           // 現在は 1
  id: Id;
  name: string;
  assets: Asset[];
  model: Model;
  expressions: Expression[];
  animations: Animation[];
  physics: Physics[];
  trackingMappings: TrackingMapping[];   // 空なら既定のマッピング
  studio: { scenes: Scene[]; activeSceneId: Id | null; hotkeys: Hotkey[] };
}
```

### Expression（@app/schema）

```ts
export type BlendOp = 'override' | 'add' | 'multiply' | 'max';
export interface Expression {
  id: Id; name: string;
  entries: { parameterId: Id; value: number; blend: BlendOp }[];
  fadeIn: number; fadeOut: number;          // 秒
}
```

### LipSync（@app/schema）

```ts
export interface LipSync {
  mouthSource: 'max' | 'micOnly' | 'cameraOnly';
  strength: 'low' | 'standard' | 'high';
  vowels: { vowel: 'closed' | 'a' | 'i' | 'u' | 'e' | 'o'; values: Record<Id, number> }[];   // STEP2で使う
}
```

### Animation（@app/schema）

```ts
export interface Animation {
  id: Id; name: string;
  duration: number;                // 秒
  speed: number; loop: boolean;
  periodic: boolean;               // 周期アニメーションか
  tracks: { parameterId: Id; keyframes: { time: number; value: number; curve: 'linear' | 'smooth' | 'step' }[] }[];
  affectedGroups: ParameterGroupId[];      // 空なら自動（トラックのあるグループ）
  restart: 'restart' | 'ignore';
  transition: {
    preset: 'auto' | 'quick' | 'natural' | 'slow' | 'custom';
    blendIn: number; blendOut: number;     // 秒
    curve: 'linear' | 'smooth';
    blendMode: 'override' | 'addToTracking';
    keepLipSync: boolean; keepPhysics: boolean; returnToTracking: boolean;
  };
}
```

### Physics（@app/schema）

```ts
export interface Physics {
  id: Id; partId: Id;              // 根元の位置はこのパーツの pivot
  preset: 'hair' | 'cloth' | 'ribbon' | 'accessory';
  strength: number;                // 0..1（かんたん設定の「揺れ方」）
  direction: 'horizontal' | 'vertical' | 'both';
  length: number;                  // px
  spring: number; damping: number; gravity: number; inertia: number; range: number;
  inputs: { parameterId: Id; weight: number }[];
  outputParameterId: Id;
}
```

### TrackingMapping（@app/schema）

```ts
export type TrackingInput = 'faceYaw' | 'facePitch' | 'faceRoll' | 'eyeOpenL' | 'eyeOpenR' | 'eyeBallX' | 'eyeBallY'
  | 'mouthOpen' | 'mouthForm' | 'mouthWidth' | 'browY';
export interface TrackingMapping {
  input: TrackingInput; parameterId: Id;
  inputRange: [number, number]; outputRange: [number, number];
  invert: boolean; curve: 'linear' | 'smooth';
  smoothing: number;               // 0..1
  deadZone: number;                // 入力の単位
}
```

### Scene と Hotkey（@app/schema）

```ts
export interface Scene {
  id: Id; name: string;
  background: { type: 'transparent' } | { type: 'color'; color: string } | { type: 'image'; path: string };   // path はプロジェクトからの相対パス
  modelTransform: { position: Vec2; scale: number };   // 出力画面での位置（px）と倍率
  expressionIds: Id[];             // シーンに切り替えたときに適用する表情
  periodicAnimationIds: Id[];      // STEP2で使う
}
export interface Hotkey {
  id: Id;
  keys: string;                    // 例: 'Ctrl+Shift+1'
  action: 'expression' | 'scene' | 'background' | 'animation' | 'parameter' | 'pauseTracking' | 'recalibrate';
  targetId: Id | null;
  mode: 'toggle' | 'hold';
}
```

### Environment（@app/schema。PCごとの設定でプロジェクトの外に保存）

```ts
export interface Environment {
  cameraDeviceId: string | null;
  mirror: boolean;
  calibration: { neutral: { yaw: number; pitch: number; roll: number }; eyeClosed: { l: number; r: number }; mouthOpenMax: number } | null;
  microphoneDeviceId: string | null;
  silenceThreshold: number;        // dBFS
  trackingPreset: 'stable' | 'standard' | 'large' | 'custom';
  output: { method: 'window' | 'spout2'; width: number; height: number; fps: number };
  uiLevel: Record<ModeId, UiLevel>;
  lastProjectDir: string | null;
}
```

### スキーマの関数（@app/schema）

```ts
export const SCHEMA_VERSION = 1;
export function validateProject(json: unknown): Project;       // 失敗時は項目のパス付きのエラー
export function migrate(json: unknown): unknown;               // 古い版を現在の版へ変換
export function loadProjectJson(text: string): Project;        // 解析 → migrate → validate
export function createEmptyProject(name: string): Project;     // MVPの標準パラメータ入り
export function ensureStandardParameters(model: Model, phase: 'mvp' | 'step1' | 'step2'): Model;
```

### 規則（@app/schema の rules.ts）

```ts
export const STANDARD_PARAMETERS: Parameter[];                      // 標準パラメータの表（standard: true）
export const PARAMETER_GROUPS: ParameterGroup[];                    // face 顔 / eye 目 / brow 眉 / mouth 口 / cheek 頬 / body 体 / armL 左腕 / armR 右腕 / sway 揺れもの / other その他
export const STANDARD_PART_NAMES: Record<StandardPartType, string>; // 日本語の表示名（例: eyeWhiteL → 白目 L）
export const STANDARD_DRAW_ORDER: StandardPartType[];               // 背面 → 前面（下記）
export const DEFAULT_DEPTH: Partial<Record<StandardPartType, number>>;   // 下記
export const PARALLAX_RATIO = 0.08;
// 奥行きによる移動量（px）。faceWidth は standardType 'face' の素材の幅
export function depthParallaxOffset(depth: number, value: number, faceWidth: number, axis: 'x' | 'y'): number {
  const d = depth * (value / 30) * faceWidth * PARALLAX_RATIO;
  return axis === 'x' ? d : -d;    // y は上が負
}
```

- STANDARD_DRAW_ORDER（背面 → 前面）: backHair, torso, armL, armR, neck, earL, earR, face, cheek, mouthInside, teeth, tongue, upperLip, lowerLip, mouthWhole, eyeWhiteL, eyeWhiteR, eyeWholeL, eyeWholeR, irisL, irisR, highlightL, highlightR, lowerLidL, lowerLidR, upperLidL, upperLidR, browL, browR, sideHairL, sideHairR, frontHair
- DEFAULT_DEPTH: frontHair 1.0 / browL・browR 0.6 / 目のパーツ（eyeWhite・iris・highlight・upperLid・lowerLid・eyeWhole の L・R）0.5 / 口のパーツ（upperLip・lowerLip・mouthInside・teeth・tongue・mouthWhole）0.5 / sideHairL・sideHairR 0.4 / cheek 0.4 / face 0.2 / earL・earR −0.5 / backHair −1.0

### 標準パラメータ（STANDARD_PARAMETERS）

| id | 表示名 | group | min | max | default | フェーズ |
| --- | --- | --- | --- | --- | --- | --- |
| FaceAngleX | 顔 左右 | face | -30 | 30 | 0 | MVP |
| FaceAngleY | 顔 上下 | face | -30 | 30 | 0 | MVP |
| FaceAngleZ | 顔 傾き | face | -30 | 30 | 0 | MVP |
| EyeOpenL / EyeOpenR | 目 開閉 L / R | eye | 0 | 1 | 1 | MVP |
| EyeBallX / EyeBallY | 瞳 左右 / 上下 | eye | -1 | 1 | 0 | MVP |
| MouthOpen | 口 開閉 | mouth | 0 | 1 | 0 | MVP |
| EyeSmileL / EyeSmileR | 目 笑顔 L / R | eye | 0 | 1 | 0 | STEP1 |
| BrowYL / BrowYR | 眉 上下 L / R | brow | -1 | 1 | 0 | STEP1 |
| BrowFormL / BrowFormR | 眉 形 L / R（困り〜怒り） | brow | -1 | 1 | 0 | STEP1 |
| MouthForm | 口 形（への字〜笑顔） | mouth | -1 | 1 | 0 | STEP1 |
| MouthWidth | 口 横幅（すぼめ〜横に開く） | mouth | -1 | 1 | 0 | STEP1 |
| Cheek | 頬染め | cheek | 0 | 1 | 0 | STEP1 |
| BodyAngleX / BodyAngleY / BodyAngleZ | 体 左右 / 上下 / 傾き | body | -10 | 10 | 0 | STEP1 |
| Breath | 呼吸 | body | 0 | 1 | 0 | STEP2 |
| ArmL / ArmR | 腕 L / R | armL / armR | -1 | 1 | 0 | STEP2 |
| HairFront / HairSide / HairBack | 髪揺れ 前 / 横 / 後ろ | sway | -1 | 1 | 0 | STEP2 |

## 作らないもの

実行時の処理（評価・描画など）。

## 完了条件

- [ ] createEmptyProject の結果が validateProject を通る
- [ ] 型が違う項目でパス付きのエラーになる
- [ ] v1 の migrate が何も変えず、v2 のファイルはエラーになる
- [ ] ensureStandardParameters が足りないものだけを足す
- [ ] STANDARD_PARAMETERS が表と一致する（id・範囲・デフォルト値・グループ）
- [ ] depthParallaxOffset の符号（奥行きが正で値が正のとき、x は正・y は負）
