# 03. 実行時の契約と仮実装

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | MVP / M0 基盤 |
| 並行作業 | 直列。前の番号のカードが終わってから始める |
| 担当の目安 | 基盤 |
| 作業場所 | packages/contracts/src/、fixtures/sample-model/ |

## 目的

部品どうしをつなぐインターフェースを確定させ、仮実装を用意する。これで部品のカードが互いを待たずに作れる。

## 前提（このカードの時点ですでにあるもの）

`@app/schema` に型・検証・既定値・規則がある（下に抜粋）。

### リポジトリの約束

- pnpm ワークスペースのモノレポ。TypeScript は strict、テストは Vitest。
- パッケージ: `@app/schema`（packages/schema。データ型・検証・既定値・規則）、`@app/contracts`（packages/contracts。実行時のインターフェースと仮実装）、`@app/core`（packages/core。評価・変形・生成・合成・ストア。DOMに依存しない）、`@app/render`（packages/render。WebGL2）、`@app/io`（packages/io。取り込み・保存）、`@app/tracking`（packages/tracking）、`@app/audio`（packages/audio）、`apps/desktop`（Tauri 2 + React）。
- パッケージから参照してよいのは `@app/schema` と `@app/contracts` だけ（同じパッケージの中は自由）。すべてを組み合わせるのは apps/desktop だけ。
- データは不変に扱い、更新は新しいオブジェクトを返す。
- ロジックには必ずユニットテストを付ける。

### Model と Project（@app/schema）

```ts
export interface Model {
  parts: Part[];
  meshes: Mesh[];
  warps: Warp[];
  drawOrder: Id[];                 // 画像パーツの id。背面 → 前面
  parameters: Parameter[];
  parameterGroups: ParameterGroup[];
  bindings: Binding[];
  lipSync: LipSync;
  setupHints: { closedLineL: Vec2[] | null; closedLineR: Vec2[] | null };   // かんたんセットアップ用（閉じた目の線。STEP1で使う）
}
export interface Project {
  schemaVersion: number;           // 現在は 1
  id: Id;
  name: string;
  assets: Asset[];
  model: Model;
  expressions: Expression[];
  animations: Animation[];
  physics: Physics[];
  trackingMappings: TrackingMapping[];   // 空なら既定のマッピング
  studio: { scenes: Scene[]; activeSceneId: Id | null; hotkeys: Hotkey[] };
}
```

### Binding と ParameterKey（@app/schema）

```ts
export type Channel = 'transform' | 'vertices' | 'warpPoints';
export interface TransformDelta { position: Vec2; rotation: number; scale: Vec2; opacity: number }
// position・rotation は加算、scale・opacity は倍率（1 = 変化なし）
export interface Binding {
  id: Id;
  target: { type: 'part' | 'mesh' | 'warp'; id: Id };   // transform → part、vertices → mesh、warpPoints → warp
  channel: Channel;
  parameterIds: Id[];              // 1 または 2
  keyValues: number[][];           // パラメータごとのキー位置（昇順。デフォルト値を必ず含む）
  keys: ParameterKey[];
  generation: 'linear' | 'depth' | 'rotate' | 'surface' | 'ease';
  divisions: number | null;        // 中間キーの分割数（自動なら null）
}
export interface ParameterKey {
  coords: number[];                // parameterIds と同じ順の値
  delta: TransformDelta | Vec2[];  // transform は TransformDelta、それ以外は頂点・制御点ごとの差分
  source: 'manual' | 'auto' | 'generated' | 'combined';
  locked: boolean;
}
```

### スキーマの関数（@app/schema）

```ts
export const SCHEMA_VERSION = 1;
export function validateProject(json: unknown): Project;       // 失敗時は項目のパス付きのエラー
export function migrate(json: unknown): unknown;               // 古い版を現在の版へ変換
export function loadProjectJson(text: string): Project;        // 解析 → migrate → validate
export function createEmptyProject(name: string): Project;     // MVPの標準パラメータ入り
export function ensureStandardParameters(model: Model, phase: 'mvp' | 'step1' | 'step2'): Model;
```

## 作るもの

- `index.ts` に下のインターフェースをそのまま定義する（スキーマの型は `@app/schema` から import する）。
- `fakes/` に下の仮実装を作る。
- `assets.ts` に `createAssetRepository()` の本物の実装（PNG を createImageBitmap で画像にし、ImageData は OffscreenCanvas で取り出す）。
- `fixtures/sample-model/`: 生成スクリプト（Node + @napi-rs/canvas）で単純な図形のテスト用素材を作る。キャンバスは 1000×1500px。顔・耳・白目・瞳・ハイライト・上下まぶた・眉・上下唇・口の中・歯・舌・前髪・横髪・後ろ髪・首・胴体・腕を、目を開け口を閉じた状態で描く。標準パーツへの割り当てだけ済んだ project.json（階層・バインディングなし）も出力する。

### 評価の契約（@app/contracts）

```ts
export type ParamValues = Record<string, number>;
export interface TargetDeltas {
  transforms: Record<string, TransformDelta>;   // partId → 合成済みの差分
  vertices: Record<string, Float32Array>;        // meshId → [dx0, dy0, dx1, dy1, ...]
  warpPoints: Record<string, Float32Array>;      // warpId → 制御点の差分（同じ並び）
}
export interface BindingEvaluator { evaluate(model: Model, params: ParamValues): TargetDeltas }
```

### 変形の契約（@app/contracts）

```ts
export interface DrawItem {
  partId: string; assetId: string;
  positions: Float32Array;         // 変形後の頂点（キャンバス座標）[x0, y0, x1, y1, ...]
  uvs: Float32Array;               // [u0, v0, ...]（0..1）
  indices: Uint32Array;
  opacity: number;                 // 親まで掛けた最終値
  blendMode: BlendMode;
  mask: { sourcePartIds: string[]; inverted: boolean } | null;
}
export interface DeformedModel {
  items: DrawItem[];               // 描画順（背面 → 前面）。非表示のパーツは含めない
  byPartId: Record<string, DrawItem>;
}
export interface DeformPipeline { deform(model: Model, deltas: TargetDeltas): DeformedModel }
```

### 合成の契約（@app/contracts）

```ts
export type LayerId = 'tracking' | 'bodyFollow' | 'expression' | 'animation' | 'lipSync' | 'periodic' | 'physics';
export const LAYER_ORDER: LayerId[] = ['tracking', 'bodyFollow', 'expression', 'animation', 'lipSync', 'periodic', 'physics'];
export interface Layer {
  id: LayerId;
  weight: number;                     // 0..1
  values: ParamValues;                // このレイヤーが担当するパラメータの値だけ
  blend?: Record<string, BlendOp>;    // パラメータごとの合成方法。無ければ override
}
export interface ParameterMixer { mix(parameters: Parameter[], layers: Layer[]): ParamValues }

// スタジオの1フレームの文脈。producer は LAYER_ORDER の順に呼ばれる
export interface FrameContext {
  now: number; dt: number;            // ミリ秒
  project: Project;
  mixedSoFar: ParamValues;            // それまでのレイヤーを合成した値
  flags: { lipSyncWeight: number; physicsActive: boolean };   // 前のレイヤーが後のレイヤーへ伝える値（初期値 1・true）
}
export interface LayerProducer { id: LayerId; produce(ctx: FrameContext): Layer | null }
```

### 描画の契約（@app/contracts）

```ts
export type Background = { type: 'transparent' } | { type: 'color'; color: string } | { type: 'image'; image: ImageBitmap };
export interface ViewTransform { scale: number; offset: Vec2 }   // 画面座標（CSSピクセル）= キャンバス座標 × scale + offset
export interface Renderer {
  init(canvas: HTMLCanvasElement): void;
  setTextures(images: Record<string, ImageBitmap>): void;       // assetId → 画像
  render(model: DeformedModel, view: ViewTransform, background: Background): void;
  dispose(): void;
}
```

### ストアの契約（@app/contracts）

```ts
export interface Command { label: string; apply(project: Project): Project }   // 純粋関数
export interface ProjectStore {
  get(): Project;
  subscribe(listener: (project: Project) => void): () => void;
  dispatch(command: Command): void;                                          // 1回の Undo 単位
  transaction(label: string, run: (dispatch: (c: Command) => void) => void): void;   // まとめて1回の Undo
  undo(): void; redo(): void; canUndo(): boolean; canRedo(): boolean;
  load(project: Project): void;                                              // 履歴を消して置き換える
}
export interface EditorState {
  mode: ModeId;
  uiLevel: Record<ModeId, UiLevel>;
  selectedPartIds: string[];
  activeParameterIds: string[];        // 編集中のパラメータ（0〜2個）
  editorParamValues: ParamValues;      // モデリング中のプレビュー値（無いパラメータはデフォルト値）
}
export interface EditorStore { get(): EditorState; set(patch: Partial<EditorState>): void; subscribe(l: (s: EditorState) => void): () => void }
```

### 素材の置き場の契約（@app/contracts）

```ts
export interface AssetRepository {
  put(assetId: string, png: Uint8Array): Promise<void>;   // 画像も作って保持する
  getPng(assetId: string): Uint8Array | undefined;
  getImage(assetId: string): ImageBitmap | undefined;
  getImageData(assetId: string): ImageData | undefined;   // メッシュ生成などに使う
  all(): Record<string, Uint8Array>;
  subscribe(listener: () => void): () => void;
}
export function createAssetRepository(): AssetRepository;   // 本物の実装
```

### 取り込み・保存の契約（@app/contracts）

```ts
export interface FileSystem {          // パスは / 区切りの絶対パス
  readText(path: string): Promise<string>; writeText(path: string, data: string): Promise<void>;
  readBinary(path: string): Promise<Uint8Array>; writeBinary(path: string, data: Uint8Array): Promise<void>;
  exists(path: string): Promise<boolean>; mkdir(path: string): Promise<void>;
  list(dir: string): Promise<string[]>; remove(path: string): Promise<void>; rename(from: string, to: string): Promise<void>;
}
export interface ImportedAsset { asset: Asset; png: Uint8Array }   // png はトリミング済み
export interface ImportWarning { kind: 'canvasMismatch' | 'noTransparency' | 'resolution' | 'needsMerge'; assetIds: string[]; layerNames: string[]; message: string }
export interface Importer { importFiles(files: { name: string; data: Uint8Array }[]): Promise<{ assets: ImportedAsset[]; warnings: ImportWarning[] }> }
export interface ProjectIO {
  save(dir: string, project: Project, assetPngs: Record<string, Uint8Array>): Promise<void>;
  load(dir: string): Promise<{ project: Project; assetPngs: Record<string, Uint8Array> }>;
}
export interface AutoSaver { start(dir: string): void; stop(): void; findRecoverable(dir: string): Promise<string | null> }
```

### メッシュ生成の契約（@app/contracts）

```ts
export interface MeshGenerator {
  generate(alpha: ImageData, offset: Vec2, density: 'light' | 'standard' | 'smooth'):
    { vertices: Vec2[]; uvs: Vec2[]; triangles: [number, number, number][] };   // 頂点はキャンバス座標
}
```

### 生成・セットアップの契約（@app/contracts）

```ts
export interface KeyGenerator {
  linear(binding: Binding, divisions?: number): Binding;
  depthParallax(model: Model, parameterId: 'FaceAngleX' | 'FaceAngleY'): Binding[];   // 作り直した transform バインディング
}
export interface AutoSetup { plan(project: Project): { command: Command; warnings: string[] } }
```

### キー編集の契約（@app/contracts）

```ts
export type TransformChange = { dPosition?: Vec2; dRotation?: number; scaleFactor?: Vec2; opacityFactor?: number; dPivot?: Vec2 };
export type PointsTarget = { kind: 'mesh'; meshId: string } | { kind: 'warp'; warpId: string };
export interface KeyEditor {
  // EditorState の activeParameterIds と editorParamValues に応じて、基準状態かキーを変えるコマンドを返す
  transformEdit(project: Project, editor: EditorState, partIds: string[], change: TransformChange): Command | 'needsKey';
  pointsEdit(project: Project, editor: EditorState, target: PointsTarget, moves: { index: number; d: Vec2 }[]): Command | 'needsKey';
  addKeyAtCurrentValue(project: Project, editor: EditorState, target: { partId: string } | PointsTarget): Command;
}
```

### トラッキングの契約（@app/contracts）

```ts
export interface TrackingFrame {
  time: number;                    // ミリ秒（performance.now）
  detected: boolean;
  faceYaw: number;                 // 度。ユーザーが自分の右を向くと正
  facePitch: number;               // 度。上を向くと正
  faceRoll: number;                // 度。ユーザーが自分の右へ傾けると正
  eyeOpenL: number; eyeOpenR: number;   // 0..1。ユーザー自身の左目・右目
  eyeBallX: number;                // -1..1。ユーザーが自分の右を見ると正
  eyeBallY: number;                // -1..1。上を見ると正
  mouthOpen: number;               // 0..1
}
export interface TrackingSource {
  listDevices(): Promise<{ id: string; label: string }[]>;
  start(deviceId?: string): Promise<void>;
  stop(): void;
  onFrame(listener: (frame: TrackingFrame) => void): () => void;
}
export interface TrackingLayerProducer {
  update(frame: TrackingFrame): void;
  tick(now: number): Layer;        // id 'tracking'
  status(): 'tracking' | 'lost';
  setMirror(on: boolean): void;
  setLostBehavior(b: 'returnToFront' | 'hold'): void;
}
```

### サービスのまとめ（@app/contracts）

```ts
export interface Services {
  store: ProjectStore; editor: EditorStore; assets: AssetRepository; fs: FileSystem;
  evaluator: BindingEvaluator; pipeline: DeformPipeline; mixer: ParameterMixer; createRenderer(): Renderer;
  meshGenerator: MeshGenerator; keyGenerator: KeyGenerator; autoSetup: AutoSetup; keyEditor: KeyEditor;
  importer: Importer; io: ProjectIO; autoSaver: AutoSaver;
  tracking: TrackingSource; trackingLayer: TrackingLayerProducer;
}
```

### 仮実装（@app/contracts の fakes）

- FakeEvaluator: 差分なし（すべて空）を返す。
- FakePipeline: 表示中の画像パーツを、素材の矩形（offset と幅・高さ）を覆う三角形2枚にし、自身のパーツの基本の変形だけを掛ける。順番は drawOrder。
- FakeRenderer: Canvas 2D で、各 DrawItem の画像を頂点の外接矩形に drawImage する。
- FakeMixer: デフォルト値に、各レイヤーの値を重みで上書きする。
- FakeTrackingSource: 30fps で顔をゆっくり左右に振る TrackingFrame を出す。20秒ごとに2秒間 detected を false にする。
- FakeTrackingLayer: フレームの値をそのままパラメータに写す（ミラー・スムージングなし）。
- FakeImporter: PNG だけを読み、トリミングせず offset (0,0) で返す。
- MemoryFileSystem、FakeProjectIO（メモリに保存）、FakeAutoSaver（何もしない）。
- FakeMeshGenerator: 画像全体を覆う四角形（三角形2枚）。
- FakeKeyGenerator・FakeAutoSetup: 何も変えないコマンド・バインディングを返す。
- FakeKeyEditor: 常に基準状態（Part の position・rotation・scale・pivot・opacity、メッシュの基準頂点）を変えるコマンドを返す。
- fixtures/sample-model: 単純な図形で描いたテスト用素材（1000×1500px、標準パーツ一式）と、割り当てだけ済んだ project.json。

## 作らないもの

本物の評価・描画・推定など（仮実装だけ）。

## 完了条件

- [ ] 型検査が通る
- [ ] 仮実装それぞれに簡単なテストがある
- [ ] fixtures の project.json が validateProject を通る
