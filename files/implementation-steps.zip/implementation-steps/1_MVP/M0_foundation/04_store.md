# 04. ストアとコマンド（Undo / Redo）

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | MVP / M0 基盤 |
| 並行作業 | 直列。前の番号のカードが終わってから始める |
| 担当の目安 | 基盤 |
| 作業場所 | packages/core/src/store/ |

## 目的

すべての編集をコマンドとして扱い、Undo / Redo できる状態の入れ物を作る。

## 前提（このカードの時点ですでにあるもの）

`@app/contracts` に Command・ProjectStore・EditorStore のインターフェースがある（下）。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### リポジトリの約束

- pnpm ワークスペースのモノレポ。TypeScript は strict、テストは Vitest。
- パッケージ: `@app/schema`（packages/schema。データ型・検証・既定値・規則）、`@app/contracts`（packages/contracts。実行時のインターフェースと仮実装）、`@app/core`（packages/core。評価・変形・生成・合成・ストア。DOMに依存しない）、`@app/render`（packages/render。WebGL2）、`@app/io`（packages/io。取り込み・保存）、`@app/tracking`（packages/tracking）、`@app/audio`（packages/audio）、`apps/desktop`（Tauri 2 + React）。
- パッケージから参照してよいのは `@app/schema` と `@app/contracts` だけ（同じパッケージの中は自由）。すべてを組み合わせるのは apps/desktop だけ。
- データは不変に扱い、更新は新しいオブジェクトを返す。
- ロジックには必ずユニットテストを付ける。

### Model と Project（@app/schema）

```ts
export interface Model {
  parts: Part[];
  meshes: Mesh[];
  warps: Warp[];
  drawOrder: Id[];                 // 画像パーツの id。背面 → 前面
  parameters: Parameter[];
  parameterGroups: ParameterGroup[];
  bindings: Binding[];
  lipSync: LipSync;
  setupHints: { closedLineL: Vec2[] | null; closedLineR: Vec2[] | null };   // かんたんセットアップ用（閉じた目の線。STEP1で使う）
}
export interface Project {
  schemaVersion: number;           // 現在は 1
  id: Id;
  name: string;
  assets: Asset[];
  model: Model;
  expressions: Expression[];
  animations: Animation[];
  physics: Physics[];
  trackingMappings: TrackingMapping[];   // 空なら既定のマッピング
  studio: { scenes: Scene[]; activeSceneId: Id | null; hotkeys: Hotkey[] };
}
```

### ストアの契約（@app/contracts）

```ts
export interface Command { label: string; apply(project: Project): Project }   // 純粋関数
export interface ProjectStore {
  get(): Project;
  subscribe(listener: (project: Project) => void): () => void;
  dispatch(command: Command): void;                                          // 1回の Undo 単位
  transaction(label: string, run: (dispatch: (c: Command) => void) => void): void;   // まとめて1回の Undo
  undo(): void; redo(): void; canUndo(): boolean; canRedo(): boolean;
  load(project: Project): void;                                              // 履歴を消して置き換える
}
export interface EditorState {
  mode: ModeId;
  uiLevel: Record<ModeId, UiLevel>;
  selectedPartIds: string[];
  activeParameterIds: string[];        // 編集中のパラメータ（0〜2個）
  editorParamValues: ParamValues;      // モデリング中のプレビュー値（無いパラメータはデフォルト値）
}
export interface EditorStore { get(): EditorState; set(patch: Partial<EditorState>): void; subscribe(l: (s: EditorState) => void): () => void }
```

## 作るもの

- `createProjectStore(initial: Project): ProjectStore` と `createEditorStore(initial?: Partial<EditorState>): EditorStore`。
- dispatch: `command.apply(現在)` を新しい状態にし、前の状態を履歴に積む。結果が同じ参照なら何もしない。
- transaction: 中の dispatch をまとめて1回の Undo にする。入れ子はいちばん外側にまとめる。中で例外が出たら開始前の状態に戻し、例外を投げ直す。
- undo / redo: 履歴は最大200件。新しい dispatch で redo の履歴を消す。
- load: 状態を置き換え、履歴を消す。
- subscribe: 状態が変わるたびに同期で通知する。解除関数を返す。
- 補助関数: `modelCommand(label, fn: (model: Model) => Model): Command`、`patchPart(label, partId, patch: Partial<Part>): Command`。
- EditorState の初期値: mode 'modeling'、uiLevel はすべて 'easy'、selectedPartIds []、activeParameterIds []、editorParamValues {}。

## 作らないもの

個別の編集コマンド（各機能のカードが作る）。

## 完了条件

- [ ] dispatch → undo → redo で状態が行き来する
- [ ] transaction が1回の Undo になり、例外で元に戻る
- [ ] 新しい dispatch で redo が消える
- [ ] 履歴が200件を超えると古いものから消える
- [ ] load で履歴が消える
