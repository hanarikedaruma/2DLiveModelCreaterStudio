# 06. バインディングの評価

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | MVP / M1 部品 |
| 並行作業 | 同じ段階の 06〜22 と並行して作れる（触るフォルダは重ならない） |
| 担当の目安 | コア |
| 作業場所 | packages/core/src/eval/ |

## 目的

パラメータの値から、対象ごとの差分の合計（TargetDeltas）を求める。

## 前提（このカードの時点ですでにあるもの）

`@app/schema` と `@app/contracts` に下の型とインターフェースがある。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### 座標と値の約束

- 座標はキャンバス（元のPSD・PNG）のピクセル。原点は左上、x は右、y は下が正。
- 回転は度。画面上の時計回りが正。
- L / R はキャラクター自身から見た左右。画面では L が右側に描かれる。
- FaceAngleX はキャラクターが画面の右を向くと正、FaceAngleY は上を向くと正、FaceAngleZ は時計回りが正。EyeBallX は画面の右を見ると正、EyeBallY は上を見ると正。
- 基準状態 = 素材を配置しただけの状態 = 全パラメータがデフォルト値の状態。素材は「目を開け、口を閉じた」状態で描かれている前提。
- キーは基準状態からの差分。位置・回転・頂点は加算、拡縮・不透明度は倍率（1 = 変化なし）。

### Parameter と ParameterGroup（@app/schema）

```ts
export interface ParameterGroup { id: ParameterGroupId; name: string }
export interface Parameter {
  id: Id;                          // 標準は 'FaceAngleX' など。ユーザー定義は任意の文字列
  name: string;                    // 表示名
  groupId: ParameterGroupId;
  min: number; max: number; default: number;
  standard: boolean;
}
```

### Binding と ParameterKey（@app/schema）

```ts
export type Channel = 'transform' | 'vertices' | 'warpPoints';
export interface TransformDelta { position: Vec2; rotation: number; scale: Vec2; opacity: number }
// position・rotation は加算、scale・opacity は倍率（1 = 変化なし）
export interface Binding {
  id: Id;
  target: { type: 'part' | 'mesh' | 'warp'; id: Id };   // transform → part、vertices → mesh、warpPoints → warp
  channel: Channel;
  parameterIds: Id[];              // 1 または 2
  keyValues: number[][];           // パラメータごとのキー位置（昇順。デフォルト値を必ず含む）
  keys: ParameterKey[];
  generation: 'linear' | 'depth' | 'rotate' | 'surface' | 'ease';
  divisions: number | null;        // 中間キーの分割数（自動なら null）
}
export interface ParameterKey {
  coords: number[];                // parameterIds と同じ順の値
  delta: TransformDelta | Vec2[];  // transform は TransformDelta、それ以外は頂点・制御点ごとの差分
  source: 'manual' | 'auto' | 'generated' | 'combined';
  locked: boolean;
}
```

### Mesh（@app/schema）

```ts
export interface Mesh {
  id: Id;
  vertices: Vec2[];                // 基準状態の頂点（キャンバス座標）
  uvs: Vec2[];                     // 0..1（素材画像の中の位置）
  triangles: [number, number, number][];
  density: 'light' | 'standard' | 'smooth' | 'custom';
  edited: boolean;                 // 手で編集したか
}
```

### Warp（@app/schema）

```ts
export interface Warp {
  id: Id;
  partId: Id;                      // ワープを付ける group パーツ
  columns: number; rows: number;   // 格子の分割数
  bounds: { x: number; y: number; width: number; height: number };   // キャンバス座標
  points: Vec2[];                  // (columns+1)×(rows+1) 個、行優先。基準状態の制御点
}
```

### Model と Project（@app/schema）

```ts
export interface Model {
  parts: Part[];
  meshes: Mesh[];
  warps: Warp[];
  drawOrder: Id[];                 // 画像パーツの id。背面 → 前面
  parameters: Parameter[];
  parameterGroups: ParameterGroup[];
  bindings: Binding[];
  lipSync: LipSync;
  setupHints: { closedLineL: Vec2[] | null; closedLineR: Vec2[] | null };   // かんたんセットアップ用（閉じた目の線。STEP1で使う）
}
export interface Project {
  schemaVersion: number;           // 現在は 1
  id: Id;
  name: string;
  assets: Asset[];
  model: Model;
  expressions: Expression[];
  animations: Animation[];
  physics: Physics[];
  trackingMappings: TrackingMapping[];   // 空なら既定のマッピング
  studio: { scenes: Scene[]; activeSceneId: Id | null; hotkeys: Hotkey[] };
}
```

### 評価の契約（@app/contracts）

```ts
export type ParamValues = Record<string, number>;
export interface TargetDeltas {
  transforms: Record<string, TransformDelta>;   // partId → 合成済みの差分
  vertices: Record<string, Float32Array>;        // meshId → [dx0, dy0, dx1, dy1, ...]
  warpPoints: Record<string, Float32Array>;      // warpId → 制御点の差分（同じ並び）
}
export interface BindingEvaluator { evaluate(model: Model, params: ParamValues): TargetDeltas }
```

## 作るもの

- `createBindingEvaluator(): BindingEvaluator`。
- 値: params に無いパラメータはデフォルト値。値は min..max に丸める。
- 1パラメータ: keyValues[0] で値をはさむ2つのキーを線形補間する。範囲外は端のキー。キーが1つならその差分。
- 2パラメータ: 格子の双線形補間。格子の点にキーが無いときは、各軸の差分の和で代用する（(x, y) = (x, y0) + (x0, y)。x0・y0 はデフォルト値。どちらも無ければ 0）。
- 補間の対象: transform は position・rotation・scale・opacity を成分ごとに線形補間（scale・opacity は倍率のまま）。vertices・warpPoints は要素ごと。
- 合成: 同じ対象・同じチャンネルの複数のバインディングは、position・rotation・頂点・制御点を加算、scale・opacity を乗算する。
- 差分の配列の長さが対象の頂点数・制御点数と違うバインディングは無視して console.warn（例外にしない）。
- 性能: 頂点の合計 5,000・バインディング 200 で 1回 1ms 未満が目安。毎フレーム呼ばれるので、配列は再利用してよい。

## 作らないもの

階層の変形の適用（別のカード）。

## 完了条件

- [ ] 1パラメータ: キーの間の線形補間、範囲外は端のキー、キー1つの場合
- [ ] 2パラメータ: 双線形補間と、格子に無い組み合わせの代用
- [ ] transform の合成（位置・回転は加算、拡縮・不透明度は乗算）
- [ ] 頂点の加算と、長さの合わない差分の無視
- [ ] 性能テスト（CI では 5ms 未満を条件にする）
