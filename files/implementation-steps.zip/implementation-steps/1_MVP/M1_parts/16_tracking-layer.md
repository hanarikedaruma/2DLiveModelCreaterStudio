# 16. マッピング・スムージング・外れたときの復帰

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | MVP / M1 部品 |
| 並行作業 | 同じ段階の 06〜22 と並行して作れる（触るフォルダは重ならない） |
| 担当の目安 | トラッキング |
| 作業場所 | packages/tracking/src/mapping/ |

## 目的

トラッキングの値をパラメータへ写し、滑らかにし、顔が外れたら正面へ戻す。

## 前提（このカードの時点ですでにあるもの）

`@app/schema` と `@app/contracts` に下の型とインターフェースがある。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### 座標と値の約束

- 座標はキャンバス（元のPSD・PNG）のピクセル。原点は左上、x は右、y は下が正。
- 回転は度。画面上の時計回りが正。
- L / R はキャラクター自身から見た左右。画面では L が右側に描かれる。
- FaceAngleX はキャラクターが画面の右を向くと正、FaceAngleY は上を向くと正、FaceAngleZ は時計回りが正。EyeBallX は画面の右を見ると正、EyeBallY は上を見ると正。
- 基準状態 = 素材を配置しただけの状態 = 全パラメータがデフォルト値の状態。素材は「目を開け、口を閉じた」状態で描かれている前提。
- キーは基準状態からの差分。位置・回転・頂点は加算、拡縮・不透明度は倍率（1 = 変化なし）。

### Parameter と ParameterGroup（@app/schema）

```ts
export interface ParameterGroup { id: ParameterGroupId; name: string }
export interface Parameter {
  id: Id;                          // 標準は 'FaceAngleX' など。ユーザー定義は任意の文字列
  name: string;                    // 表示名
  groupId: ParameterGroupId;
  min: number; max: number; default: number;
  standard: boolean;
}
```

### TrackingMapping（@app/schema）

```ts
export type TrackingInput = 'faceYaw' | 'facePitch' | 'faceRoll' | 'eyeOpenL' | 'eyeOpenR' | 'eyeBallX' | 'eyeBallY'
  | 'mouthOpen' | 'mouthForm' | 'mouthWidth' | 'browY';
export interface TrackingMapping {
  input: TrackingInput; parameterId: Id;
  inputRange: [number, number]; outputRange: [number, number];
  invert: boolean; curve: 'linear' | 'smooth';
  smoothing: number;               // 0..1
  deadZone: number;                // 入力の単位
}
```

### トラッキングの契約（@app/contracts）

```ts
export interface TrackingFrame {
  time: number;                    // ミリ秒（performance.now）
  detected: boolean;
  faceYaw: number;                 // 度。ユーザーが自分の右を向くと正
  facePitch: number;               // 度。上を向くと正
  faceRoll: number;                // 度。ユーザーが自分の右へ傾けると正
  eyeOpenL: number; eyeOpenR: number;   // 0..1。ユーザー自身の左目・右目
  eyeBallX: number;                // -1..1。ユーザーが自分の右を見ると正
  eyeBallY: number;                // -1..1。上を見ると正
  mouthOpen: number;               // 0..1
}
export interface TrackingSource {
  listDevices(): Promise<{ id: string; label: string }[]>;
  start(deviceId?: string): Promise<void>;
  stop(): void;
  onFrame(listener: (frame: TrackingFrame) => void): () => void;
}
export interface TrackingLayerProducer {
  update(frame: TrackingFrame): void;
  tick(now: number): Layer;        // id 'tracking'
  status(): 'tracking' | 'lost';
  setMirror(on: boolean): void;
  setLostBehavior(b: 'returnToFront' | 'hold'): void;
}
```

### 合成の契約（@app/contracts）

```ts
export type LayerId = 'tracking' | 'bodyFollow' | 'expression' | 'animation' | 'lipSync' | 'periodic' | 'physics';
export const LAYER_ORDER: LayerId[] = ['tracking', 'bodyFollow', 'expression', 'animation', 'lipSync', 'periodic', 'physics'];
export interface Layer {
  id: LayerId;
  weight: number;                     // 0..1
  values: ParamValues;                // このレイヤーが担当するパラメータの値だけ
  blend?: Record<string, BlendOp>;    // パラメータごとの合成方法。無ければ override
}
export interface ParameterMixer { mix(parameters: Parameter[], layers: Layer[]): ParamValues }

// スタジオの1フレームの文脈。producer は LAYER_ORDER の順に呼ばれる
export interface FrameContext {
  now: number; dt: number;            // ミリ秒
  project: Project;
  mixedSoFar: ParamValues;            // それまでのレイヤーを合成した値
  flags: { lipSyncWeight: number; physicsActive: boolean };   // 前のレイヤーが後のレイヤーへ伝える値（初期値 1・true）
}
export interface LayerProducer { id: LayerId; produce(ctx: FrameContext): Layer | null }
```

## 作るもの

- `createTrackingLayerProducer(parameters: Parameter[], mappings?: TrackingMapping[]): TrackingLayerProducer`。
- 既定のマッピング（mappings が空のとき）: faceYaw → FaceAngleX、facePitch → FaceAngleY、faceRoll → FaceAngleZ（[−30, 30] → [−30, 30]）、eyeOpenL / R → EyeOpenL / R、eyeBallX / Y → EyeBallX / Y、mouthOpen → MouthOpen（同じ範囲のまま）。
- ミラー（初期値オン）: オンでは鏡のように映す。yaw・roll・eyeBallX はそのままの符号にし、左右の目を入れ替える（ユーザーの右目 → EyeOpenL）。オフでは yaw・roll・eyeBallX の符号を反転し、目は入れ替えない。
- 写像: inputRange → outputRange の線形（範囲外は丸める）、invert、deadZone（入力の中央 ± deadZone は中央の値にする）、curve 'smooth' は smoothstep。
- スムージング: 値ごとに One Euro Filter（minCutoff 1.0、beta 0.02、dCutoff 1.0 が初期値。mapping.smoothing の 0..1 を minCutoff の 3.0〜0.3 に割り当てる）。
- tick(now) が返すレイヤー: id 'tracking'、values = 写像後の値、blend なし（override）、weight は次の規則。
- 外れたとき: 最後に detected だった時刻から 0.5秒たったら、weight を 1 → 0 へ 1秒かけて下げる（ease-in-out）。値は最後の値のまま。再び detected になったら 0.3秒で 1 に戻す。setLostBehavior('hold') のときは weight を 1 のまま保つ。status() は 'tracking' か 'lost'。

## 作らないもの

キャリブレーション、簡易設定、自動まばたき（STEP1）。

## 完了条件

- [ ] 写像・invert・deadZone・丸め
- [ ] ミラーのオン・オフでの符号と左右の入れ替え
- [ ] スムージング: 段差の入力に対し、30fps で 150ms 以内に 90% へ届く
- [ ] 外れたときの weight（0.5秒・1.0秒・1.5秒の時点）と、再検出で 0.3秒で戻る
- [ ] hold のとき weight が 1 のまま
