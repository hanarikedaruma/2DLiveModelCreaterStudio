# 12. WebGL2レンダラー（マスク・背景を含む）

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | MVP / M1 部品 |
| 並行作業 | 同じ段階の 06〜22 と並行して作れる（触るフォルダは重ならない） |
| 担当の目安 | 描画 |
| 作業場所 | packages/render/src/ |

## 目的

変形済みのモデルを、透過の縁が黒ずまない品質で GPU 描画する。

## 前提（このカードの時点ですでにあるもの）

`@app/schema` と `@app/contracts` に下の型とインターフェースがある。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### 基本の型（@app/schema）

```ts
export type Id = string;
export interface Vec2 { x: number; y: number }
export type BlendMode = 'normal' | 'multiply' | 'screen' | 'add';
export type ParameterGroupId = 'face' | 'eye' | 'brow' | 'mouth' | 'cheek' | 'body' | 'armL' | 'armR' | 'sway' | 'other';
export type ModeId = 'modeling' | 'animation' | 'studio';
export type UiLevel = 'easy' | 'detail';
export function newId(): string;   // ULID
```

### 変形の契約（@app/contracts）

```ts
export interface DrawItem {
  partId: string; assetId: string;
  positions: Float32Array;         // 変形後の頂点（キャンバス座標）[x0, y0, x1, y1, ...]
  uvs: Float32Array;               // [u0, v0, ...]（0..1）
  indices: Uint32Array;
  opacity: number;                 // 親まで掛けた最終値
  blendMode: BlendMode;
  mask: { sourcePartIds: string[]; inverted: boolean } | null;
}
export interface DeformedModel {
  items: DrawItem[];               // 描画順（背面 → 前面）。非表示のパーツは含めない
  byPartId: Record<string, DrawItem>;
}
export interface DeformPipeline { deform(model: Model, deltas: TargetDeltas): DeformedModel }
```

### 描画の契約（@app/contracts）

```ts
export type Background = { type: 'transparent' } | { type: 'color'; color: string } | { type: 'image'; image: ImageBitmap };
export interface ViewTransform { scale: number; offset: Vec2 }   // 画面座標（CSSピクセル）= キャンバス座標 × scale + offset
export interface Renderer {
  init(canvas: HTMLCanvasElement): void;
  setTextures(images: Record<string, ImageBitmap>): void;       // assetId → 画像
  render(model: DeformedModel, view: ViewTransform, background: Background): void;
  dispose(): void;
}
```

## 作るもの

- `createWebGLRenderer(): Renderer`。
- コンテキスト: WebGL2、alpha true、premultipliedAlpha true、antialias true。CSSサイズ × devicePixelRatio で描画バッファを合わせる。
- テクスチャ: 乗算済みアルファで持つ（UNPACK_PREMULTIPLY_ALPHA_WEBGL）。ミップマップと LINEAR_MIPMAP_LINEAR。MAX_TEXTURE_SIZE を超える画像は縮小して console.warn。
- 描画: 背景 → items の順。不透明度は uniform で掛ける。合成は `blend.ts` の `applyBlend(gl, mode: BlendMode)` に集める。今は normal（ONE, ONE_MINUS_SRC_ALPHA）だけを実装し、ほかの値も normal で描く（後のカードで足す）。
- マスク: マスク元（sourcePartIds の items）のアルファを、画面サイズの1チャンネルのオフスクリーンへ最大値で描く（＝範囲の和）。inverted なら 1 − a にする。その値を対象のアルファに掛けて描く。マスク元の形には、マスク元自身のマスクを掛けない。マスク元が items に無い（非表示など）場合は空のマスク（対象は表示されない）。同じマスク元の組の結果はフレーム内で使い回してよい。
- 背景: transparent はアルファ 0 で消す。color は塗る。image は縦横比を保って全体を覆う。
- view: 画面座標 = キャンバス座標 × scale + offset（CSSピクセル）。
- コンテキストを失って復帰したら、テクスチャを作り直す。

## 作らないもの

乗算・スクリーン・加算の合成（STEP1）、出力ウィンドウ。

## 完了条件

- [ ] 1枚の画像が正しい位置・色で描かれる（ピクセルのテスト。Vitest のブラウザモードか Playwright）
- [ ] 半透明の縁を白背景に描いたとき、期待値との差が ±2 以内（黒ずまない）
- [ ] 不透明度と描画順
- [ ] マスク: 範囲外が消える、反転、複数のマスク元の和
- [ ] 透明背景でアルファが 0 になる
- [ ] 60個・頂点 5,000 の描画が基準PCで 60fps（手動で確認）
