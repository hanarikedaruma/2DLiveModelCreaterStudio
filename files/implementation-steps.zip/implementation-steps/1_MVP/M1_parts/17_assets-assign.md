# 17. 素材トレイと標準パーツの割り当て

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | MVP / M1 部品 |
| 並行作業 | 同じ段階の 06〜22 と並行して作れる（触るフォルダは重ならない） |
| 担当の目安 | 画面 |
| 作業場所 | apps/desktop/src/modes/modeling/assets/ |

## 目的

素材を取り込み、標準パーツの枠へドラッグで割り当てられるようにする。

## 前提（このカードの時点ですでにあるもの）

アプリの枠の差し込み口と、services（仮実装）がある。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### アプリの枠の差し込み口（apps/desktop/src/shell/api.ts）

```ts
export interface PanelDef { id: string; mode: ModeId; area: 'left' | 'right' | 'bottom'; title: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanel(def: PanelDef): void;
export interface SectionDef { id: string; panelId: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanelSection(def: SectionDef): void;      // パネルの中の <PanelSections panelId=… /> に入る
export function PanelSections(props: { panelId: string }): JSX.Element;
export function registerCenter(mode: 'studio' | 'animation', component: React.FC): void;
export function registerSetupScreen(component: React.FC): void;   // 素材が1つも無いとき中央に出す
export function registerMenuItem(item: { id: string; label: string; shortcut?: string; run(): void }): void;

export interface CanvasPointerEvent { canvasPoint: Vec2; screenPoint: Vec2; button: number; shiftKey: boolean; altKey: boolean; ctrlKey: boolean }
export interface CanvasTool {
  id: string; label: string; cursor?: string;
  onPointerDown?(e: CanvasPointerEvent): void; onPointerMove?(e: CanvasPointerEvent): void; onPointerUp?(e: CanvasPointerEvent): void;
  onKeyDown?(e: KeyboardEvent): void;
  drawOverlay?(ctx: CanvasRenderingContext2D, view: ViewTransform): void;
}
export function registerCanvasTool(tool: CanvasTool): void;        // 最初に登録したものが既定のツール
export function registerCanvasOverlay(id: string, draw: (ctx: CanvasRenderingContext2D, view: ViewTransform) => void): void;
export function useCanvas(): { view: ViewTransform; activeToolId: string; setActiveTool(id: string): void; requestRedraw(): void; lastDeformed(): DeformedModel | null; screenToCanvas(p: Vec2): Vec2 };

export function useServices(): Services;
export function useProject(): Project;
export function useDispatch(): (c: Command) => void;
export function useEditor(): [EditorState, (patch: Partial<EditorState>) => void];
export function useEnvironment(): [Environment, (patch: Partial<Environment>) => void];
export function useDialogs(): { confirm(message: string): Promise<boolean>; notify(message: string): void; prompt(message: string, initial?: string): Promise<string | null> };
export function emitAppEvent(name: string, payload?: unknown): void;
export function onAppEvent(name: string, listener: (payload: unknown) => void): () => void;
```

### サービスのまとめ（@app/contracts）

```ts
export interface Services {
  store: ProjectStore; editor: EditorStore; assets: AssetRepository; fs: FileSystem;
  evaluator: BindingEvaluator; pipeline: DeformPipeline; mixer: ParameterMixer; createRenderer(): Renderer;
  meshGenerator: MeshGenerator; keyGenerator: KeyGenerator; autoSetup: AutoSetup; keyEditor: KeyEditor;
  importer: Importer; io: ProjectIO; autoSaver: AutoSaver;
  tracking: TrackingSource; trackingLayer: TrackingLayerProducer;
}
```

### 取り込み・保存の契約（@app/contracts）

```ts
export interface FileSystem {          // パスは / 区切りの絶対パス
  readText(path: string): Promise<string>; writeText(path: string, data: string): Promise<void>;
  readBinary(path: string): Promise<Uint8Array>; writeBinary(path: string, data: Uint8Array): Promise<void>;
  exists(path: string): Promise<boolean>; mkdir(path: string): Promise<void>;
  list(dir: string): Promise<string[]>; remove(path: string): Promise<void>; rename(from: string, to: string): Promise<void>;
}
export interface ImportedAsset { asset: Asset; png: Uint8Array }   // png はトリミング済み
export interface ImportWarning { kind: 'canvasMismatch' | 'noTransparency' | 'resolution' | 'needsMerge'; assetIds: string[]; layerNames: string[]; message: string }
export interface Importer { importFiles(files: { name: string; data: Uint8Array }[]): Promise<{ assets: ImportedAsset[]; warnings: ImportWarning[] }> }
export interface ProjectIO {
  save(dir: string, project: Project, assetPngs: Record<string, Uint8Array>): Promise<void>;
  load(dir: string): Promise<{ project: Project; assetPngs: Record<string, Uint8Array> }>;
}
export interface AutoSaver { start(dir: string): void; stop(): void; findRecoverable(dir: string): Promise<string | null> }
```

### 素材の置き場の契約（@app/contracts）

```ts
export interface AssetRepository {
  put(assetId: string, png: Uint8Array): Promise<void>;   // 画像も作って保持する
  getPng(assetId: string): Uint8Array | undefined;
  getImage(assetId: string): ImageBitmap | undefined;
  getImageData(assetId: string): ImageData | undefined;   // メッシュ生成などに使う
  all(): Record<string, Uint8Array>;
  subscribe(listener: () => void): () => void;
}
export function createAssetRepository(): AssetRepository;   // 本物の実装
```

### メッシュ生成の契約（@app/contracts）

```ts
export interface MeshGenerator {
  generate(alpha: ImageData, offset: Vec2, density: 'light' | 'standard' | 'smooth'):
    { vertices: Vec2[]; uvs: Vec2[]; triangles: [number, number, number][] };   // 頂点はキャンバス座標
}
```

### 生成・セットアップの契約（@app/contracts）

```ts
export interface KeyGenerator {
  linear(binding: Binding, divisions?: number): Binding;
  depthParallax(model: Model, parameterId: 'FaceAngleX' | 'FaceAngleY'): Binding[];   // 作り直した transform バインディング
}
export interface AutoSetup { plan(project: Project): { command: Command; warnings: string[] } }
```

### Asset（@app/schema）

```ts
export interface Asset {
  id: Id;
  path: string;                    // 例: assets/<id>.png
  hash: string;                    // png の SHA-256（16進）
  width: number; height: number;   // トリミング後のサイズ
  offset: Vec2;                    // トリミング後の左上のキャンバス座標
  canvasSize: { width: number; height: number };
  source: { kind: 'psd' | 'png'; file: string; layerName?: string; layerPath?: string[]; hidden?: boolean };
  sourceBlendMode: BlendMode;
  sourceOpacity: number;           // 0..1
}
```

### Part と StandardPartType（@app/schema）

```ts
export interface Part {
  id: Id;
  name: string;
  kind: 'image' | 'group';
  standardType: StandardPartType | null;   // 自由パーツは null
  assetId: Id | null;                      // image のみ
  meshId: Id | null;                       // image のみ
  parentId: Id | null;
  position: Vec2;                          // 初期値 {x: 0, y: 0}
  rotation: number;                        // 度。初期値 0
  scale: Vec2;                             // 初期値 {x: 1, y: 1}
  pivot: Vec2;                             // 回転・拡縮の中心（キャンバス座標）
  opacity: number;                         // 0..1
  blendMode: BlendMode;
  depth: number;                           // 奥行き。手前が正（-1..1 が目安）
  mask: { sourcePartIds: Id[]; inverted: boolean } | null;
  physicsId: Id | null;
  visible: boolean;
  locked: boolean;
}
export type StandardPartType =
  | 'face' | 'earL' | 'earR' | 'cheek'
  | 'eyeWhiteL' | 'irisL' | 'highlightL' | 'upperLidL' | 'lowerLidL' | 'eyeWholeL'
  | 'eyeWhiteR' | 'irisR' | 'highlightR' | 'upperLidR' | 'lowerLidR' | 'eyeWholeR'
  | 'browL' | 'browR'
  | 'upperLip' | 'lowerLip' | 'mouthInside' | 'teeth' | 'tongue' | 'mouthWhole'
  | 'frontHair' | 'sideHairL' | 'sideHairR' | 'backHair'
  | 'neck' | 'torso' | 'armL' | 'armR'
  // 変形グループ（かんたんセットアップが作る）
  | 'bodyRoot' | 'armRootL' | 'armRootR' | 'neckRoot' | 'headRoot'
  | 'faceGroup' | 'eyeGroupL' | 'eyeGroupR' | 'mouthGroup';
```

### 規則（@app/schema の rules.ts）

```ts
export const STANDARD_PARAMETERS: Parameter[];                      // 標準パラメータの表（standard: true）
export const PARAMETER_GROUPS: ParameterGroup[];                    // face 顔 / eye 目 / brow 眉 / mouth 口 / cheek 頬 / body 体 / armL 左腕 / armR 右腕 / sway 揺れもの / other その他
export const STANDARD_PART_NAMES: Record<StandardPartType, string>; // 日本語の表示名（例: eyeWhiteL → 白目 L）
export const STANDARD_DRAW_ORDER: StandardPartType[];               // 背面 → 前面（下記）
export const DEFAULT_DEPTH: Partial<Record<StandardPartType, number>>;   // 下記
export const PARALLAX_RATIO = 0.08;
// 奥行きによる移動量（px）。faceWidth は standardType 'face' の素材の幅
export function depthParallaxOffset(depth: number, value: number, faceWidth: number, axis: 'x' | 'y'): number {
  const d = depth * (value / 30) * faceWidth * PARALLAX_RATIO;
  return axis === 'x' ? d : -d;    // y は上が負
}
```

- STANDARD_DRAW_ORDER（背面 → 前面）: backHair, torso, armL, armR, neck, earL, earR, face, cheek, mouthInside, teeth, tongue, upperLip, lowerLip, mouthWhole, eyeWhiteL, eyeWhiteR, eyeWholeL, eyeWholeR, irisL, irisR, highlightL, highlightR, lowerLidL, lowerLidR, upperLidL, upperLidR, browL, browR, sideHairL, sideHairR, frontHair
- DEFAULT_DEPTH: frontHair 1.0 / browL・browR 0.6 / 目のパーツ（eyeWhite・iris・highlight・upperLid・lowerLid・eyeWhole の L・R）0.5 / 口のパーツ（upperLip・lowerLip・mouthInside・teeth・tongue・mouthWhole）0.5 / sideHairL・sideHairR 0.4 / cheek 0.4 / face 0.2 / earL・earR −0.5 / backHair −1.0

### ストアの契約（@app/contracts）

```ts
export interface Command { label: string; apply(project: Project): Project }   // 純粋関数
export interface ProjectStore {
  get(): Project;
  subscribe(listener: (project: Project) => void): () => void;
  dispatch(command: Command): void;                                          // 1回の Undo 単位
  transaction(label: string, run: (dispatch: (c: Command) => void) => void): void;   // まとめて1回の Undo
  undo(): void; redo(): void; canUndo(): boolean; canRedo(): boolean;
  load(project: Project): void;                                              // 履歴を消して置き換える
}
export interface EditorState {
  mode: ModeId;
  uiLevel: Record<ModeId, UiLevel>;
  selectedPartIds: string[];
  activeParameterIds: string[];        // 編集中のパラメータ（0〜2個）
  editorParamValues: ParamValues;      // モデリング中のプレビュー値（無いパラメータはデフォルト値）
}
export interface EditorStore { get(): EditorState; set(patch: Partial<EditorState>): void; subscribe(l: (s: EditorState) => void): () => void }
```

## 作るもの

- セットアップ画面（registerSetupScreen）: PSD・PNG を複数ドラッグ&ドロップ → importer.importFiles → コマンド addAssets（project.assets に足し、assets.put で PNG を登録）。警告は種類ごとに一覧で出す（下の文）。
- 素材トレイ（left のパネル）: サムネイル、PSD のグループ（layerPath）ごとの折りたたみ、非表示の印、ドラッグ元。[素材を追加]。
- 割り当て（right のパネル。セットアップ画面では右側）: 標準パーツの枠を下の表のとおり部位ごとに並べる。★は推奨。
- ドロップでコマンド assign(standardType, assetIds): 画像パーツを作る（name = STANDARD_PART_NAMES、standardType、assetId、meshId = meshGenerator.generate(素材の ImageData, offset, 'standard') で作ったメッシュ、pivot = 素材の中心、depth 0、visible true、blendMode 'normal'）。drawOrder の最前面に足す。
- 1つの枠に複数の素材を入れたら、その枠をグループ（standardType を持つ）にし、各素材を子の画像パーツ（standardType null、name = レイヤー名）にする。
- 割り当ての解除・付け替えのコマンド。どれも Undo できる。
- [かんたんセットアップ]: services.autoSetup.plan(project) の command を transaction で実行し、warnings を通知で出す。

| 部位 | 枠（standardType） |
| --- | --- |
| 顔 | 顔 face、耳 L earL、耳 R earR、頬染め cheek |
| 左目 | 白目★ eyeWhiteL、瞳★ irisL、ハイライト highlightL、上まぶた★ upperLidL、下まぶた lowerLidL、目（まとめて）eyeWholeL |
| 右目 | 左目と同じ（R） |
| 眉 | 眉 L browL、眉 R browR |
| 口 | 上唇★ upperLip、下唇★ lowerLip、口の中★ mouthInside、歯 teeth、舌 tongue、口（まとめて）mouthWhole |
| 髪 | 前髪 frontHair、横髪 L sideHairL、横髪 R sideHairR、後ろ髪 backHair |
| 体 | 首 neck、胴体 torso、腕 L armL、腕 R armR |
| その他 | 自由パーツ（名前を入れる。standardType null） |

警告の文: canvasMismatch「キャンバスサイズが違う素材があります。位置は手動で合わせてください」、noTransparency「背景が透過していない素材があります」、resolution「解像度が小さすぎる（または大きすぎる）素材があります」、needsMerge「統合が必要なレイヤーがあります。ペイントソフトで統合してから取り込み直してください」＋レイヤー名の一覧。

## 作らないもの

PSD の再読み込み（STEP1）。

## 完了条件

- [ ] 仮実装で、ドロップ → 素材トレイに並ぶ、警告が出る
- [ ] 割り当てでパーツとメッシュができる、複数の素材でグループになる
- [ ] どの操作も Undo できる
- [ ] [かんたんセットアップ] で plan が呼ばれ、警告が出る
