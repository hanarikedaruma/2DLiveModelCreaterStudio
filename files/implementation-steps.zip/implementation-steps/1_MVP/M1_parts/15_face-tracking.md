# 15. カメラと顔の推定

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | MVP / M1 部品 |
| 並行作業 | 同じ段階の 06〜22 と並行して作れる（触るフォルダは重ならない） |
| 担当の目安 | トラッキング |
| 作業場所 | packages/tracking/src/source/ |

## 目的

Webカメラの映像から、顔の向き・目・口の状態を PC の中で推定する。

## 前提（このカードの時点ですでにあるもの）

`@app/contracts` に下のインターフェースがある。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### 座標と値の約束

- 座標はキャンバス（元のPSD・PNG）のピクセル。原点は左上、x は右、y は下が正。
- 回転は度。画面上の時計回りが正。
- L / R はキャラクター自身から見た左右。画面では L が右側に描かれる。
- FaceAngleX はキャラクターが画面の右を向くと正、FaceAngleY は上を向くと正、FaceAngleZ は時計回りが正。EyeBallX は画面の右を見ると正、EyeBallY は上を見ると正。
- 基準状態 = 素材を配置しただけの状態 = 全パラメータがデフォルト値の状態。素材は「目を開け、口を閉じた」状態で描かれている前提。
- キーは基準状態からの差分。位置・回転・頂点は加算、拡縮・不透明度は倍率（1 = 変化なし）。

### トラッキングの契約（@app/contracts）

```ts
export interface TrackingFrame {
  time: number;                    // ミリ秒（performance.now）
  detected: boolean;
  faceYaw: number;                 // 度。ユーザーが自分の右を向くと正
  facePitch: number;               // 度。上を向くと正
  faceRoll: number;                // 度。ユーザーが自分の右へ傾けると正
  eyeOpenL: number; eyeOpenR: number;   // 0..1。ユーザー自身の左目・右目
  eyeBallX: number;                // -1..1。ユーザーが自分の右を見ると正
  eyeBallY: number;                // -1..1。上を見ると正
  mouthOpen: number;               // 0..1
}
export interface TrackingSource {
  listDevices(): Promise<{ id: string; label: string }[]>;
  start(deviceId?: string): Promise<void>;
  stop(): void;
  onFrame(listener: (frame: TrackingFrame) => void): () => void;
}
export interface TrackingLayerProducer {
  update(frame: TrackingFrame): void;
  tick(now: number): Layer;        // id 'tracking'
  status(): 'tracking' | 'lost';
  setMirror(on: boolean): void;
  setLostBehavior(b: 'returnToFront' | 'hold'): void;
}
```

## 作るもの

- `createMediaPipeTrackingSource(): TrackingSource`。
- カメラ: getUserMedia（deviceId を指定、1280×720・30fps を優先）。listDevices は videoinput の一覧。
- 推定: MediaPipe Tasks Vision の FaceLandmarker（runningMode 'VIDEO'、outputFaceBlendshapes と outputFacialTransformationMatrixes を有効、GPU を優先して失敗したら CPU）。モデルのファイルはアプリに同梱し、実行時にネットワークを使わない。
- requestVideoFrameCallback ごとに推定し、TrackingFrame を出す。
  - faceYaw・facePitch・faceRoll: 変換行列から求める（度。符号は TrackingFrame の約束どおり）。
  - eyeOpenL・R: 1 − eyeBlink。被写体自身の左右に合わせる（MediaPipe の Left / Right の向きを実機で確かめ、テストに残す）。
  - eyeBallX・Y: eyeLookIn / Out / Up / Down から −1..1。
  - mouthOpen: jawOpen。
  - 顔が無いフレームは detected false（ほかの値は前回のまま）。
- 変換は純粋関数（matrixToAngles・blendshapesToFrame）に分けてテストする。
- 推定が追いつかないフレームは捨て、30fps 以上を保つ。カメラの映像は外部に送らない。

## 作らないもの

パラメータへの写像、スムージング（別のカード）。

## 完了条件

- [ ] カメラの一覧・開始・停止ができる
- [ ] 基準PCで 30fps 以上
- [ ] 変換関数のテスト（向きと左右の符号）
- [ ] カメラを手で覆うと detected が false になる
