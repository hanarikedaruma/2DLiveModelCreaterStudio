# 13. PNG・PSDの取り込み

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | MVP / M1 部品 |
| 並行作業 | 同じ段階の 06〜22 と並行して作れる（触るフォルダは重ならない） |
| 担当の目安 | 入出力 |
| 作業場所 | packages/io/src/import/ |

## 目的

PNG と PSD から、位置を保ったトリミング済みの素材を作り、問題があれば警告する。

## 前提（このカードの時点ですでにあるもの）

`@app/schema` と `@app/contracts` に下の型とインターフェースがある。ID は `newId()`（@app/schema）で作る。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### 座標と値の約束

- 座標はキャンバス（元のPSD・PNG）のピクセル。原点は左上、x は右、y は下が正。
- 回転は度。画面上の時計回りが正。
- L / R はキャラクター自身から見た左右。画面では L が右側に描かれる。
- FaceAngleX はキャラクターが画面の右を向くと正、FaceAngleY は上を向くと正、FaceAngleZ は時計回りが正。EyeBallX は画面の右を見ると正、EyeBallY は上を見ると正。
- 基準状態 = 素材を配置しただけの状態 = 全パラメータがデフォルト値の状態。素材は「目を開け、口を閉じた」状態で描かれている前提。
- キーは基準状態からの差分。位置・回転・頂点は加算、拡縮・不透明度は倍率（1 = 変化なし）。

### 基本の型（@app/schema）

```ts
export type Id = string;
export interface Vec2 { x: number; y: number }
export type BlendMode = 'normal' | 'multiply' | 'screen' | 'add';
export type ParameterGroupId = 'face' | 'eye' | 'brow' | 'mouth' | 'cheek' | 'body' | 'armL' | 'armR' | 'sway' | 'other';
export type ModeId = 'modeling' | 'animation' | 'studio';
export type UiLevel = 'easy' | 'detail';
export function newId(): string;   // ULID
```

### Asset（@app/schema）

```ts
export interface Asset {
  id: Id;
  path: string;                    // 例: assets/<id>.png
  hash: string;                    // png の SHA-256（16進）
  width: number; height: number;   // トリミング後のサイズ
  offset: Vec2;                    // トリミング後の左上のキャンバス座標
  canvasSize: { width: number; height: number };
  source: { kind: 'psd' | 'png'; file: string; layerName?: string; layerPath?: string[]; hidden?: boolean };
  sourceBlendMode: BlendMode;
  sourceOpacity: number;           // 0..1
}
```

### 取り込み・保存の契約（@app/contracts）

```ts
export interface FileSystem {          // パスは / 区切りの絶対パス
  readText(path: string): Promise<string>; writeText(path: string, data: string): Promise<void>;
  readBinary(path: string): Promise<Uint8Array>; writeBinary(path: string, data: Uint8Array): Promise<void>;
  exists(path: string): Promise<boolean>; mkdir(path: string): Promise<void>;
  list(dir: string): Promise<string[]>; remove(path: string): Promise<void>; rename(from: string, to: string): Promise<void>;
}
export interface ImportedAsset { asset: Asset; png: Uint8Array }   // png はトリミング済み
export interface ImportWarning { kind: 'canvasMismatch' | 'noTransparency' | 'resolution' | 'needsMerge'; assetIds: string[]; layerNames: string[]; message: string }
export interface Importer { importFiles(files: { name: string; data: Uint8Array }[]): Promise<{ assets: ImportedAsset[]; warnings: ImportWarning[] }> }
export interface ProjectIO {
  save(dir: string, project: Project, assetPngs: Record<string, Uint8Array>): Promise<void>;
  load(dir: string): Promise<{ project: Project; assetPngs: Record<string, Uint8Array> }>;
}
export interface AutoSaver { start(dir: string): void; stop(): void; findRecoverable(dir: string): Promise<string | null> }
```

## 作るもの

- `createImporter(): Importer`。ブラウザ（WebView2）で動くこと。ファイルの中身は Uint8Array で受け取る。
- PNG: 復号し（例: UPNG.js）、透明な余白をトリミングする。offset = 残った矩形の左上、canvasSize = 元の画像サイズ。最初のファイルとサイズが違う PNG には canvasMismatch を出し、その offset は (0,0) にする。
- PSD（ag-psd）: グループの中も含めたラスタレイヤーを1枚ずつ素材にする。offset = レイヤーの左上 + トリミング分、layerName、layerPath（グループ名の配列）、sourceOpacity、hidden（非表示でも取り込む）。
- 合成モードの対応: normal → 'normal'、multiply → 'multiply'、screen → 'screen'、linear dodge → 'add'、ほかは 'normal'。
- 統合が必要なレイヤー（クリッピング、normal 以外の合成モード、調整レイヤー、レイヤー効果、スマートオブジェクト）は needsMerge の警告に集める。取り込みは止めず、通常のラスタとして読む。
- そのほかの警告: noTransparency（四隅のピクセルが不透明で、全体の 99% 以上が不透明）、resolution（キャンバスの長辺が 1000px 未満か 8000px 超）。
- 出力: トリミング後の PNG（png）、hash = png の SHA-256（16進）、path = `assets/<id>.png`。

## 作らないもの

合成モードの引き継ぎとクリッピングの自動統合（STEP1）、PSD の再読み込み（STEP1）。

## 完了条件

- [ ] テストの中で ag-psd で作った PSD で: 位置、トリミング、非表示、layerPath、合成モードの対応、needsMerge
- [ ] PNG: サイズ違いの canvasMismatch、noTransparency、resolution
- [ ] hash と path が正しい
