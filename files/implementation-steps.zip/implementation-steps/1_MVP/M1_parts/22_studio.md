# 22. スタジオ画面と出力ウィンドウ

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | MVP / M1 部品 |
| 並行作業 | 同じ段階の 06〜22 と並行して作れる（触るフォルダは重ならない） |
| 担当の目安 | 画面 |
| 作業場所 | apps/desktop/src/modes/studio/、apps/desktop/src/output/ |

## 目的

トラッキングでモデルを動かすスタジオ画面と、配信ソフトに取り込む出力ウィンドウを作る。

## 前提（このカードの時点ですでにあるもの）

アプリの枠の差し込み口と、services（仮実装）がある。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### アプリの枠の差し込み口（apps/desktop/src/shell/api.ts）

```ts
export interface PanelDef { id: string; mode: ModeId; area: 'left' | 'right' | 'bottom'; title: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanel(def: PanelDef): void;
export interface SectionDef { id: string; panelId: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanelSection(def: SectionDef): void;      // パネルの中の <PanelSections panelId=… /> に入る
export function PanelSections(props: { panelId: string }): JSX.Element;
export function registerCenter(mode: 'studio' | 'animation', component: React.FC): void;
export function registerSetupScreen(component: React.FC): void;   // 素材が1つも無いとき中央に出す
export function registerMenuItem(item: { id: string; label: string; shortcut?: string; run(): void }): void;

export interface CanvasPointerEvent { canvasPoint: Vec2; screenPoint: Vec2; button: number; shiftKey: boolean; altKey: boolean; ctrlKey: boolean }
export interface CanvasTool {
  id: string; label: string; cursor?: string;
  onPointerDown?(e: CanvasPointerEvent): void; onPointerMove?(e: CanvasPointerEvent): void; onPointerUp?(e: CanvasPointerEvent): void;
  onKeyDown?(e: KeyboardEvent): void;
  drawOverlay?(ctx: CanvasRenderingContext2D, view: ViewTransform): void;
}
export function registerCanvasTool(tool: CanvasTool): void;        // 最初に登録したものが既定のツール
export function registerCanvasOverlay(id: string, draw: (ctx: CanvasRenderingContext2D, view: ViewTransform) => void): void;
export function useCanvas(): { view: ViewTransform; activeToolId: string; setActiveTool(id: string): void; requestRedraw(): void; lastDeformed(): DeformedModel | null; screenToCanvas(p: Vec2): Vec2 };

export function useServices(): Services;
export function useProject(): Project;
export function useDispatch(): (c: Command) => void;
export function useEditor(): [EditorState, (patch: Partial<EditorState>) => void];
export function useEnvironment(): [Environment, (patch: Partial<Environment>) => void];
export function useDialogs(): { confirm(message: string): Promise<boolean>; notify(message: string): void; prompt(message: string, initial?: string): Promise<string | null> };
export function emitAppEvent(name: string, payload?: unknown): void;
export function onAppEvent(name: string, listener: (payload: unknown) => void): () => void;
```

### サービスのまとめ（@app/contracts）

```ts
export interface Services {
  store: ProjectStore; editor: EditorStore; assets: AssetRepository; fs: FileSystem;
  evaluator: BindingEvaluator; pipeline: DeformPipeline; mixer: ParameterMixer; createRenderer(): Renderer;
  meshGenerator: MeshGenerator; keyGenerator: KeyGenerator; autoSetup: AutoSetup; keyEditor: KeyEditor;
  importer: Importer; io: ProjectIO; autoSaver: AutoSaver;
  tracking: TrackingSource; trackingLayer: TrackingLayerProducer;
}
```

### 合成の契約（@app/contracts）

```ts
export type LayerId = 'tracking' | 'bodyFollow' | 'expression' | 'animation' | 'lipSync' | 'periodic' | 'physics';
export const LAYER_ORDER: LayerId[] = ['tracking', 'bodyFollow', 'expression', 'animation', 'lipSync', 'periodic', 'physics'];
export interface Layer {
  id: LayerId;
  weight: number;                     // 0..1
  values: ParamValues;                // このレイヤーが担当するパラメータの値だけ
  blend?: Record<string, BlendOp>;    // パラメータごとの合成方法。無ければ override
}
export interface ParameterMixer { mix(parameters: Parameter[], layers: Layer[]): ParamValues }

// スタジオの1フレームの文脈。producer は LAYER_ORDER の順に呼ばれる
export interface FrameContext {
  now: number; dt: number;            // ミリ秒
  project: Project;
  mixedSoFar: ParamValues;            // それまでのレイヤーを合成した値
  flags: { lipSyncWeight: number; physicsActive: boolean };   // 前のレイヤーが後のレイヤーへ伝える値（初期値 1・true）
}
export interface LayerProducer { id: LayerId; produce(ctx: FrameContext): Layer | null }
```

### 描画の契約（@app/contracts）

```ts
export type Background = { type: 'transparent' } | { type: 'color'; color: string } | { type: 'image'; image: ImageBitmap };
export interface ViewTransform { scale: number; offset: Vec2 }   // 画面座標（CSSピクセル）= キャンバス座標 × scale + offset
export interface Renderer {
  init(canvas: HTMLCanvasElement): void;
  setTextures(images: Record<string, ImageBitmap>): void;       // assetId → 画像
  render(model: DeformedModel, view: ViewTransform, background: Background): void;
  dispose(): void;
}
```

### トラッキングの契約（@app/contracts）

```ts
export interface TrackingFrame {
  time: number;                    // ミリ秒（performance.now）
  detected: boolean;
  faceYaw: number;                 // 度。ユーザーが自分の右を向くと正
  facePitch: number;               // 度。上を向くと正
  faceRoll: number;                // 度。ユーザーが自分の右へ傾けると正
  eyeOpenL: number; eyeOpenR: number;   // 0..1。ユーザー自身の左目・右目
  eyeBallX: number;                // -1..1。ユーザーが自分の右を見ると正
  eyeBallY: number;                // -1..1。上を見ると正
  mouthOpen: number;               // 0..1
}
export interface TrackingSource {
  listDevices(): Promise<{ id: string; label: string }[]>;
  start(deviceId?: string): Promise<void>;
  stop(): void;
  onFrame(listener: (frame: TrackingFrame) => void): () => void;
}
export interface TrackingLayerProducer {
  update(frame: TrackingFrame): void;
  tick(now: number): Layer;        // id 'tracking'
  status(): 'tracking' | 'lost';
  setMirror(on: boolean): void;
  setLostBehavior(b: 'returnToFront' | 'hold'): void;
}
```

### Scene と Hotkey（@app/schema）

```ts
export interface Scene {
  id: Id; name: string;
  background: { type: 'transparent' } | { type: 'color'; color: string } | { type: 'image'; path: string };   // path はプロジェクトからの相対パス
  modelTransform: { position: Vec2; scale: number };   // 出力画面での位置（px）と倍率
  expressionIds: Id[];             // シーンに切り替えたときに適用する表情
  periodicAnimationIds: Id[];      // STEP2で使う
}
export interface Hotkey {
  id: Id;
  keys: string;                    // 例: 'Ctrl+Shift+1'
  action: 'expression' | 'scene' | 'background' | 'animation' | 'parameter' | 'pauseTracking' | 'recalibrate';
  targetId: Id | null;
  mode: 'toggle' | 'hold';
}
```

### Environment（@app/schema。PCごとの設定でプロジェクトの外に保存）

```ts
export interface Environment {
  cameraDeviceId: string | null;
  mirror: boolean;
  calibration: { neutral: { yaw: number; pitch: number; roll: number }; eyeClosed: { l: number; r: number }; mouthOpenMax: number } | null;
  microphoneDeviceId: string | null;
  silenceThreshold: number;        // dBFS
  trackingPreset: 'stable' | 'standard' | 'large' | 'custom';
  output: { method: 'window' | 'spout2'; width: number; height: number; fps: number };
  uiLevel: Record<ModeId, UiLevel>;
  lastProjectDir: string | null;
}
```

## 作るもの

- 実行部（`runtime.ts`）: 下の差し込み口を作る。トラッキングは services.trackingLayer を包んだ producer（id 'tracking'）として最初から登録する。毎フレーム（requestAnimationFrame）、LAYER_ORDER の順に producer を呼んで mixedSoFar を更新し、mixer.mix → evaluator → pipeline → プレビューの renderer と、登録された sink へ渡す。
- シーン: project.studio.activeSceneId のシーン（無ければ scenes[0]、それも無ければ作る）の背景と modelTransform を使う。
- 中央（registerCenter('studio')）: ライブプレビュー。ドラッグでモデルの位置、ホイールで大きさを変え、シーンの modelTransform に保存する。
- right のパネル（中に `<PanelSections panelId="studioSettings" />`）に、次のセクションを登録する。
  - トラッキング: カメラの選択、ミラー（初期値オン）、[開始 / 停止]、状態（検出中 / 外れている）。カメラとミラーは Environment に保存する。
  - 背景: 透明・単色（緑・青・任意の色）・画像（選んだファイルをプロジェクトの `backgrounds/` に写す）。
  - 出力: 解像度（1920×1080、1280×720、任意）と [出力ウィンドウを開く]。
- 出力ウィンドウ（`/output` の画面。UIなし）: Tauri の別ウィンドウ。開くときにプロジェクトと素材の PNG をイベントで受け取り、以後は毎フレームの ParamValues をイベントで受け取って、同じ evaluator・pipeline・renderer で描く。背景とモデルの配置も同じにする。プロジェクトが変わったら送り直す（0.5秒ごとにまとめる）。

### スタジオの実行部の差し込み口（apps/desktop/src/modes/studio/runtime.ts）

```ts
export function registerLayerProducer(p: LayerProducer): () => void;   // LayerProducer・FrameContext は @app/contracts
export interface StudioFrame { model: DeformedModel; view: ViewTransform; background: Background; params: ParamValues; now: number }
export function registerFrameSink(sink: (frame: StudioFrame) => void): () => void;
export function useStudioRuntime(): { running: boolean; status: 'tracking' | 'lost' | 'stopped'; lastFrame(): StudioFrame | null };
```

1フレームの処理: LAYER_ORDER の順に producer を呼び、呼ぶたびに mixedSoFar を更新する → mixer.mix → evaluator → pipeline → プレビューの renderer と、登録された sink へ渡す。

## 作らないもの

複数のシーン、表情、リップシンク、透過出力（STEP1）。

## 完了条件

- [ ] 仮実装のトラッキングでプレビューが動く
- [ ] 背景の切り替えとモデルの配置が保存される
- [ ] 出力ウィンドウが選んだ解像度で開き、プレビューと同じ動きになる
- [ ] 外れている状態が表示される
- [ ] registerLayerProducer と registerFrameSink がテスト用の producer・sink で動く
