# 08. 中間キーの生成（線形・奥行き）

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | MVP / M1 部品 |
| 並行作業 | 同じ段階の 06〜22 と並行して作れる（触るフォルダは重ならない） |
| 担当の目安 | コア |
| 作業場所 | packages/core/src/generate/ |

## 目的

代表状態の間の中間キーと、奥行きによる顔の向きのキーを作る。

## 前提（このカードの時点ですでにあるもの）

`@app/schema` と `@app/contracts` に下の型・規則・インターフェースがある。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### 座標と値の約束

- 座標はキャンバス（元のPSD・PNG）のピクセル。原点は左上、x は右、y は下が正。
- 回転は度。画面上の時計回りが正。
- L / R はキャラクター自身から見た左右。画面では L が右側に描かれる。
- FaceAngleX はキャラクターが画面の右を向くと正、FaceAngleY は上を向くと正、FaceAngleZ は時計回りが正。EyeBallX は画面の右を見ると正、EyeBallY は上を見ると正。
- 基準状態 = 素材を配置しただけの状態 = 全パラメータがデフォルト値の状態。素材は「目を開け、口を閉じた」状態で描かれている前提。
- キーは基準状態からの差分。位置・回転・頂点は加算、拡縮・不透明度は倍率（1 = 変化なし）。

### Part と StandardPartType（@app/schema）

```ts
export interface Part {
  id: Id;
  name: string;
  kind: 'image' | 'group';
  standardType: StandardPartType | null;   // 自由パーツは null
  assetId: Id | null;                      // image のみ
  meshId: Id | null;                       // image のみ
  parentId: Id | null;
  position: Vec2;                          // 初期値 {x: 0, y: 0}
  rotation: number;                        // 度。初期値 0
  scale: Vec2;                             // 初期値 {x: 1, y: 1}
  pivot: Vec2;                             // 回転・拡縮の中心（キャンバス座標）
  opacity: number;                         // 0..1
  blendMode: BlendMode;
  depth: number;                           // 奥行き。手前が正（-1..1 が目安）
  mask: { sourcePartIds: Id[]; inverted: boolean } | null;
  physicsId: Id | null;
  visible: boolean;
  locked: boolean;
}
export type StandardPartType =
  | 'face' | 'earL' | 'earR' | 'cheek'
  | 'eyeWhiteL' | 'irisL' | 'highlightL' | 'upperLidL' | 'lowerLidL' | 'eyeWholeL'
  | 'eyeWhiteR' | 'irisR' | 'highlightR' | 'upperLidR' | 'lowerLidR' | 'eyeWholeR'
  | 'browL' | 'browR'
  | 'upperLip' | 'lowerLip' | 'mouthInside' | 'teeth' | 'tongue' | 'mouthWhole'
  | 'frontHair' | 'sideHairL' | 'sideHairR' | 'backHair'
  | 'neck' | 'torso' | 'armL' | 'armR'
  // 変形グループ（かんたんセットアップが作る）
  | 'bodyRoot' | 'armRootL' | 'armRootR' | 'neckRoot' | 'headRoot'
  | 'faceGroup' | 'eyeGroupL' | 'eyeGroupR' | 'mouthGroup';
```

### Asset（@app/schema）

```ts
export interface Asset {
  id: Id;
  path: string;                    // 例: assets/<id>.png
  hash: string;                    // png の SHA-256（16進）
  width: number; height: number;   // トリミング後のサイズ
  offset: Vec2;                    // トリミング後の左上のキャンバス座標
  canvasSize: { width: number; height: number };
  source: { kind: 'psd' | 'png'; file: string; layerName?: string; layerPath?: string[]; hidden?: boolean };
  sourceBlendMode: BlendMode;
  sourceOpacity: number;           // 0..1
}
```

### Parameter と ParameterGroup（@app/schema）

```ts
export interface ParameterGroup { id: ParameterGroupId; name: string }
export interface Parameter {
  id: Id;                          // 標準は 'FaceAngleX' など。ユーザー定義は任意の文字列
  name: string;                    // 表示名
  groupId: ParameterGroupId;
  min: number; max: number; default: number;
  standard: boolean;
}
```

### Binding と ParameterKey（@app/schema）

```ts
export type Channel = 'transform' | 'vertices' | 'warpPoints';
export interface TransformDelta { position: Vec2; rotation: number; scale: Vec2; opacity: number }
// position・rotation は加算、scale・opacity は倍率（1 = 変化なし）
export interface Binding {
  id: Id;
  target: { type: 'part' | 'mesh' | 'warp'; id: Id };   // transform → part、vertices → mesh、warpPoints → warp
  channel: Channel;
  parameterIds: Id[];              // 1 または 2
  keyValues: number[][];           // パラメータごとのキー位置（昇順。デフォルト値を必ず含む）
  keys: ParameterKey[];
  generation: 'linear' | 'depth' | 'rotate' | 'surface' | 'ease';
  divisions: number | null;        // 中間キーの分割数（自動なら null）
}
export interface ParameterKey {
  coords: number[];                // parameterIds と同じ順の値
  delta: TransformDelta | Vec2[];  // transform は TransformDelta、それ以外は頂点・制御点ごとの差分
  source: 'manual' | 'auto' | 'generated' | 'combined';
  locked: boolean;
}
```

### Model と Project（@app/schema）

```ts
export interface Model {
  parts: Part[];
  meshes: Mesh[];
  warps: Warp[];
  drawOrder: Id[];                 // 画像パーツの id。背面 → 前面
  parameters: Parameter[];
  parameterGroups: ParameterGroup[];
  bindings: Binding[];
  lipSync: LipSync;
  setupHints: { closedLineL: Vec2[] | null; closedLineR: Vec2[] | null };   // かんたんセットアップ用（閉じた目の線。STEP1で使う）
}
export interface Project {
  schemaVersion: number;           // 現在は 1
  id: Id;
  name: string;
  assets: Asset[];
  model: Model;
  expressions: Expression[];
  animations: Animation[];
  physics: Physics[];
  trackingMappings: TrackingMapping[];   // 空なら既定のマッピング
  studio: { scenes: Scene[]; activeSceneId: Id | null; hotkeys: Hotkey[] };
}
```

### 規則（@app/schema の rules.ts）

```ts
export const STANDARD_PARAMETERS: Parameter[];                      // 標準パラメータの表（standard: true）
export const PARAMETER_GROUPS: ParameterGroup[];                    // face 顔 / eye 目 / brow 眉 / mouth 口 / cheek 頬 / body 体 / armL 左腕 / armR 右腕 / sway 揺れもの / other その他
export const STANDARD_PART_NAMES: Record<StandardPartType, string>; // 日本語の表示名（例: eyeWhiteL → 白目 L）
export const STANDARD_DRAW_ORDER: StandardPartType[];               // 背面 → 前面（下記）
export const DEFAULT_DEPTH: Partial<Record<StandardPartType, number>>;   // 下記
export const PARALLAX_RATIO = 0.08;
// 奥行きによる移動量（px）。faceWidth は standardType 'face' の素材の幅
export function depthParallaxOffset(depth: number, value: number, faceWidth: number, axis: 'x' | 'y'): number {
  const d = depth * (value / 30) * faceWidth * PARALLAX_RATIO;
  return axis === 'x' ? d : -d;    // y は上が負
}
```

- STANDARD_DRAW_ORDER（背面 → 前面）: backHair, torso, armL, armR, neck, earL, earR, face, cheek, mouthInside, teeth, tongue, upperLip, lowerLip, mouthWhole, eyeWhiteL, eyeWhiteR, eyeWholeL, eyeWholeR, irisL, irisR, highlightL, highlightR, lowerLidL, lowerLidR, upperLidL, upperLidR, browL, browR, sideHairL, sideHairR, frontHair
- DEFAULT_DEPTH: frontHair 1.0 / browL・browR 0.6 / 目のパーツ（eyeWhite・iris・highlight・upperLid・lowerLid・eyeWhole の L・R）0.5 / 口のパーツ（upperLip・lowerLip・mouthInside・teeth・tongue・mouthWhole）0.5 / sideHairL・sideHairR 0.4 / cheek 0.4 / face 0.2 / earL・earR −0.5 / backHair −1.0

### 生成・セットアップの契約（@app/contracts）

```ts
export interface KeyGenerator {
  linear(binding: Binding, divisions?: number): Binding;
  depthParallax(model: Model, parameterId: 'FaceAngleX' | 'FaceAngleY'): Binding[];   // 作り直した transform バインディング
}
export interface AutoSetup { plan(project: Project): { command: Command; warnings: string[] } }
```

## 作るもの

- `createKeyGenerator(): KeyGenerator`。
- `linear(binding, divisions?)`: 1パラメータのバインディングだけが対象（2パラメータはそのまま返す）。代表状態（source が manual か auto、または locked のキー）の隣り合う2つの間に、中間キーを等間隔に作る。値は線形補間、source 'generated'、locked false。間隔は divisions があれば区間の分割数、無ければ「範囲が10を超えるパラメータは10刻み、それ以外は 0.25 刻み」。既存の generated で未ロックのキーは作り直し、keyValues を昇順に更新する。
- `depthParallax(model, parameterId)`: standardType 'headRoot' のグループの子孫にある画像パーツごとに、transform バインディングを1つ（無ければ作り、あれば未ロックのキーだけ作り直す）。キーは −30・0・30（source 'auto'、0 は差分 0）。Δposition は `depthParallaxOffset(part.depth, value, faceWidth, 'x' または 'y')`（FaceAngleX は x、FaceAngleY は y）。standardType 'face' のパーツは、FaceAngleX のとき `Δscale.x = 1 − 0.04 × |value| / 30` も入れる。faceWidth は 'face' の素材の幅（無ければ headRoot 配下の外接矩形の幅）。generation は 'depth'。

## 作らないもの

回転・曲面・なめらかの生成方式（STEP1）。

## 完了条件

- [ ] linear: 中間キーの数と値、ロックされたキーを残す、作り直しで未ロックの generated だけが変わる
- [ ] depthParallax: 手前のパーツは右へ・奥のパーツは左へ（FaceAngleX 正）、上を向くと手前のパーツが上へ（FaceAngleY 正）
- [ ] 顔の輪郭の横の縮み
- [ ] 2回実行しても結果が同じ
