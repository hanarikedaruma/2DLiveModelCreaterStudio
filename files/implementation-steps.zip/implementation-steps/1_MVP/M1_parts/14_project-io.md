# 14. 保存・読み込み・自動保存

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | MVP / M1 部品 |
| 並行作業 | 同じ段階の 06〜22 と並行して作れる（触るフォルダは重ならない） |
| 担当の目安 | 入出力 |
| 作業場所 | packages/io/src/project/ |

## 目的

プロジェクトをフォルダに保存・読み込みし、自動保存と異常終了からの復元を用意する。

## 前提（このカードの時点ですでにあるもの）

`@app/schema` と `@app/contracts` に下の型・関数・インターフェースがある。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### Model と Project（@app/schema）

```ts
export interface Model {
  parts: Part[];
  meshes: Mesh[];
  warps: Warp[];
  drawOrder: Id[];                 // 画像パーツの id。背面 → 前面
  parameters: Parameter[];
  parameterGroups: ParameterGroup[];
  bindings: Binding[];
  lipSync: LipSync;
  setupHints: { closedLineL: Vec2[] | null; closedLineR: Vec2[] | null };   // かんたんセットアップ用（閉じた目の線。STEP1で使う）
}
export interface Project {
  schemaVersion: number;           // 現在は 1
  id: Id;
  name: string;
  assets: Asset[];
  model: Model;
  expressions: Expression[];
  animations: Animation[];
  physics: Physics[];
  trackingMappings: TrackingMapping[];   // 空なら既定のマッピング
  studio: { scenes: Scene[]; activeSceneId: Id | null; hotkeys: Hotkey[] };
}
```

### スキーマの関数（@app/schema）

```ts
export const SCHEMA_VERSION = 1;
export function validateProject(json: unknown): Project;       // 失敗時は項目のパス付きのエラー
export function migrate(json: unknown): unknown;               // 古い版を現在の版へ変換
export function loadProjectJson(text: string): Project;        // 解析 → migrate → validate
export function createEmptyProject(name: string): Project;     // MVPの標準パラメータ入り
export function ensureStandardParameters(model: Model, phase: 'mvp' | 'step1' | 'step2'): Model;
```

### 取り込み・保存の契約（@app/contracts）

```ts
export interface FileSystem {          // パスは / 区切りの絶対パス
  readText(path: string): Promise<string>; writeText(path: string, data: string): Promise<void>;
  readBinary(path: string): Promise<Uint8Array>; writeBinary(path: string, data: Uint8Array): Promise<void>;
  exists(path: string): Promise<boolean>; mkdir(path: string): Promise<void>;
  list(dir: string): Promise<string[]>; remove(path: string): Promise<void>; rename(from: string, to: string): Promise<void>;
}
export interface ImportedAsset { asset: Asset; png: Uint8Array }   // png はトリミング済み
export interface ImportWarning { kind: 'canvasMismatch' | 'noTransparency' | 'resolution' | 'needsMerge'; assetIds: string[]; layerNames: string[]; message: string }
export interface Importer { importFiles(files: { name: string; data: Uint8Array }[]): Promise<{ assets: ImportedAsset[]; warnings: ImportWarning[] }> }
export interface ProjectIO {
  save(dir: string, project: Project, assetPngs: Record<string, Uint8Array>): Promise<void>;
  load(dir: string): Promise<{ project: Project; assetPngs: Record<string, Uint8Array> }>;
}
export interface AutoSaver { start(dir: string): void; stop(): void; findRecoverable(dir: string): Promise<string | null> }
```

### ストアの契約（@app/contracts）

```ts
export interface Command { label: string; apply(project: Project): Project }   // 純粋関数
export interface ProjectStore {
  get(): Project;
  subscribe(listener: (project: Project) => void): () => void;
  dispatch(command: Command): void;                                          // 1回の Undo 単位
  transaction(label: string, run: (dispatch: (c: Command) => void) => void): void;   // まとめて1回の Undo
  undo(): void; redo(): void; canUndo(): boolean; canRedo(): boolean;
  load(project: Project): void;                                              // 履歴を消して置き換える
}
export interface EditorState {
  mode: ModeId;
  uiLevel: Record<ModeId, UiLevel>;
  selectedPartIds: string[];
  activeParameterIds: string[];        // 編集中のパラメータ（0〜2個）
  editorParamValues: ParamValues;      // モデリング中のプレビュー値（無いパラメータはデフォルト値）
}
export interface EditorStore { get(): EditorState; set(patch: Partial<EditorState>): void; subscribe(l: (s: EditorState) => void): () => void }
```

## 作るもの

- `createProjectIO(fs: FileSystem): ProjectIO`。フォルダの構成は `project.json`・`assets/`・`backups/`。
- save: project.json を整形して書く（schemaVersion を先頭に）。`assets/<id>.png` は hash が変わったものだけ書く。書き込みは `.tmp` に書いてから rename する。
- load: project.json を読み、版が古ければ変換前のファイルを `backups/project.v<版>.<日時>.json` に写してから変換し、検証する。参照している素材のファイルが無ければ、その id を並べたエラーにする。
- `createAutoSaver(fs, io, store, getAssetPngs: () => Record<string, Uint8Array>): AutoSaver`。start(dir) でストアを購読し、最後の変更から5秒後に `backups/autosave-<日時>.json` を書く（素材は assets/ に無いものだけ書く）。古いものから消して10世代を保つ。stop() で止める。
- findRecoverable(dir): project.json より新しい自動保存があれば、そのパスを返す。
- 保存先がまだ無い新規のプロジェクトは、呼び出し側がアプリのデータフォルダの `unsaved/<project.id>/` を dir として渡す。

## 作らないもの

保存・読み込みのメニューやダイアログ（結合のカード）。

## 完了条件

- [ ] MemoryFileSystem で、保存 → 読み込みが同じ内容になる
- [ ] 書き込みが .tmp → rename になっている
- [ ] 古い版の読み込みで変換前のファイルが backups/ に残る
- [ ] 素材のファイルが無いときのエラー
- [ ] 自動保存が10世代を超えない、findRecoverable が正しく判定する
