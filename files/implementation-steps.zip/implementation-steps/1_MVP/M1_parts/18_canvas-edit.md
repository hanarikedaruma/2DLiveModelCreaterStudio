# 18. キャンバス編集（選択・変形・ピボット）

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | MVP / M1 部品 |
| 並行作業 | 同じ段階の 06〜22 と並行して作れる（触るフォルダは重ならない） |
| 担当の目安 | 画面 |
| 作業場所 | apps/desktop/src/modes/modeling/canvas/ |

## 目的

キャンバス上でパーツを選び、移動・回転・拡縮・ピボットの調整をできるようにする。

## 前提（このカードの時点ですでにあるもの）

アプリの枠の差し込み口（キャンバスのツール）と、services（仮実装）がある。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### パーツの変形と計算の順序

- パーツの変形は、点 p を `p' = position + pivot + R(rotation)·(scale ⊙ (p − pivot))` に動かす。R は y が下向きの座標で `[cos −sin; sin cos]`（正の角度で時計回り）。
- 実際に使う値: `position = Part.position + Δposition`、`rotation = Part.rotation + Δrotation`、`scale = Part.scale ⊙ Δscale`、`opacity = Part.opacity × Δopacity`（Δ はキーの合成結果）。
- 取り込み直後は position (0,0)・rotation 0・scale (1,1)。メッシュの頂点と pivot はキャンバス座標。
- 画像パーツの最終頂点は内側から外側へ求める。(1) メッシュの基準頂点 + 頂点の差分 → (2) 自身のパーツの変形 → (3) 親グループのワープ（あれば）→ (4) 親グループのパーツの変形 → ルートまで (3)(4) を繰り返す。
- 不透明度は、自身から親までの値をすべて掛け合わせる。

### アプリの枠の差し込み口（apps/desktop/src/shell/api.ts）

```ts
export interface PanelDef { id: string; mode: ModeId; area: 'left' | 'right' | 'bottom'; title: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanel(def: PanelDef): void;
export interface SectionDef { id: string; panelId: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanelSection(def: SectionDef): void;      // パネルの中の <PanelSections panelId=… /> に入る
export function PanelSections(props: { panelId: string }): JSX.Element;
export function registerCenter(mode: 'studio' | 'animation', component: React.FC): void;
export function registerSetupScreen(component: React.FC): void;   // 素材が1つも無いとき中央に出す
export function registerMenuItem(item: { id: string; label: string; shortcut?: string; run(): void }): void;

export interface CanvasPointerEvent { canvasPoint: Vec2; screenPoint: Vec2; button: number; shiftKey: boolean; altKey: boolean; ctrlKey: boolean }
export interface CanvasTool {
  id: string; label: string; cursor?: string;
  onPointerDown?(e: CanvasPointerEvent): void; onPointerMove?(e: CanvasPointerEvent): void; onPointerUp?(e: CanvasPointerEvent): void;
  onKeyDown?(e: KeyboardEvent): void;
  drawOverlay?(ctx: CanvasRenderingContext2D, view: ViewTransform): void;
}
export function registerCanvasTool(tool: CanvasTool): void;        // 最初に登録したものが既定のツール
export function registerCanvasOverlay(id: string, draw: (ctx: CanvasRenderingContext2D, view: ViewTransform) => void): void;
export function useCanvas(): { view: ViewTransform; activeToolId: string; setActiveTool(id: string): void; requestRedraw(): void; lastDeformed(): DeformedModel | null; screenToCanvas(p: Vec2): Vec2 };

export function useServices(): Services;
export function useProject(): Project;
export function useDispatch(): (c: Command) => void;
export function useEditor(): [EditorState, (patch: Partial<EditorState>) => void];
export function useEnvironment(): [Environment, (patch: Partial<Environment>) => void];
export function useDialogs(): { confirm(message: string): Promise<boolean>; notify(message: string): void; prompt(message: string, initial?: string): Promise<string | null> };
export function emitAppEvent(name: string, payload?: unknown): void;
export function onAppEvent(name: string, listener: (payload: unknown) => void): () => void;
```

### サービスのまとめ（@app/contracts）

```ts
export interface Services {
  store: ProjectStore; editor: EditorStore; assets: AssetRepository; fs: FileSystem;
  evaluator: BindingEvaluator; pipeline: DeformPipeline; mixer: ParameterMixer; createRenderer(): Renderer;
  meshGenerator: MeshGenerator; keyGenerator: KeyGenerator; autoSetup: AutoSetup; keyEditor: KeyEditor;
  importer: Importer; io: ProjectIO; autoSaver: AutoSaver;
  tracking: TrackingSource; trackingLayer: TrackingLayerProducer;
}
```

### キー編集の契約（@app/contracts）

```ts
export type TransformChange = { dPosition?: Vec2; dRotation?: number; scaleFactor?: Vec2; opacityFactor?: number; dPivot?: Vec2 };
export type PointsTarget = { kind: 'mesh'; meshId: string } | { kind: 'warp'; warpId: string };
export interface KeyEditor {
  // EditorState の activeParameterIds と editorParamValues に応じて、基準状態かキーを変えるコマンドを返す
  transformEdit(project: Project, editor: EditorState, partIds: string[], change: TransformChange): Command | 'needsKey';
  pointsEdit(project: Project, editor: EditorState, target: PointsTarget, moves: { index: number; d: Vec2 }[]): Command | 'needsKey';
  addKeyAtCurrentValue(project: Project, editor: EditorState, target: { partId: string } | PointsTarget): Command;
}
```

### 変形の契約（@app/contracts）

```ts
export interface DrawItem {
  partId: string; assetId: string;
  positions: Float32Array;         // 変形後の頂点（キャンバス座標）[x0, y0, x1, y1, ...]
  uvs: Float32Array;               // [u0, v0, ...]（0..1）
  indices: Uint32Array;
  opacity: number;                 // 親まで掛けた最終値
  blendMode: BlendMode;
  mask: { sourcePartIds: string[]; inverted: boolean } | null;
}
export interface DeformedModel {
  items: DrawItem[];               // 描画順（背面 → 前面）。非表示のパーツは含めない
  byPartId: Record<string, DrawItem>;
}
export interface DeformPipeline { deform(model: Model, deltas: TargetDeltas): DeformedModel }
```

### ストアの契約（@app/contracts）

```ts
export interface Command { label: string; apply(project: Project): Project }   // 純粋関数
export interface ProjectStore {
  get(): Project;
  subscribe(listener: (project: Project) => void): () => void;
  dispatch(command: Command): void;                                          // 1回の Undo 単位
  transaction(label: string, run: (dispatch: (c: Command) => void) => void): void;   // まとめて1回の Undo
  undo(): void; redo(): void; canUndo(): boolean; canRedo(): boolean;
  load(project: Project): void;                                              // 履歴を消して置き換える
}
export interface EditorState {
  mode: ModeId;
  uiLevel: Record<ModeId, UiLevel>;
  selectedPartIds: string[];
  activeParameterIds: string[];        // 編集中のパラメータ（0〜2個）
  editorParamValues: ParamValues;      // モデリング中のプレビュー値（無いパラメータはデフォルト値）
}
export interface EditorStore { get(): EditorState; set(patch: Partial<EditorState>): void; subscribe(l: (s: EditorState) => void): () => void }
```

## 作るもの

- 選択・変形ツール（registerCanvasTool。既定のツールにする）:
  - クリックで、手前から見て最初に当たる DrawItem を選ぶ（三角形の内側の判定）。Shift で追加、何も無い所で解除。locked のパーツは選ばない。
  - 選択中は、外接矩形・回転ハンドル（上）・拡縮ハンドル（四隅と辺）・ピボット ◎ をオーバーレイに描く。
  - ドラッグで移動・回転（ピボット中心）・拡縮（Shift で縦横比を固定）・ピボット移動。services.keyEditor.transformEdit でコマンドを得て、1回のドラッグを1つの transaction にする。
  - 'needsKey' が返ったら「この値にキーを追加して編集」を確認し、承認されたら addKeyAtCurrentValue を実行してから、もう一度 transformEdit する。
  - ピボットの移動は、編集中のパラメータが無いときだけ。
- Transform パネル（right）: X・Y・Rotation・Scale X / Y・Pivot X / Y・Opacity を数値で表示・編集する（基準状態の値）。奥行きは「前後の位置（手前〜奥）」のスライダー（−1..1）。編集中のパラメータがあるときは読み取り専用にし、「パラメータ編集中は画面上で操作」と出す。パネルの下に `<PanelSections panelId="transform" />` を置く。

## 作らないもの

メッシュの頂点の編集、パラメータのパネル（別のカード）。

## 完了条件

- [ ] 仮実装で fixtures のモデルを選び、移動・回転・拡縮・ピボット移動ができる
- [ ] 1回のドラッグが1回の Undo になる
- [ ] Transform パネルの数値の編集が反映される
- [ ] needsKey の確認からキーを足して編集する流れ
