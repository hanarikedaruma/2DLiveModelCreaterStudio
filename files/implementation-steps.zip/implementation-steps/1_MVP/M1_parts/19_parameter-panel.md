# 19. パラメータパネルとキー編集

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | MVP / M1 部品 |
| 並行作業 | 同じ段階の 06〜22 と並行して作れる（触るフォルダは重ならない） |
| 担当の目安 | 画面 |
| 作業場所 | apps/desktop/src/modes/modeling/parameters/、apps/desktop/src/services/keyEditor/ |

## 目的

パラメータを選んで状態を作り、間を生成できるようにする。編集をどのキーに記録するかを決める KeyEditor の本物を作る。

## 前提（このカードの時点ですでにあるもの）

アプリの枠の差し込み口と、services（仮実装）がある。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### 座標と値の約束

- 座標はキャンバス（元のPSD・PNG）のピクセル。原点は左上、x は右、y は下が正。
- 回転は度。画面上の時計回りが正。
- L / R はキャラクター自身から見た左右。画面では L が右側に描かれる。
- FaceAngleX はキャラクターが画面の右を向くと正、FaceAngleY は上を向くと正、FaceAngleZ は時計回りが正。EyeBallX は画面の右を見ると正、EyeBallY は上を見ると正。
- 基準状態 = 素材を配置しただけの状態 = 全パラメータがデフォルト値の状態。素材は「目を開け、口を閉じた」状態で描かれている前提。
- キーは基準状態からの差分。位置・回転・頂点は加算、拡縮・不透明度は倍率（1 = 変化なし）。

### Parameter と ParameterGroup（@app/schema）

```ts
export interface ParameterGroup { id: ParameterGroupId; name: string }
export interface Parameter {
  id: Id;                          // 標準は 'FaceAngleX' など。ユーザー定義は任意の文字列
  name: string;                    // 表示名
  groupId: ParameterGroupId;
  min: number; max: number; default: number;
  standard: boolean;
}
```

### Binding と ParameterKey（@app/schema）

```ts
export type Channel = 'transform' | 'vertices' | 'warpPoints';
export interface TransformDelta { position: Vec2; rotation: number; scale: Vec2; opacity: number }
// position・rotation は加算、scale・opacity は倍率（1 = 変化なし）
export interface Binding {
  id: Id;
  target: { type: 'part' | 'mesh' | 'warp'; id: Id };   // transform → part、vertices → mesh、warpPoints → warp
  channel: Channel;
  parameterIds: Id[];              // 1 または 2
  keyValues: number[][];           // パラメータごとのキー位置（昇順。デフォルト値を必ず含む）
  keys: ParameterKey[];
  generation: 'linear' | 'depth' | 'rotate' | 'surface' | 'ease';
  divisions: number | null;        // 中間キーの分割数（自動なら null）
}
export interface ParameterKey {
  coords: number[];                // parameterIds と同じ順の値
  delta: TransformDelta | Vec2[];  // transform は TransformDelta、それ以外は頂点・制御点ごとの差分
  source: 'manual' | 'auto' | 'generated' | 'combined';
  locked: boolean;
}
```

### Model と Project（@app/schema）

```ts
export interface Model {
  parts: Part[];
  meshes: Mesh[];
  warps: Warp[];
  drawOrder: Id[];                 // 画像パーツの id。背面 → 前面
  parameters: Parameter[];
  parameterGroups: ParameterGroup[];
  bindings: Binding[];
  lipSync: LipSync;
  setupHints: { closedLineL: Vec2[] | null; closedLineR: Vec2[] | null };   // かんたんセットアップ用（閉じた目の線。STEP1で使う）
}
export interface Project {
  schemaVersion: number;           // 現在は 1
  id: Id;
  name: string;
  assets: Asset[];
  model: Model;
  expressions: Expression[];
  animations: Animation[];
  physics: Physics[];
  trackingMappings: TrackingMapping[];   // 空なら既定のマッピング
  studio: { scenes: Scene[]; activeSceneId: Id | null; hotkeys: Hotkey[] };
}
```

### MVPの標準パラメータ

| id | 表示名 | min | max | default |
| --- | --- | --- | --- | --- |
| FaceAngleX | 顔 左右 | -30 | 30 | 0 |
| FaceAngleY | 顔 上下 | -30 | 30 | 0 |
| FaceAngleZ | 顔 傾き | -30 | 30 | 0 |
| EyeOpenL / EyeOpenR | 目 開閉 L / R | 0 | 1 | 1 |
| EyeBallX / EyeBallY | 瞳 左右 / 上下 | -1 | 1 | 0 |
| MouthOpen | 口 開閉 | 0 | 1 | 0 |

### キー編集の契約（@app/contracts）

```ts
export type TransformChange = { dPosition?: Vec2; dRotation?: number; scaleFactor?: Vec2; opacityFactor?: number; dPivot?: Vec2 };
export type PointsTarget = { kind: 'mesh'; meshId: string } | { kind: 'warp'; warpId: string };
export interface KeyEditor {
  // EditorState の activeParameterIds と editorParamValues に応じて、基準状態かキーを変えるコマンドを返す
  transformEdit(project: Project, editor: EditorState, partIds: string[], change: TransformChange): Command | 'needsKey';
  pointsEdit(project: Project, editor: EditorState, target: PointsTarget, moves: { index: number; d: Vec2 }[]): Command | 'needsKey';
  addKeyAtCurrentValue(project: Project, editor: EditorState, target: { partId: string } | PointsTarget): Command;
}
```

### 生成・セットアップの契約（@app/contracts）

```ts
export interface KeyGenerator {
  linear(binding: Binding, divisions?: number): Binding;
  depthParallax(model: Model, parameterId: 'FaceAngleX' | 'FaceAngleY'): Binding[];   // 作り直した transform バインディング
}
export interface AutoSetup { plan(project: Project): { command: Command; warnings: string[] } }
```

### アプリの枠の差し込み口（apps/desktop/src/shell/api.ts）

```ts
export interface PanelDef { id: string; mode: ModeId; area: 'left' | 'right' | 'bottom'; title: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanel(def: PanelDef): void;
export interface SectionDef { id: string; panelId: string; order?: number; level?: 'easy' | 'detail' | 'both'; component: React.FC }
export function registerPanelSection(def: SectionDef): void;      // パネルの中の <PanelSections panelId=… /> に入る
export function PanelSections(props: { panelId: string }): JSX.Element;
export function registerCenter(mode: 'studio' | 'animation', component: React.FC): void;
export function registerSetupScreen(component: React.FC): void;   // 素材が1つも無いとき中央に出す
export function registerMenuItem(item: { id: string; label: string; shortcut?: string; run(): void }): void;

export interface CanvasPointerEvent { canvasPoint: Vec2; screenPoint: Vec2; button: number; shiftKey: boolean; altKey: boolean; ctrlKey: boolean }
export interface CanvasTool {
  id: string; label: string; cursor?: string;
  onPointerDown?(e: CanvasPointerEvent): void; onPointerMove?(e: CanvasPointerEvent): void; onPointerUp?(e: CanvasPointerEvent): void;
  onKeyDown?(e: KeyboardEvent): void;
  drawOverlay?(ctx: CanvasRenderingContext2D, view: ViewTransform): void;
}
export function registerCanvasTool(tool: CanvasTool): void;        // 最初に登録したものが既定のツール
export function registerCanvasOverlay(id: string, draw: (ctx: CanvasRenderingContext2D, view: ViewTransform) => void): void;
export function useCanvas(): { view: ViewTransform; activeToolId: string; setActiveTool(id: string): void; requestRedraw(): void; lastDeformed(): DeformedModel | null; screenToCanvas(p: Vec2): Vec2 };

export function useServices(): Services;
export function useProject(): Project;
export function useDispatch(): (c: Command) => void;
export function useEditor(): [EditorState, (patch: Partial<EditorState>) => void];
export function useEnvironment(): [Environment, (patch: Partial<Environment>) => void];
export function useDialogs(): { confirm(message: string): Promise<boolean>; notify(message: string): void; prompt(message: string, initial?: string): Promise<string | null> };
export function emitAppEvent(name: string, payload?: unknown): void;
export function onAppEvent(name: string, listener: (payload: unknown) => void): () => void;
```

### ストアの契約（@app/contracts）

```ts
export interface Command { label: string; apply(project: Project): Project }   // 純粋関数
export interface ProjectStore {
  get(): Project;
  subscribe(listener: (project: Project) => void): () => void;
  dispatch(command: Command): void;                                          // 1回の Undo 単位
  transaction(label: string, run: (dispatch: (c: Command) => void) => void): void;   // まとめて1回の Undo
  undo(): void; redo(): void; canUndo(): boolean; canRedo(): boolean;
  load(project: Project): void;                                              // 履歴を消して置き換える
}
export interface EditorState {
  mode: ModeId;
  uiLevel: Record<ModeId, UiLevel>;
  selectedPartIds: string[];
  activeParameterIds: string[];        // 編集中のパラメータ（0〜2個）
  editorParamValues: ParamValues;      // モデリング中のプレビュー値（無いパラメータはデフォルト値）
}
export interface EditorStore { get(): EditorState; set(patch: Partial<EditorState>): void; subscribe(l: (s: EditorState) => void): () => void }
```

## 作るもの

- パラメータパネル（right。`ParameterPanel.tsx`）: グループごとに並べ、行（`ParameterRow.tsx`）ごとにスライダー（`KeySlider.tsx`）と結果の言葉（下表）を出す。行を押すとそのパラメータを編集中にする（activeParameterIds = [id]、ほかのパラメータは editorParamValues でデフォルト値に戻す）。もう一度押すと編集をやめる（基準状態）。パネルの下に `<PanelSections panelId="parameters" />` を置く。
- スライダーにキーの印を出す（そのパラメータを使うバインディングのキー位置。● = manual・auto、○ = generated、■ = locked）。範囲の 2% 以内でキーに吸い付く。
- 編集中の表示（registerCanvasOverlay）: 「編集中: 顔 左右 ＝ 右（+30）」。キーの無い値なら「キーなし」を添える。
- [間を生成]: 編集中のパラメータを使う全バインディングに keyGenerator.linear を掛ける（1つの transaction）。FaceAngleX・FaceAngleY のときは [奥行きで作り直す]（keyGenerator.depthParallax）も出す。
- KeyEditor の本物（`services/keyEditor/index.ts` の `createKeyEditor()`。中を transform.ts・points.ts に分ける）:
  - 編集中のパラメータが無い: 基準状態を変える（Part の position・rotation・scale・pivot・opacity、メッシュやワープの基準の点）。
  - 編集中のパラメータが1つか2つ: その組と対象・チャンネル（パーツの変形 → transform、頂点 → vertices、ワープ → warpPoints）を持つバインディングを探し、無ければ作る（各 keyValues は [デフォルト値, 現在値] の昇順。デフォルト値のキーは差分 0）。現在値の組にキーがあれば、その差分に変更を足す（位置・回転・点は加算、scaleFactor・opacityFactor は掛ける）。source を 'manual' にし、かんたんモードでは locked を true にする。キーが無ければ 'needsKey'。
  - addKeyAtCurrentValue: 現在値を keyValues に足し、前後のキーから補間した差分で新しいキーを作る（見た目は変わらない）。source 'manual'。
  - dPivot は基準状態でだけ受け付ける。

| パラメータ | 結果の言葉（最小 / デフォルト / 最大） |
| --- | --- |
| 顔 左右 | 左 / 正面 / 右 |
| 顔 上下 | 下 / 正面 / 上 |
| 顔 傾き | 左へ / なし / 右へ |
| 目 開閉 L / R | 閉じる / – / 開く |
| 瞳 左右 / 上下 | 左 / 中央 / 右、下 / 中央 / 上 |
| 口 開閉 | 閉じる / – / 開く |

## 作らないもの

2Dの方向グリッド、中間キーの編集・ロック・再補間の操作（STEP1）。

## 完了条件

- [ ] 仮実装で、パラメータを選ぶとキーの印が出て、編集中の表示が出る
- [ ] キーのある値で編集すると、そのキーの差分が変わる（KeyEditor のユニットテスト）
- [ ] キーの無い値では needsKey、キーを足しても見た目が変わらない
- [ ] 基準状態の編集、2つのパラメータでの編集（ユニットテスト）
- [ ] [間を生成] と [奥行きで作り直す] が呼ばれ、Undo できる
