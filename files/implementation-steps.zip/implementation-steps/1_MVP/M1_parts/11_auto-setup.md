# 11. かんたんセットアップ（たたき台の生成）

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | MVP / M1 部品 |
| 並行作業 | 同じ段階の 06〜22 と並行して作れる（触るフォルダは重ならない） |
| 担当の目安 | コア |
| 作業場所 | packages/core/src/setup/ |

## 目的

割り当て済みの標準パーツから、階層・ピボット・描画順・マスクと基本の動きのたたき台を自動で作る。

## 前提（このカードの時点ですでにあるもの）

`@app/schema` と `@app/contracts` に下の型・規則・インターフェースがある。ほかの core の機能は使わず、このカードの中で計算する。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### 座標と値の約束

- 座標はキャンバス（元のPSD・PNG）のピクセル。原点は左上、x は右、y は下が正。
- 回転は度。画面上の時計回りが正。
- L / R はキャラクター自身から見た左右。画面では L が右側に描かれる。
- FaceAngleX はキャラクターが画面の右を向くと正、FaceAngleY は上を向くと正、FaceAngleZ は時計回りが正。EyeBallX は画面の右を見ると正、EyeBallY は上を見ると正。
- 基準状態 = 素材を配置しただけの状態 = 全パラメータがデフォルト値の状態。素材は「目を開け、口を閉じた」状態で描かれている前提。
- キーは基準状態からの差分。位置・回転・頂点は加算、拡縮・不透明度は倍率（1 = 変化なし）。

### パーツの変形と計算の順序

- パーツの変形は、点 p を `p' = position + pivot + R(rotation)·(scale ⊙ (p − pivot))` に動かす。R は y が下向きの座標で `[cos −sin; sin cos]`（正の角度で時計回り）。
- 実際に使う値: `position = Part.position + Δposition`、`rotation = Part.rotation + Δrotation`、`scale = Part.scale ⊙ Δscale`、`opacity = Part.opacity × Δopacity`（Δ はキーの合成結果）。
- 取り込み直後は position (0,0)・rotation 0・scale (1,1)。メッシュの頂点と pivot はキャンバス座標。
- 画像パーツの最終頂点は内側から外側へ求める。(1) メッシュの基準頂点 + 頂点の差分 → (2) 自身のパーツの変形 → (3) 親グループのワープ（あれば）→ (4) 親グループのパーツの変形 → ルートまで (3)(4) を繰り返す。
- 不透明度は、自身から親までの値をすべて掛け合わせる。

### Asset（@app/schema）

```ts
export interface Asset {
  id: Id;
  path: string;                    // 例: assets/<id>.png
  hash: string;                    // png の SHA-256（16進）
  width: number; height: number;   // トリミング後のサイズ
  offset: Vec2;                    // トリミング後の左上のキャンバス座標
  canvasSize: { width: number; height: number };
  source: { kind: 'psd' | 'png'; file: string; layerName?: string; layerPath?: string[]; hidden?: boolean };
  sourceBlendMode: BlendMode;
  sourceOpacity: number;           // 0..1
}
```

### Part と StandardPartType（@app/schema）

```ts
export interface Part {
  id: Id;
  name: string;
  kind: 'image' | 'group';
  standardType: StandardPartType | null;   // 自由パーツは null
  assetId: Id | null;                      // image のみ
  meshId: Id | null;                       // image のみ
  parentId: Id | null;
  position: Vec2;                          // 初期値 {x: 0, y: 0}
  rotation: number;                        // 度。初期値 0
  scale: Vec2;                             // 初期値 {x: 1, y: 1}
  pivot: Vec2;                             // 回転・拡縮の中心（キャンバス座標）
  opacity: number;                         // 0..1
  blendMode: BlendMode;
  depth: number;                           // 奥行き。手前が正（-1..1 が目安）
  mask: { sourcePartIds: Id[]; inverted: boolean } | null;
  physicsId: Id | null;
  visible: boolean;
  locked: boolean;
}
export type StandardPartType =
  | 'face' | 'earL' | 'earR' | 'cheek'
  | 'eyeWhiteL' | 'irisL' | 'highlightL' | 'upperLidL' | 'lowerLidL' | 'eyeWholeL'
  | 'eyeWhiteR' | 'irisR' | 'highlightR' | 'upperLidR' | 'lowerLidR' | 'eyeWholeR'
  | 'browL' | 'browR'
  | 'upperLip' | 'lowerLip' | 'mouthInside' | 'teeth' | 'tongue' | 'mouthWhole'
  | 'frontHair' | 'sideHairL' | 'sideHairR' | 'backHair'
  | 'neck' | 'torso' | 'armL' | 'armR'
  // 変形グループ（かんたんセットアップが作る）
  | 'bodyRoot' | 'armRootL' | 'armRootR' | 'neckRoot' | 'headRoot'
  | 'faceGroup' | 'eyeGroupL' | 'eyeGroupR' | 'mouthGroup';
```

### Parameter と ParameterGroup（@app/schema）

```ts
export interface ParameterGroup { id: ParameterGroupId; name: string }
export interface Parameter {
  id: Id;                          // 標準は 'FaceAngleX' など。ユーザー定義は任意の文字列
  name: string;                    // 表示名
  groupId: ParameterGroupId;
  min: number; max: number; default: number;
  standard: boolean;
}
```

### Binding と ParameterKey（@app/schema）

```ts
export type Channel = 'transform' | 'vertices' | 'warpPoints';
export interface TransformDelta { position: Vec2; rotation: number; scale: Vec2; opacity: number }
// position・rotation は加算、scale・opacity は倍率（1 = 変化なし）
export interface Binding {
  id: Id;
  target: { type: 'part' | 'mesh' | 'warp'; id: Id };   // transform → part、vertices → mesh、warpPoints → warp
  channel: Channel;
  parameterIds: Id[];              // 1 または 2
  keyValues: number[][];           // パラメータごとのキー位置（昇順。デフォルト値を必ず含む）
  keys: ParameterKey[];
  generation: 'linear' | 'depth' | 'rotate' | 'surface' | 'ease';
  divisions: number | null;        // 中間キーの分割数（自動なら null）
}
export interface ParameterKey {
  coords: number[];                // parameterIds と同じ順の値
  delta: TransformDelta | Vec2[];  // transform は TransformDelta、それ以外は頂点・制御点ごとの差分
  source: 'manual' | 'auto' | 'generated' | 'combined';
  locked: boolean;
}
```

### Model と Project（@app/schema）

```ts
export interface Model {
  parts: Part[];
  meshes: Mesh[];
  warps: Warp[];
  drawOrder: Id[];                 // 画像パーツの id。背面 → 前面
  parameters: Parameter[];
  parameterGroups: ParameterGroup[];
  bindings: Binding[];
  lipSync: LipSync;
  setupHints: { closedLineL: Vec2[] | null; closedLineR: Vec2[] | null };   // かんたんセットアップ用（閉じた目の線。STEP1で使う）
}
export interface Project {
  schemaVersion: number;           // 現在は 1
  id: Id;
  name: string;
  assets: Asset[];
  model: Model;
  expressions: Expression[];
  animations: Animation[];
  physics: Physics[];
  trackingMappings: TrackingMapping[];   // 空なら既定のマッピング
  studio: { scenes: Scene[]; activeSceneId: Id | null; hotkeys: Hotkey[] };
}
```

### 規則（@app/schema の rules.ts）

```ts
export const STANDARD_PARAMETERS: Parameter[];                      // 標準パラメータの表（standard: true）
export const PARAMETER_GROUPS: ParameterGroup[];                    // face 顔 / eye 目 / brow 眉 / mouth 口 / cheek 頬 / body 体 / armL 左腕 / armR 右腕 / sway 揺れもの / other その他
export const STANDARD_PART_NAMES: Record<StandardPartType, string>; // 日本語の表示名（例: eyeWhiteL → 白目 L）
export const STANDARD_DRAW_ORDER: StandardPartType[];               // 背面 → 前面（下記）
export const DEFAULT_DEPTH: Partial<Record<StandardPartType, number>>;   // 下記
export const PARALLAX_RATIO = 0.08;
// 奥行きによる移動量（px）。faceWidth は standardType 'face' の素材の幅
export function depthParallaxOffset(depth: number, value: number, faceWidth: number, axis: 'x' | 'y'): number {
  const d = depth * (value / 30) * faceWidth * PARALLAX_RATIO;
  return axis === 'x' ? d : -d;    // y は上が負
}
```

- STANDARD_DRAW_ORDER（背面 → 前面）: backHair, torso, armL, armR, neck, earL, earR, face, cheek, mouthInside, teeth, tongue, upperLip, lowerLip, mouthWhole, eyeWhiteL, eyeWhiteR, eyeWholeL, eyeWholeR, irisL, irisR, highlightL, highlightR, lowerLidL, lowerLidR, upperLidL, upperLidR, browL, browR, sideHairL, sideHairR, frontHair
- DEFAULT_DEPTH: frontHair 1.0 / browL・browR 0.6 / 目のパーツ（eyeWhite・iris・highlight・upperLid・lowerLid・eyeWhole の L・R）0.5 / 口のパーツ（upperLip・lowerLip・mouthInside・teeth・tongue・mouthWhole）0.5 / sideHairL・sideHairR 0.4 / cheek 0.4 / face 0.2 / earL・earR −0.5 / backHair −1.0

### ストアの契約（@app/contracts）

```ts
export interface Command { label: string; apply(project: Project): Project }   // 純粋関数
export interface ProjectStore {
  get(): Project;
  subscribe(listener: (project: Project) => void): () => void;
  dispatch(command: Command): void;                                          // 1回の Undo 単位
  transaction(label: string, run: (dispatch: (c: Command) => void) => void): void;   // まとめて1回の Undo
  undo(): void; redo(): void; canUndo(): boolean; canRedo(): boolean;
  load(project: Project): void;                                              // 履歴を消して置き換える
}
export interface EditorState {
  mode: ModeId;
  uiLevel: Record<ModeId, UiLevel>;
  selectedPartIds: string[];
  activeParameterIds: string[];        // 編集中のパラメータ（0〜2個）
  editorParamValues: ParamValues;      // モデリング中のプレビュー値（無いパラメータはデフォルト値）
}
export interface EditorStore { get(): EditorState; set(patch: Partial<EditorState>): void; subscribe(l: (s: EditorState) => void): () => void }
```

### 生成・セットアップの契約（@app/contracts）

```ts
export interface KeyGenerator {
  linear(binding: Binding, divisions?: number): Binding;
  depthParallax(model: Model, parameterId: 'FaceAngleX' | 'FaceAngleY'): Binding[];   // 作り直した transform バインディング
}
export interface AutoSetup { plan(project: Project): { command: Command; warnings: string[] } }
```

## 作るもの

- `createAutoSetup(): AutoSetup`。`plan(project)` は `{ command, warnings }` を返す。command は純粋な関数で、何度実行してもよい。
- 位置の基準: 画像パーツの外接矩形 = 素材の offset と幅・高さ。

1. 変形グループを作る（無いものだけ。standardType で判定）: bodyRoot・armRootL・armRootR・neckRoot・headRoot・faceGroup・eyeGroupL・eyeGroupR・mouthGroup。
2. 階層を下の木のとおりにする。割り当ての無い標準パーツは飛ばす。親の無い自由パーツは headRoot の子にする。
3. ピボット: bodyRoot = 胴体の下端中央、armRoot = 腕の上端中央、neckRoot = 首の下端中央、headRoot = 首の上端中央、faceGroup・eyeGroup・mouthGroup = 子の外接矩形の中心、髪 = 上端中央、白目 = 下端中央、その他 = 中心。首が無ければ neckRoot と headRoot は顔の下端中央、胴体が無ければ bodyRoot はキャンバスの下端中央。
4. 描画順: STANDARD_DRAW_ORDER の順に並べ、標準外の画像パーツは親の直前（手前）に入れる。
5. マスク: 瞳・ハイライト → 同じ側の白目、歯・舌 → 口の中（1つずつ、反転なし）。
6. 奥行き: depth が 0 のパーツだけ DEFAULT_DEPTH を入れる（ユーザーが変えた値は残す）。
7. MVP の標準パラメータが無ければ足す。
8. バインディング（すべて transform、source 'auto'）。既存のキーのうち manual と locked は残し、それ以外を作り直す。

| パラメータ | 対象 | 内容（キー以外の値の差分は 0） |
| --- | --- | --- |
| EyeBallX | 瞳・ハイライト | 値 1 で Δposition.x = 白目の幅 × 0.25、値 −1 で逆 |
| EyeBallY | 瞳・ハイライト | 値 1 で Δposition.y = −白目の高さ × 0.2、値 −1 で逆 |
| FaceAngleZ | neckRoot・headRoot | 値 30 で Δrotation = 9（首）・21（頭）、−30 で逆 |
| FaceAngleX / Y | headRoot 配下の画像パーツ | Δposition = depthParallaxOffset(depth, 値, 顔の幅, x または y)。顔の輪郭は FaceAngleX のとき Δscale.x = 1 − 0.04×│値│/30。キーは −30・0・30 |
| EyeOpenL / R | 同じ側の上まぶた・白目・下まぶた | 値 0 で: 上まぶた Δposition.y = 白目の下端 − 上まぶたの下端、白目 Δscale.y = 0.08、下まぶた Δposition.y = −白目の高さ × 0.1 |
| MouthOpen | 下唇・舌・口の中 | 値 1 で: 下唇と舌 Δposition.y = 口の中の高さ × 0.6、口の中 Δposition.y = 口の中の高さ × 0.3 |

- 目を1枚（eyeWhole）で割り当てた場合は、値 0 で eyeWhole の Δscale.y = 0.1（ピボットは中心）。口を1枚（mouthWhole）で割り当てた場合は、値 1 で Δscale.y = 1.6。
- キーの位置は表の値とデフォルト値（例: EyeOpen は 0 と 1）。
9. warnings: 推奨パーツ（白目・瞳・上まぶた・上唇・下唇・口の中）が足りないとき、動きがどう簡易になるかの文（例: 「上まぶたがないため、まばたきは目全体を縦に縮める方式になります」）。

階層の木:

```
bodyRoot
├ torso
├ armRootL └ armL
├ armRootR └ armR
└ neckRoot
   ├ neck
   └ headRoot
      ├ backHair
      ├ faceGroup
      │ ├ face
      │ ├ eyeGroupL: eyeWhiteL, irisL, highlightL, upperLidL, lowerLidL, eyeWholeL
      │ ├ eyeGroupR: eyeWhiteR, irisR, highlightR, upperLidR, lowerLidR, eyeWholeR
      │ ├ browL, browR
      │ ├ mouthGroup: mouthInside, teeth, tongue, upperLip, lowerLip, mouthWhole
      │ └ cheek
      ├ earL, earR
      ├ sideHairL, sideHairR
      └ frontHair
```

## 作らないもの

曲面の顔の向き・曲線のまばたき・眉や口の形（STEP1）。

## 完了条件

- [ ] fixtures の sample-model で、階層・ピボット・描画順・マスクが表のとおり
- [ ] 各バインディングのキーの位置と差分の符号が表のとおり
- [ ] 再実行で manual と locked のキーが残る
- [ ] 推奨パーツが足りないときに警告が出て、代わりの方式になる
