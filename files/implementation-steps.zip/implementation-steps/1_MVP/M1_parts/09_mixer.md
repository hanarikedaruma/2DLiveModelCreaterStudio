# 09. パラメータの合成（ミキサー）

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | MVP / M1 部品 |
| 並行作業 | 同じ段階の 06〜22 と並行して作れる（触るフォルダは重ならない） |
| 担当の目安 | コア |
| 作業場所 | packages/core/src/mix/ |

## 目的

トラッキング・表情などのレイヤーを、決まった順と合成方法で1つのパラメータ値にまとめる。

## 前提（このカードの時点ですでにあるもの）

`@app/schema` と `@app/contracts` に下の型とインターフェースがある。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### Parameter と ParameterGroup（@app/schema）

```ts
export interface ParameterGroup { id: ParameterGroupId; name: string }
export interface Parameter {
  id: Id;                          // 標準は 'FaceAngleX' など。ユーザー定義は任意の文字列
  name: string;                    // 表示名
  groupId: ParameterGroupId;
  min: number; max: number; default: number;
  standard: boolean;
}
```

### Expression（@app/schema）

```ts
export type BlendOp = 'override' | 'add' | 'multiply' | 'max';
export interface Expression {
  id: Id; name: string;
  entries: { parameterId: Id; value: number; blend: BlendOp }[];
  fadeIn: number; fadeOut: number;          // 秒
}
```

### 評価の契約（@app/contracts）

```ts
export type ParamValues = Record<string, number>;
export interface TargetDeltas {
  transforms: Record<string, TransformDelta>;   // partId → 合成済みの差分
  vertices: Record<string, Float32Array>;        // meshId → [dx0, dy0, dx1, dy1, ...]
  warpPoints: Record<string, Float32Array>;      // warpId → 制御点の差分（同じ並び）
}
export interface BindingEvaluator { evaluate(model: Model, params: ParamValues): TargetDeltas }
```

### 合成の契約（@app/contracts）

```ts
export type LayerId = 'tracking' | 'bodyFollow' | 'expression' | 'animation' | 'lipSync' | 'periodic' | 'physics';
export const LAYER_ORDER: LayerId[] = ['tracking', 'bodyFollow', 'expression', 'animation', 'lipSync', 'periodic', 'physics'];
export interface Layer {
  id: LayerId;
  weight: number;                     // 0..1
  values: ParamValues;                // このレイヤーが担当するパラメータの値だけ
  blend?: Record<string, BlendOp>;    // パラメータごとの合成方法。無ければ override
}
export interface ParameterMixer { mix(parameters: Parameter[], layers: Layer[]): ParamValues }

// スタジオの1フレームの文脈。producer は LAYER_ORDER の順に呼ばれる
export interface FrameContext {
  now: number; dt: number;            // ミリ秒
  project: Project;
  mixedSoFar: ParamValues;            // それまでのレイヤーを合成した値
  flags: { lipSyncWeight: number; physicsActive: boolean };   // 前のレイヤーが後のレイヤーへ伝える値（初期値 1・true）
}
export interface LayerProducer { id: LayerId; produce(ctx: FrameContext): Layer | null }
```

## 作るもの

- `createParameterMixer(): ParameterMixer`。
- 各パラメータをデフォルト値から始め、LAYER_ORDER の順にレイヤーを適用する。引数の配列の順は使わない（同じ id が複数あれば、その id の中では配列の順）。
- 適用: op = blend[id] ?? 'override'、w = weight（0..1 に丸める）、t = レイヤーの値。
  - override: v ← v + (t − v)·w
  - add: v ← v + t·w
  - multiply: v ← v·(1 + (t − 1)·w)
  - max: v ← v + (max(v, t) − v)·w
- 最後に min..max に丸める。知らない id は無視する。

## 作らないもの

各レイヤーの値を作る処理（それぞれのカード）。

## 完了条件

- [ ] 4つの合成方法ごとの値（重み 0・0.5・1）
- [ ] 引数の順に関係なく LAYER_ORDER で合成される
- [ ] 範囲への丸め、知らない id の無視
