# 10. メッシュの自動生成

> このカードだけで実装できるように、必要な仕様・型・約束をすべて書いている。ほかのカードや設計書を読む必要はない。「前提」に書いたものは、このカードの時点で必ずある。名前と形を変えないこと。

| 項目 | 内容 |
| --- | --- |
| フェーズ / 段階 | MVP / M1 部品 |
| 並行作業 | 同じ段階の 06〜22 と並行して作れる（触るフォルダは重ならない） |
| 担当の目安 | コア |
| 作業場所 | packages/core/src/mesh/ |

## 目的

素材の不透明部分から、変形に使うメッシュを自動で作る。

## 前提（このカードの時点ですでにあるもの）

`@app/schema` と `@app/contracts` に下の型とインターフェースがある。

抜粋に名前だけ出てくる型も、すべて `@app/schema` か `@app/contracts` から import できる。

### 座標と値の約束

- 座標はキャンバス（元のPSD・PNG）のピクセル。原点は左上、x は右、y は下が正。
- 回転は度。画面上の時計回りが正。
- L / R はキャラクター自身から見た左右。画面では L が右側に描かれる。
- FaceAngleX はキャラクターが画面の右を向くと正、FaceAngleY は上を向くと正、FaceAngleZ は時計回りが正。EyeBallX は画面の右を見ると正、EyeBallY は上を見ると正。
- 基準状態 = 素材を配置しただけの状態 = 全パラメータがデフォルト値の状態。素材は「目を開け、口を閉じた」状態で描かれている前提。
- キーは基準状態からの差分。位置・回転・頂点は加算、拡縮・不透明度は倍率（1 = 変化なし）。

### Mesh（@app/schema）

```ts
export interface Mesh {
  id: Id;
  vertices: Vec2[];                // 基準状態の頂点（キャンバス座標）
  uvs: Vec2[];                     // 0..1（素材画像の中の位置）
  triangles: [number, number, number][];
  density: 'light' | 'standard' | 'smooth' | 'custom';
  edited: boolean;                 // 手で編集したか
}
```

### メッシュ生成の契約（@app/contracts）

```ts
export interface MeshGenerator {
  generate(alpha: ImageData, offset: Vec2, density: 'light' | 'standard' | 'smooth'):
    { vertices: Vec2[]; uvs: Vec2[]; triangles: [number, number, number][] };   // 頂点はキャンバス座標
}
```

## 作るもの

- `createMeshGenerator(): MeshGenerator`。
- 不透明部分（alpha ≥ 8）の輪郭を marching squares で求める。穴と、離れた島も扱う。
- 輪郭を Douglas–Peucker で単純化する（許容誤差: light 6px、standard 3px、smooth 1.5px）。
- 内部に格子状の点を足す（間隔: light 80px、standard 48px、smooth 28px。輪郭から間隔の半分以内の点は足さない）。
- 輪郭を制約にした三角形分割（例: cdt2d）を行い、輪郭の外の三角形は捨てる。
- 頂点はキャンバス座標（画像の中の位置 + offset）。uvs は画像の中の位置 ÷ 画像サイズ。
- 不透明なピクセルが1つも無い画像は、画像全体の四角形を返す。

## 作らないもの

メッシュの編集の画面、キーの扱い（別のカード）。

## 完了条件

- [ ] 不透明なピクセルの 99% 以上が三角形の内側に入る
- [ ] 穴のある画像・離れた島のある画像
- [ ] light < standard < smooth の順に頂点が増える
- [ ] uvs がすべて 0..1
- [ ] 2000×2000px の画像で 200ms 未満
